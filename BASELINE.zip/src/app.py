import streamlit as st
import altair as alt
import openai
import json
import os
import re
from dotenv import load_dotenv # To load .env file for local development

import pandas as pd
# -------------------------------
# STEP 0: Configuration and Setup
# -------------------------------
# Load environment variables from a .env file if it exists.
# This is useful for local development.
load_dotenv()

# Initialize the OpenAI client (for openai library version 1.0.0+).
# The client automatically looks for the API key in the following order:
# 1. The `OPENAI_API_KEY` environment variable (which `load_dotenv()` helps set).
# 2. Streamlit secrets (`st.secrets['OPENAI_API_KEY']`) when deployed.
client = openai.OpenAI()

# -------------------------------
# STEP 1: Load Data
# -------------------------------
st.markdown("<h1 style='font-size: 1.8em;'>📊 Performance Dashboard with AI Chat</h1>", unsafe_allow_html=True)

@st.cache_data
def load_data():
    # Construct the data file path robustly using os.path.join for cross-platform compatibility.
    # This also makes the path relative to the script's directory.
    script_dir = os.path.dirname(__file__)
    project_root = os.path.dirname(script_dir) # Go up one level from 'src' to the project root
    data_file_path = os.path.join(project_root, "logs", "ept_coverage_delegation_compact.csv")
    try:
        df = pd.read_csv(data_file_path)

        # Ensure required columns exist
        required_cols = ['api_name', 'test_case_id', 'worker_id', 'iteration_number', 'http_status_code', 'http_latency_ms', 'response_size_bytes', 'sla_met']
        if not all(col in df.columns for col in required_cols):
            missing = [col for col in required_cols if col not in df.columns]
            st.error(f"The data file is missing the following required columns: {', '.join(missing)}")
            st.stop()

        # Add 'test_status' column
        df['test_status'] = df['sla_met'].apply(lambda x: 'Pass' if x else 'Fail')

        # Select and sort data
        df = df[required_cols + ['test_status']]
        df = df.sort_values(by=['api_name', 'test_case_id', 'worker_id', 'iteration_number']).reset_index(drop=True)
        return df
    except FileNotFoundError:
        st.error(f"Error: The data file '{data_file_path}' was not found. Please ensure 'ept_coverage_delegation_compact.csv' is in the 'logs' subdirectory.")
        st.stop()
    except Exception as e:
        st.error(f"An error occurred while loading or processing the data: {e}")
        st.stop()

df = load_data()

# Create a combined column for the legend
df['api_test_case'] = df['api_name'] + '/' + df['test_case_id'].astype(str)

# Get unique API and Test Case combinations
combinations = df[['api_name', 'test_case_id']].drop_duplicates()

# -------------------------------
# STEP 3: Overall Performance Summary
# -------------------------------
st.subheader("Performance Summary")

# Calculate overall performance metrics for each API and Testcase combination
overall_performance_df = df.groupby(['api_name', 'test_case_id']).agg(
    avg_response_time_ms=('http_latency_ms', 'mean'),
    p95_response_time_ms=('http_latency_ms', lambda x: x.quantile(0.95)),
    sla_compliance_pct=('sla_met', lambda x: x.mean() * 100)
).reset_index()

st.dataframe(overall_performance_df.style.format({
    'avg_response_time_ms': '{:.0f}',
    'p95_response_time_ms': '{:.0f}',
    'sla_compliance_pct': '{:.2f}'
}), hide_index=True, use_container_width=True)
st.divider()

# --- Combined Chart ---
st.subheader("Overall Response Time Chart")

# Calculate average latency for each combination and iteration
combined_avg_latency_df = df.groupby(['api_test_case', 'iteration_number'], as_index=False)['http_latency_ms'].mean()

combined_chart = alt.Chart(combined_avg_latency_df).mark_line(point=True).encode(
    x=alt.X('iteration_number', title='Iteration Number'),
    y=alt.Y('http_latency_ms', title='Average Response Time (ms)'),
    color=alt.Color('api_test_case:N', legend=alt.Legend(
        title="API/Test Case",
        orient="bottom",
        direction="vertical",
        labelLimit=0
    )),
    tooltip=['api_test_case', 'iteration_number', alt.Tooltip('http_latency_ms', format=',.0f')]
).properties(
    title="Average Response Time per API/Test Case"
).interactive()

st.altair_chart(combined_chart, use_container_width=True)
st.divider()
# -------------------------------
# STEP 4: Default Charts
# -------------------------------
# Custom CSS for Apple-style tables
st.markdown("""
<style>
.metric-table {
    border-collapse: collapse;
    width: 100%;
    border-radius: 8px;
    overflow: hidden;
    border: 1px solid #e1e4e8;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
}
.metric-table th, .metric-table td {
    padding: 6px 8px;
    text-align: left;
}
.metric-table th {
    background-color: #f6f8fa;
    font-weight: 600;
}
.metric-table tr:not(:last-child) td {
    border-bottom: 1px solid #e1e4e8;
}
</style>
""", unsafe_allow_html=True)

st.subheader("Detailed Results per API/Test Case Combination")

for index, row in combinations.iterrows():
    api_name = row['api_name']
    test_case_id = row['test_case_id']
    
    # Dataframe for the current combination
    combo_df = df[(df["api_name"] == api_name) & (df["test_case_id"] == test_case_id)].copy()

    st.markdown(f"#### Actual Results for {api_name}/{test_case_id}")
    unique_iterations = sorted(combo_df['iteration_number'].unique())
    iterations_to_show = unique_iterations[:20] # Showing first 20 iterations

    if iterations_to_show:
        table_df_data = combo_df[combo_df['iteration_number'].isin(iterations_to_show)]
        sorted_table_data = table_df_data.sort_values(by=['worker_id', 'iteration_number']).reset_index(drop=True)

        def get_status_html(status):
            color = "blue" if status == "Pass" else "red"
            return f'<span style="color: {color};">{status}</span>'

        num_records = len(sorted_table_data)
        num_cols = 10

        for i in range(0, num_records, num_cols):
            cols = st.columns(num_cols)
            chunk = sorted_table_data.iloc[i:i+num_cols]

            for j, record in enumerate(chunk.itertuples(index=False)):
                with cols[j]:
                    table_html = f"""
                    <table class="metric-table">
                        <tr><td>{record.worker_id}/{record.iteration_number}</td></tr>
                        <tr><td>{record.http_latency_ms:.0f}</td></tr>
                        <tr><td>{get_status_html(record.test_status)}</td></tr>
                    </table>
                    """
                    st.markdown(table_html, unsafe_allow_html=True)
            st.write("")
    else:
        st.write("No data available for this combination to display in table format.")

    st.divider()

# -------------------------------
# STEP 5: Memory Layer
# -------------------------------
if "memory" not in st.session_state:
    st.session_state.memory = {
        "chart_preference": None,
        "priority_metric": None,
        "focus_worker": None,
        "response_style": "detailed"
    }

# Sidebar memory editor
st.sidebar.subheader("AI Memory Settings")
st.sidebar.write(st.session_state.memory)

if st.sidebar.button("Reset Preferences"):
    st.session_state.memory = {
        "chart_preference": None,
        "priority_metric": None,
        "focus_worker": None,
        "response_style": "detailed"
    }

# -------------------------------
# STEP 6: Chat Interface
# -------------------------------
user_query = st.chat_input("Ask about performance metrics...")

if user_query:
    # Display user's message in the chat history
    st.chat_message("user").write(user_query)

    # Update memory based on user query
    if "prefer bar chart" in user_query.lower():
        st.session_state.memory["chart_preference"] = "bar"
    if "always show sla" in user_query.lower():
        st.session_state.memory["priority_metric"] = "sla_compliance"
    if "focus on gw1" in user_query.lower():
        st.session_state.memory["focus_worker"] = "gw1"
    if "be concise" in user_query.lower():
        st.session_state.memory["response_style"] = "concise"

    # -------------------------------
    # STEP 7: Guardrails
    # -------------------------------
    keywords = ["latency","sla","worker","iteration","success","failure","duration", "api", "test case"]
    if not any(k in user_query.lower() for k in keywords):
        st.chat_message("assistant").write(
            "Sorry, I can only answer performance-related questions about the dataset."
        )
    else:
        # -------------------------------
        # STEP 8: Prompt Engineering
        # -------------------------------
        system_prompt = f"""
        You are an AI assistant embedded in a Streamlit dashboard that displays performance test results.
        The full dataset is available for your analysis.

        Rules:
        - Answer performance-related questions and provide a text summary based on the user's query and the provided data context.
        - Always return chart suggestions in a JSON code block. The JSON should follow this structure:
          {{ "chart_type": "...", "x_axis": "...", "y_axis": "...", "group_by": "...", "aggregation": "..." }}
        - Apply user preferences from their memory settings when generating responses and chart suggestions:
          Chart preference: {st.session_state.memory['chart_preference']}
          Priority metric: {st.session_state.memory['priority_metric']}
          Focus worker: {st.session_state.memory['focus_worker']}
          Response style: {st.session_state.memory['response_style']}
        - If a user's query is vague, ask clarifying questions to get more specific details before providing a full answer.
        - Base your answers on the provided data context.
        """
        user_prompt = f"User Query: {user_query}\n\nContext Data (first 10 rows): {df.head(10).to_dict(orient='records')}"

        try:
            response = client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role":"system","content":system_prompt},
                    {"role":"user","content":user_prompt}
                ]
            )
            ai_output = response.choices[0].message.content
            st.chat_message("assistant").write(ai_output)

            # -------------------------------
            # STEP 9: Parse JSON & Render Chart
            # -------------------------------
            # Use regex to robustly find the JSON block, even with surrounding text
            json_match = re.search(r"```json\n({.*?})\n```", ai_output, re.DOTALL)
            chart = None

            if json_match:
                try:
                    chart_config_str = json_match.group(1)
                    chart_config = json.loads(chart_config_str)

                    chart_type = chart_config.get("chart_type") or st.session_state.memory.get("chart_preference")
                    x_axis = chart_config.get("x_axis")
                    y_axis = chart_config.get("y_axis")
                    group_by = chart_config.get("group_by")
                    aggregation = chart_config.get("aggregation")

                    if chart_type and x_axis and y_axis:
                        # Use the full dataframe for AI-generated charts
                        chart_data = df

                        # Apply aggregation if specified
                        if aggregation:
                            y_encoding = f"{aggregation}({y_axis}):Q"
                        else:
                            y_encoding = y_axis

                        if chart_type == "line":
                            chart = alt.Chart(chart_data).mark_line().encode(x=x_axis, y=y_encoding, color=group_by)
                        elif chart_type == "bar":
                            chart = alt.Chart(chart_data).mark_bar().encode(x=x_axis, y=y_encoding, color=group_by)
                        elif chart_type == "pie":
                            chart = alt.Chart(chart_data).mark_arc().encode(theta=y_encoding, color=group_by)
                        else:
                            st.warning(f"AI suggested an unsupported chart type: '{chart_type}'.")

                except json.JSONDecodeError:
                    st.warning("AI returned invalid JSON. Cannot render a chart.")
                except Exception as e:
                    st.error(f"An error occurred while creating the chart: {e}")

            if chart:
                st.altair_chart(chart, use_container_width=True)

        except openai.APIError as e:
            st.chat_message("assistant").error(f"An error occurred with the OpenAI API: {e}")
        except Exception as e:
            st.chat_message("assistant").error(f"An unexpected error occurred: {e}")