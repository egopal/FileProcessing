from lxml_sample import etree

xmlString = """
<RunResults
  xmlns="http://www.hp.com/PC/REST/API">
  <RunResult>
    <ID>1122</ID>
    <Name>output.mdb.zip</Name>
    <Type>OUTPUT LOG</Type>
    <RunID>48</RunID>
  </RunResult>
  <RunResult>
    <ID>1123</ID>
    <Name>RawResults_48.zip</Name>
    <Type>RAW RESULTS</Type>
    <RunID>48</RunID>
  </RunResult>
  <RunResult>
    <ID>1124</ID>
    <Name>Results_48.zip</Name>
    <Type>ANALYZED RESULT</Type>
    <RunID>48</RunID>
  </RunResult>
  <RunResult>
    <ID>1125</ID>
    <Name>Reports.zip</Name>
    <Type>HTML REPORT</Type>
    <RunID>48</RunID>
  </RunResult>
  <RunResult>
    <ID>1126</ID>
    <Name>HighLevelReport_48.xls</Name>
    <Type>RICH REPORT</Type>
    <RunID>48</RunID>
  </RunResult>
</RunResults>"""

root = etree.XML(xmlString)
print(etree.tostring(root))

id = None
for element in root.iter("*"):
    if (element.tag == '{http://www.hp.com/PC/REST/API}ID'):
        id = element.text
    if (element.tag == '{http://www.hp.com/PC/REST/API}Type' and element.text == 'HTML REPORT'):
        print(element.text)
        print(id)
