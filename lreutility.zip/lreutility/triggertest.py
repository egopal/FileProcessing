import login
import requests
import os
import urllib3
from requests.auth import HTTPBasicAuth

urllib3.disable_warnings()
server = os.environ['SERVER']
port = os.environ['PORT']
domain = os.environ['DOMAIN']
project = os.environ['PROJECT']

def runTest(payload, cookie):
    url = "https://" + server + ":" + port + "/LoadTest/rest/domains/" + domain + "/projects/" + project + "/Runs"
    lreUserName = os.environ['LRE_USER'];
    lrePassword = os.environ['LRE_PASSWORD'];

    headers = {
        'cookie': str(cookie) + "; LoginClient=qc",
        'Cookie': cookie,
        'Content-Type': "application/xml"
    }
    response = requests.request("POST", url, data=payload, headers=headers, verify=False, auth=HTTPBasicAuth(lreUserName, lrePassword))

    # print("Run Test: Response: ", response.text)
    # print("Run Test: Response Status Code: ", response.status_code)
    return response.text

# cookie = login.getCookie()
# runTest('<Run xmlns="http://www.hp.com/PC/REST/API">  <PostRunAction>Collate And Analyze</PostRunAction>  <TestID>204</TestID>  <TestInstanceID>18</TestInstanceID>  <TimeslotDuration>  <Hours>0</Hours>  <Minutes>5</Minutes>  </TimeslotDuration>  <VudsMode>false</VudsMode> </Run>', cookie)
