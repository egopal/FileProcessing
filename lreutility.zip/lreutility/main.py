import login
import argparse
import triggertest
import re

parser = argparse.ArgumentParser()
parser.add_argument('-testId', action='store', dest='testId', help='LRE Test Id', nargs='?')
parser.add_argument('-instanceId', action='store', dest='instanceId', help='LRE Test Instance Id', nargs='?')
parser.add_argument('-durationHours', action='store', dest='durationHours', help='Duration in hours', nargs='?')
parser.add_argument('-durationMinutes', action='store', dest='durationMinutes', help='Duration in minutes', nargs='?')
args = parser.parse_args()
testId = args.testId
instanceId = args.instanceId
durationHours = args.durationHours
durationMinutes = args.durationMinutes

def getRunId(xml_string):
    result = None
    matchobj = re.search("<ID>(.+)<\/ID>", xml_string)
    if matchobj:
        result = matchobj.group(1)
    return result

def main():
    """Main method: Login to """
    if testId and instanceId and durationHours and durationMinutes:
        cookie = 'LWSSO_COOKIE_KEY=' + login.getCookie()
        xmlRequestBody = '<Run xmlns="http://www.hp.com/PC/REST/API"><PostRunAction>Collate And Analyze</PostRunAction><TestID>TEST_ID</TestID><TestInstanceID>INSTANCE_ID</TestInstanceID><TimeslotDuration><Hours>DURATION_HOURS</Hours><Minutes>DURATION_MINUTES</Minutes></TimeslotDuration><VudsMode>false</VudsMode></Run>'
        xmlRequestBody = xmlRequestBody.replace("TEST_ID", testId).replace("INSTANCE_ID", instanceId).replace("DURATION_HOURS", durationHours).replace("DURATION_MINUTES", durationMinutes)
        responseXml = triggertest.runTest(xmlRequestBody, cookie)
        run_id = getRunId(responseXml)
        print("Run id: ", run_id)
        if run_id:
            with open("run.properties", "w") as file:
                file.write("run_id=" + run_id)
        else:
            print("Error: Run ID is ", run_id)
            exit(-1)
    else:
        print("Required parameters: -testId -instanceId -durationHours -durationMinutes")
        print("Example:python main.py -testId 204 -instanceId 18 -durationHours 0 -durationMinutes 5")

main()
