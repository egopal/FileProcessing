import requests
import os
import urllib3

urllib3.disable_warnings()
server = os.environ['SERVER']
port = os.environ['PORT']

url = "https://" + server + ":" + port + "/LoadTest/rest/authentication-point/authenticate"
lreUserName = os.environ['LRE_USER'];
lrePassword = os.environ['LRE_PASSWORD'];

def getCookie():
    headers = {'Content-Type': "application/xml"}
    response = requests.request("GET", url, headers=headers, auth=(lreUserName, lrePassword), verify=False)

    cookies = response.cookies
    returnCookie = None
    for cookie in cookies:
        returnCookie = cookie.value
        break
    return returnCookie

def getHeaders():
    headers = {'Content-Type': "application/xml"}
    response = requests.request("GET", url, headers=headers, auth=(lreUserName, lrePassword), verify=False)
    return response.headers

# print(getCookie())