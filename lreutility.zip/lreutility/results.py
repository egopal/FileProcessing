import requests
import urllib3
import os
import login
import argparse
import time
from lxml import etree

urllib3.disable_warnings()
lreUserName = os.environ['LRE_USER'];
lrePassword = os.environ['LRE_PASSWORD'];

parser = argparse.ArgumentParser()
parser.add_argument('-runId', action='store', dest='runId', help='LRE Run Id', nargs='?')
server = os.environ['SERVER']
port = os.environ['PORT']
domain = os.environ['DOMAIN']
project = os.environ['PROJECT']
# project = "Onlineapps"

def getRun(cookie, run_id):
    url = "https://" + server + ":" + port + "/LoadTest/rest/domains/" + domain + "/projects/" + project + "/Runs/" + str(run_id)

    payload = ""
    headers = {
        'cookie': str(cookie) + "; LoginClient=qc",
        'Cookie': cookie,
        'Content-Type': "application/xml"
    }
    print("headers", headers)
    response = requests.request("GET", url, headers=headers, auth=(lreUserName, lrePassword), verify=False)
    # print(response.text)
    return response.text

def getRunResults(cookie, run_id):
    url = "https://" + server + ":" + port + "/LoadTest/rest/domains/" + domain + "/projects/" + project + "/Runs/" + str(run_id) + "/Results"
    print("url", url)

    payload = ""
    headers = {
        'cookie': str(cookie) + "; LoginClient=qc",
        'Cookie': cookie,
        'Content-Type': "application/xml"
    }
    print("headers", headers)
    response = requests.request("GET", url, headers=headers, auth=(lreUserName, lrePassword), verify=False)
    # print(response.text)
    return response.text

def getAllResultsZip(cookie, run_id):
    headers = {
        'cookie': str(cookie) + "; LoginClient=qc",
        'Cookie': cookie,
        'Content-Type': "application/xml"
    }
    resultsXml = getRunResults(cookie, run_id)
    root = etree.XML(resultsXml)
    # print(etree.tostring(root))
    result_id = None
    for element in root.iter("*"):
        if (element.tag == '{http://www.hp.com/PC/REST/API}ID'):
            result_id = element.text
        if result_id:
            if (element.tag == '{http://www.hp.com/PC/REST/API}Name'):
                name = element.text
                url = "https://" + server + ":" + port + "/LoadTest/rest/domains/" + domain + "/projects/" + project + "/Runs/" + str(
                    run_id) + "/Results/" + str(result_id) + "/data"
                print(url)
                response = requests.request("GET", url, headers=headers, auth=(lreUserName, lrePassword), verify=False, stream=True)
                with open(name, 'wb') as fd:
                    for chunk in response.iter_content(chunk_size=512):
                        fd.write(chunk)

def getResultsZip(cookie, run_id, results_id):
    url = "https://" + server + ":" + port + "/LoadTest/rest/domains/" + domain + "/projects/" + project + "/Runs/" + str(run_id) + "/Results/" + str(results_id) + "/data"
    print(url)

    payload = ""
    headers = {
        'cookie': str(cookie) + "; LoginClient=qc",
        'Cookie': cookie,
        'Content-Type': "application/xml"
    }
    response = requests.request("GET", url, headers=headers, auth=(lreUserName, lrePassword), verify=False, stream=True)
    with open("Results" + str(time.time()) + ".zip", 'wb') as fd:
        # print(response.text)
        print(response.status_code)
        with open("Reports.zip", 'wb') as fd:
            for chunk in response.iter_content(chunk_size=512):
                fd.write(chunk)

def getResultsId(xml_string):
    result_id = None
    root = etree.XML(xml_string)
    print(etree.tostring(root))

    for element in root.iter("*"):
        if (element.tag == '{http://www.hp.com/PC/REST/API}ID'):
            result_id = element.text
        if (element.tag == '{http://www.hp.com/PC/REST/API}Type' and element.text == 'HTML REPORT'):
            print(element.text)
            print(result_id)

    return result_id

def main():
    args = parser.parse_args()
    run_id = args.runId
    cookie = 'LWSSO_COOKIE_KEY=' + login.getCookie()
    resultsXml = getRunResults(cookie, run_id)
    results_id = getResultsId(resultsXml)
    if results_id:
        getResultsZip(cookie, run_id=run_id, results_id=results_id)
    else:
        print("No results available for run ID: ", run_id)
        exit(-1)

    # TODO: Temporarily disabled till HTML Report issue is resolved
    # resultsXml = getRunResults(cookie, run_id)
    # results_id = getResultsId(resultsXml)
    # if results_id:
    #     getResultsZip(cookie, run_id=run_id, results_id=results_id)
    # else:
    #     print("No results available for run ID: ", run_id)
    #     exit(-1)

    # Use for debugging file download
    getAllResultsZip(cookie, run_id)

main()
# getRun('LWSSO_COOKIE_KEY=' + login.getCookie(), 60)
# getRunResults('LWSSO_COOKIE_KEY=' + login.getCookie(), 47)
# getResultsZip('LWSSO_COOKIE_KEY=' + login.getCookie(), 47, 1121)
