from string import punctuation
from collections import OrderedDict
import yaml
import logging 
from Record import Record

def setup_logger(file_path):
	'''
		input:
			file_path: absolute path of the file which would be used for logging 
		operation:
			- setups the config of the logger with thefollowing info 
				- filename where it would be present 
				- the format in which it would be written 
				- wrting in "write mode"
			- setting the logger to write all the logs equal to and greater than "DEBUG"
	'''

	# creating the logger with the format i.e. all the things which need to be written
	logging.basicConfig(filename=file_path,
						format='%(filename)s - %(lineno)s - %(funcName)s() - %(levelname)s - %(message)s',
						filemode='w')

	# getting logger instance
	logger = logging.getLogger()

	# setting the threshold level to record the data
	logger.setLevel(logging.DEBUG)

def get_extratced_data_chunk(input_file, ignore_lines_starter, ignore_lines_starter_ender, delimiter):
	'''	
		input:
			input_file: the fiel to start reading  
			ignore_lines_starter: the set of limiters ... to ignore lines starting with these strings
			ignore_lines_starter_ender:  the set of limiters ... to ignore lines starting and ending with these strings
			delimiter: the delimitter to get to knwo that 1 record has ended
		operation:
			- define a list {data} to hold lines of 1 record .. here data is the variable
			- opening the file
				- for each row in file
					- flag variable to skip line {skip_line} is initialized to False
					- for each string in the list {ignore_lines_starter} 
						- if the line starts with this string
							- set {skip_line} to True
					- for each string pair in the list {ignore_lines_starter_ender} 
						- if the line starts and ends with the pairs provided in the list 
							- set {skip_line} to True
					- if {skip_line} is set to True
						- ignore the line 
					- if after stripping the puctuations and white space (READ ABOUT STRIP FUNCTION IN PYTHON) the lenght == 0
						- ignore the line 
					- if the line starts with delimiter and we have some lines collected in {data} already
						- yield the {data} .. i.e. the chunk of lines collected till now 
						- (READ ABOUT YIELD IN PYTHON) 
					- add line to {data} after stripping punctuations and white space where we are storing lines 
				- if the line starts with delimiter and we have some lines collected in {data} already
					- yield the {data} .. i.e. the chunk of lines collected till now 					
		output:
			this is a generator function
			so as soon as one chunk of information is extracted from the testcatalog file
			that is returned chunk by chunk  
	'''
	logger = logging.getLogger()

	# data list to hold lines
	data = []	
	
	# opening the input file to read data
	with open(input_file,"r") as f:	
		# iterating through the lines of files
		for row in f:
			
			# ignore lines starting with lines that are to be ignored 
			skip_line = False
			# ignore_lines_starter = ["--","=="]
			for ignore_word in ignore_lines_starter:
				if(row.strip().startswith(ignore_word)):
					skip_line=True			
					logger.debug("skipping the line \"{}\" ... because it starts with word: \"{}\"".format(row,ignore_word))
					break
						
			for ignore_word_starter, ignore_word_ender in ignore_lines_starter_ender:
				if(row.strip().startswith(ignore_word_starter) and row.strip().endswith(ignore_word_ender)):
					skip_line=True			
					logger.debug("skipping the line \"{}\" ... because it starts with word: \"{}\" and ends with word: \"{}\". ".format(row,ignore_word_starter,ignore_word_ender))
					break
			
			if(skip_line==True):
				continue
			
			# ignore lines if the lines is blank
			if(len(row.strip(strip_punctuation))==0):
				continue
					
			# if a line starts with "~~" and all the lenght of data >0, 
			# then information would be extarcted from data
			if(row.strip().startswith(delimiter) and len(data)>0):
				# data would be extracted and in this case we won't be writing data to output file
				logger.info("found a delimiter \"{}\". Collected info till now would be extracted.".format(delimiter))
				yield data
				#'''Read about generators in function and yeild function'''

			# if line is valid and has content, then it is added to data list
			data.append(row.strip(strip_punctuation))	
		
		# this is a way to hanlde the last line of data, since we won't be having "~~" at the end, 
		# so, when we reach the end, then last line of data would be extarted   
		if(len(data)>0):
			logger.info("file has ended. Collected info till now would be extracted.")
			yield data


if(__name__=="__main__"):
	"""
	# Here, I would be extracting data 2 times
	# Since the no. of fields are not constant
	# So, when we do the first time, we would be exploring the total number of fields which we have
	# and the second time we woudl do the same, we would be writing all the details in the file
	- reading the config file or all the details
	- extacting all the information from the config file 
	- define an ordered dictionary
	- for each of the keys in the config file
		- set the value of each of the key to be None
	- read more info from config file into varibales
	- for each data chunk in the file 
		- extarct all the information Record and do not write the info to the file
	- write all the headers extarcted till now as columns of the csv file 
	- for each data chunk in the file 
		- extarct all the information Record and write the info to the file
	"""

	with open("config.yaml") as file:
		config = yaml.load(file, Loader=yaml.FullLoader)

	log_file_name = config["log_file_name"]
	setup_logger(log_file_name)

	logger = logging.getLogger()

	# punctuations to be stripped off from the string
	strip_punctuation = punctuation + " "
	logger.debug("would be stripping off the following punctuations \"{}\"".format(strip_punctuation))

	#  file from where data would be read
	input_file = config["input_file"]
	logger.debug("input file:- \"{}\"".format(input_file))

	# file where data would be written 
	output_file = config["output_file"]
	logger.debug("output file:- \"{}\"".format(output_file))

	# separator between key and value  
	separators = config["separators"]
	logger.debug("separators:- \"{}\"".format(separators))

	# keys which are simmilar and are brought down to the same value 
	alias_keys = config["data_keys"]["alias_keys"]
	logger.debug("alias_keys:- \"{}\"".format(alias_keys))

	# FirstName,LastName,DOB,Address,City,State dictionary 
	data_keys = OrderedDict()
	print(data_keys)
	
	# reading all keys from the config file
	for key in config["data_keys"]["keys"]:
		data_keys[key] = None
	print(data_keys)
	
	# reading the starting info of all the lines, which would be ignored
	ignore_lines_starter = config["ignore_lines"]["starting_with"]
	logger.debug("would be ignoring lines starting with {}".format(ignore_lines_starter))

	ignore_lines_starter_ender = config["ignore_lines"]["starting_and_ending_with"]
	logger.debug("would be ignoring lines startong and ending with {}".format(ignore_lines_starter_ender))

	# would be grouping the info based on the the delimirer here  
	delimiter = config["delimiter"]
	logger.debug("would be separating the info using the deleimiter \"{}\"".format(delimiter))

	multi_line_join_brackets = config["join_multi_line_data"]
	logger.debug("would be joining multi-line information with opening brackets \"{}\" and Closing brackets \"{}\"".format(multi_line_join_brackets["opening_brackets"],multi_line_join_brackets["closing_brackets"]))
	# print("hello {} world {}".format(5,"there"))

	# looping over the information which has been provided
	for data_chunks in get_extratced_data_chunk(input_file, ignore_lines_starter, ignore_lines_starter_ender, delimiter):
		logger.debug("Extracted a group of information {}".format(data_chunks))
		# extract the information from the data and save them in data_keys  
		Record.extract(data_chunks,data_keys,multi_line_join_brackets, separators, alias_keys, write=False)

	logger.debug("all keys that have been extracted till now")
	logger.debug(data_keys.keys())

	# writng all the fields which have been extracted above
	logger.debug("writing all the column names in the file")
	with open(output_file,"w") as f:
		f.write(",".join(data_keys.keys())+"\n")

	# looping over the information which has been provided
	for data_chunks in get_extratced_data_chunk(input_file, ignore_lines_starter, ignore_lines_starter_ender, delimiter):
		logger.debug("Extracted a group of information {}".format(data_chunks))
		# extract the information from the data and save them in data_keys and sace save information in the file
		Record.extract(data_chunks,data_keys,multi_line_join_brackets, separators, alias_keys, write=True,output_file=output_file)

# # opening the input file to read data
# with open(input_file,"r") as f:
# 	# iterating through the lines of files
# 	for row in f:

# 		# ignore lines starting with "--" or "==" or if the lines is blank
# 		if(row.strip().startswith("--") or row.strip().startswith("==") or len(row.strip())==0):
# 			continue

# 		# if a line starts with "~~" and all the lenght of data >0, 
# 		# then information would be extarcted from data
# 		if(row.strip().startswith("~~") and len(data)>0):
# 			# data would be extracted and in this case we would be writing data to output file
# 			print(data)
# 			extract(data,data_keys,write=True)	
		
# 		# if line is valid and has content, then it is added to data list
# 		data.append(row.strip(strip_punctuation))
	
# 	# this is a way to hanlde the last line of data, since we won't be having "~~" at the end, 
# 	# so, when we reach the end, then last line of data would be extarted   
# 	extract(data,data_keys,write=True)
	