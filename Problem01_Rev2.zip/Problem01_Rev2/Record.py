from string import punctuation
import logging 

# punctuations to be stripped off from the string ... normal punctuations + empty space
strip_punctuation = punctuation + " "

class Record:
    @staticmethod
    def join_multiline_data(data, opening_brackets, closing_brackets):
        """
            input: 
                data: A list of strings
                opening_brackets: a set of opening brackets
                closing_brackets: a set of closing brackets
            operation:
                # In the lsit of strings, if single line is spread across multiple indexes 
                # but is surrounded by bracktets then, all that is joined to form a single string
                # For eg:- 
                #     This list ["word1 word2","word3 (word4","word5","word6","word7)"] is converted to 
                #     ["word1 word2","word3 (word4 word5 word6 word7)"]
                - defined {new_data} to be an empty list .... which would contain 
                - {count} variable ... to count the number of opening and cliosing brackets
                - for each row in {data}
                    - if {count} > 0
                        - add the row with the previous row
                    - else
                        - add the row as a new row in {new_data}
                    -  for each charavcter in the row
                        - if the character is present in thne set of opeing brackets 
                            - increment count 
                        - if the chanageter is present in the set of closing brackets
                            - decrement the count 
                - return the {new_data} 
            returns:
                new_data:  a list of all joined string which is spread across multiple lines
        """
        logger = logging.getLogger()


        #  output list 
        new_data = []
        
        # count variable to count the no. of opening and closing brackets
        count = 0

        # itegrate over the lsit of data 
        for row in range(len(data)):	

            # if count>0 means ... some bracket is open ... so data would be 
            # appended to the previous string only
            if(count>0):
                logger.debug(" joining \"{}\" with the previous element.".format(data[row]))
                if(len(new_data)>0):
                    new_data[-1]+=" "+data[row].strip()
                    # -1 is the last lement of a list 
                else:
                    new_data.append(data[row].strip())
            # if count<=0 then no bracket is open 
            else:
                logger.debug("adding a separate element to the list \"{}\" .".format(data[row]))
                new_data.append(data[row].strip())

            # iterate over all characters 
            for char in range(len(data[row])):

                # check if there is any opening bracket and increase count
                if(data[row][char] in set(opening_brackets)):
                    count+=1
                    logger.debug("found an opening bracket in \"{}\" which is \"{}\" so increasing the count to {}.".format(data[row],data[row][char],count))
                    
                # check if there is any closing bracket and decrease count
                if(data[row][char] in set(closing_brackets)):
                    count-=1
                    logger.debug("found an closing bracket in \"{}\" which is \"{}\" so decrementing the count to {}.".format(data[row],data[row][char],count))
                    
        return new_data

    @staticmethod
    def add_data(data_keys,key,value):
        """
            input:
                data_keys: dictionary storing the data of a row
                key: key for which we want to add data
                value: value of the key which we want to add 
            operation:
                # What this function does is to assign a value to a given key in the data_keys dictionary.
                # Further, if the key does not exists, key is created first.
                # And special operation is done for "unknown" key, all the unknown values are appended in this key, separated by "~"
                - if key is not present in data_keys
                    - create the key and assign it the value of None
                - if the key is "unknown"
                    - if the value of "unknown" key is None or the length is 0
                        - assign the value directly to the key
                    - else
                        - add "~" to the value 
                        - then append the value to the original value 
                - else
                    - assign the value to the key
            returns:
                Nothing
        """

        logger = logging.getLogger()

        # check if key is not present in the dictionay, and create it if it dosen't exists
        if(key not in data_keys):
            logger.debug("addig a new key with the name \"{}\"".format(key))
            data_keys[key] = None
        
        # if we are adding value for "unknown" key, then all the values are added separated by "~" 
        # else assigning the value to the key
        
        # heloo world 
        # addres: nfjj
        # qwerty dfgfygfu

        # "unknown" => "hello world~qwerty dfgfygfu" 

        if(key=="unknown"):
            if(data_keys["unknown"]==None or len(data_keys["unknown"].strip(strip_punctuation))==0):
                data_keys["unknown"] = value
                logger.debug("key \"{}\" will have a value of \"{}\"".format(key,data_keys["unknown"]))
            else:
                data_keys["unknown"] = data_keys["unknown"].strip(strip_punctuation)+"~"+value
                logger.debug("key \"{}\" will have a value of \"{}\"".format(key,data_keys["unknown"]))
        else:
            data_keys[key] = value
            logger.debug("key \"{}\" will have a value of \"{}\"".format(key,data_keys["unknown"]))

    @staticmethod
    def extract_key_value_pairs_from_data(data_keys, new_data, separators):
        '''
            input:
                data_keys: the dictionary where we would be stroing all the processed information 
                new_data: the data after joining multiple lines
                separators: the list of speataratorn
            operation:
                - for each row in the new_data
                    - strip the punctionas and space 
                    - if the length after stripping is 0 
                        - ignore the row
                    - for each key in {data_keys}
                        - if key is present in row
                            - get the location of the key in the row 
                            - everything after theat index would be the value of the key
                            - break
                    - else
                        - for each sepaartor in the {separators} list
                            - check if the row contains  the separaotrs 
                                - then everything on the left of the sepaartor is the keys
                                - everything on the right would be the value
                                - add the key value pair to the data_keys
                                - break
                        - else
                            - append the row inkder the "unknown" column separated with "~"    
            output: None
        '''
        logger = logging.getLogger()

        # iterate across all the rows 
        for row in new_data:            
            if(row.strip(strip_punctuation)==0):
                continue

            # iterate across all the keys we have in data_keys 
            for key in data_keys:
                # ans check if any of the key from our dict is present in the row, if yes, then this would be added in the dictionary
                if(key.lower() in row.lower()):
                    record_key = key.lower().strip(strip_punctuation)

                    # key = "address"
                    # row = "complete address: usa"
                    record_value = row[row.lower().find(key.lower())+len(key.lower()): ].strip(strip_punctuation)
                    logger.debug("found a key value pair \"{}\":\"{}\"".format(record_key,record_value))
                    Record.add_data(data_keys, record_key, record_value)
                    break
            # if no key from our dictionary, then key is searched by locating a delimiter if any present 
            else:
                # iterating through every character of the row and check if it is a delimiter and separate according to it
                for i in range(len(row)):
                    if(row[i] in separators):
                        record_key = row[:i].lower().strip(strip_punctuation)
                        record_value = row[i+1:].strip(strip_punctuation)
                        logger.debug("creatign a new key .... with a key value pair \"{}\":\"{}\"".format(record_key,record_value))
                        Record.add_data(data_keys,record_key,record_value)
                        break
                # if no delimiter is found, it is added under UNKNOWN heading 
                else:
                    logger.debug("wasn't able to find a key value pair for \"{}\" ... so adding it under \"unknown\"".format(row))
                    Record.add_data(data_keys,"unknown",row.strip(strip_punctuation))
    
    @staticmethod
    def join_alias_keys(data_keys,alias_keys):
        '''
            input:
                data_keys: the dictionary where all the extarcted info has to be saved  
                alias_keys: a dictionary of simmilar keys where the key of the dictionary would be the main key and the aliases would be the  alternate keys
            operation:
                - if the key with "firstname" and "lastname" both keys are not present
                    - for each key in {data_keys}
                        - if "name" is present in any of the key name and the value of the key is not none 
                            - then try to spit it based on space
                            - first name would be the first element of the list 
                            - last name would be the everythin after the first name
                            - original key would be deleted  
                - for all the keys defined in alias_keys
                    - for all the simmilar keys of this alias key
                        - check if the alias key is present and has some value 
                        - assign the value of the alias key to the original key
                        - delete the original key  
            output: None
        '''

        #  if "firstname" and "lastname" are None and we got some other field which contains "name" in it
        if(data_keys["firstname"]==None and data_keys["lastname"]==None):
            for key in data_keys:
                # if "name" is found in the key

                # completename: "Sagar Kumar Sehgal"
                if("name" in key.lower() and data_keys[key]!=None):
                    # splitted into firstname and lastname

                    name = data_keys[key].split()
                    # name = ["Sagar","Kumar","Sehgal"]
                    # name[:1] = ["Sagar"] => 
                    # name[1:] = ["Kumar","Sehgal"] => "Kumar Sehgal"
                    
                    # this is done to handle the case when we would be having name longer than 2 words
                    data_keys["firstname"], data_keys["lastname"] = " ".join(name[:1]), " ".join(name[1:]) 
                    
                    # further that key is deleted
                    # completename
                    del data_keys[key] 
                    break

        # if "date of birth" key is found, then it is deletd and its value is put to "dob" key
        for key in alias_keys:
            for simmilar_key in alias_keys[key]:
                if(simmilar_key in data_keys and data_keys[simmilar_key]!=None): 
                    data_keys[key] = data_keys[simmilar_key]
                    del data_keys[simmilar_key]

        # if("date of birth" in data_keys and data_keys["date of birth"]!=None):
        #     data_keys["dob"] = data_keys["date of birth"]
        #     del data_keys["date of birth"] 


    # "go to", "to delhi"
    # unknown = None
    # unknown = "go to"
    # unknown = "go to ~ to delhi"

    @staticmethod
    def processData(data,data_keys, multi_line_join_brackets, separators, alias_keys):
        """
            input: 
                data: A list of strings, which constitute data for a single row in the final table
                data_keys: Dictionary to store this data
                multi_line_join_brackets: brackets which would be using for joining multi line information
                separators: separators which can separate between key and values
            operation:
                # First of all data spread across multiple lines is joined to bring them to single line.
                # Then for all the lines, it is checked if any of the already present key is present in that data
                # Else, some from some speacial sybols, it is checked if we can sepatrate it b/w key and value, and if possible, new keys are added  
                # else, data is added under the "unknown" category
                - get the list of opening bracktets 
                - get the list of closing brackets
                - join content of mutiple line of data .. to a single line 
                - extarct keys and values from the info and assign it to the data keys
                - join data from silliar keys  
            returns:
                nothing is returned 
        """
        logger = logging.getLogger()

        # join data spread across multiple lines but surrounded by brackets 
        opening_brackets = multi_line_join_brackets["opening_brackets"]
        closing_brackets = multi_line_join_brackets["closing_brackets"]
        new_data = Record.join_multiline_data(data, opening_brackets, closing_brackets)

        Record.extract_key_value_pairs_from_data(data_keys,new_data, separators)
        
        # joining simmilar keys 
        Record.join_alias_keys(data_keys,alias_keys)

    @staticmethod
    def write_data(l,output_file):
        """
            input:
                l: list to write in the CSV output file .. .this would form 1 single row in the file 
                output_file: where we would be writing the extracted info 
            operation:
                # Writes a list, 
                # by replacing the None with empty string
                # and surrounding string with (""), so that elements can contain (,) inside it and it won't affect the CSV file 
                - for each element in the list 
                    - if the element is None 
                        - replace the elemtn with empty string ""
                    - else
                        - convert the element to string and surround the string with " and "
                - {valid_line} initialize this to False ... to detect empty lines
                - for each element in the list 
                    - if the lenght of the element is > 0   
                        - valid_line  would become True permanetly 
                        - break
                - if the line is not an empty line i.e. {valid_line} is True 
                    - write the list as a singe line in the file 
                    - end it with "\n"
            ouput:
                Nothing
        """
        # iterate over the list
        for i in range(len(l)):
            # if none, replace it with ""
            if(l[i]==None):
                l[i] = "\"\""
            # surrounding it with (""), so that (,) can be present in the text 
            else:
                l[i] = "\"" + str(l[i]) + "\""

        # check if the line is empty
        # l= ["","","","",""]
        valid_line = False        
        for i in range(len(l)):
            if(l[i]!=None and len(l[i].strip(strip_punctuation))>0):
                valid_line = True
                break

        # print(empty_line,l)

        if(valid_line):
            # would write the line only if the line is non-empty
            # appending the data to the file
            with open(output_file,"a") as f:
                f.write(",".join(l)+"\n")


    @staticmethod
    def extract(data, data_keys, multi_line_join_brackets, separators, alias_keys, write=False, output_file=None):
        """
            input:
                data: list conating all the lines 
                data_keys: a dictionary containing all the keys
                multi_line_join_brackets: brackets which would be using for joining multi line information
                write: True/False, based on wheter the resultant dictinary with key value pairs has to be written in file or not 
                output_file: The name of the file where we would be writing out output 
            operation:
                # processes the complete data and writes if requried
                # furter, after completion of operation, it clears the list and the dictionary so that its ready to insert new values 
                - process the data and save the info in {data_keys}
                - if allowed to write
                    - write all the values of the keys
                - for each key in {data_keys}
                    - set the value of all keys to be None
                - empty the list {data} which kept all the string   
            returns:
                Nothing
        """

        logger = logging.getLogger()
        
        # processing of complete data 
        Record.processData(data,data_keys,multi_line_join_brackets, separators, alias_keys)
        
        if(write==False):
            logger.info("Extracted data keys till now:- \"{}\"".format(data_keys.keys()))
        else:
            logger.debug("Data keys info extracted:- \"{}\"".format(data_keys))
        
        # if write=True, we would be writing the data to the file
        if(write):
            l = list(data_keys.values())
            Record.write_data(l,output_file)
            logger.debug("completed writing \"{}\" to the file \"{}\".".format(l,output_file))
            
        # once the complete data has been extracted, all the values of the dictionary are put to None
        for key in data_keys:
            data_keys[key]=None
        # once the complete data has been extracted, list is also cleared t be emplye
        data.clear()
        logger.debug("refreshed the data_keys dictionary and all the data which was extarcted")