char* FindAllSubStrings(char *Src, char *LB, char *RB, char *buff, char checking[12])
{

//    char buff[1000], temp[100];
    char temp[100];
    char *pos1, *pos2;
    int offset, i=0;
    char * LRParam = "TestData";

    /*
    			"hello world how are you Hello world how good you"
    			LB = how
    			RB = you
    			buff = are
    			
    			"Testdat_1" ->" are"
    			
    			buff = good
    			"Testdata_2" -> "good"
    */
    
    // Capture the position of Left boundary
    pos1 = (char *)strstr(Src, LB);
 
    //If the RB and LB both are the same, ensure that you search for RB only after LB
    if(pos1 !=0)
        {
            pos2 = (char *)strstr(pos1 + strlen(LB), RB);
        }
    
    do
    {
        // Make Buff an empty string
        strcpy(buff, "");
     
        // Should return only if both Pos1 and Pos2 are not null
        if(pos1 !=0 && pos2 !=0)
        {
            //Measure the length of the string that is to be saved into the LR parameter
            offset = (int)(pos2 -(pos1+strlen(LB)));
         
            //Save the sub string into the buff variable
            strncat(buff, pos1+strlen(LB), offset);
            i++;
            //Create the LR parameter for example "TestData_i" where i will be incremented wtih each iteration
            sprintf(temp, "%s_%d",LRParam,i);
           // lr_output_message("******FindAllSubStrings =========== %s_%d", LRParam,i);
    
            //Save the sub string into the parameter "TestData_i"
            lr_save_string(buff, temp);
            lr_output_message("** %s_%d : %s", checking, i, buff);
         
            //change the pointer from where you should look for the next LB and RB
            Src = (char *)(pos2 + strlen(RB));
         
        }
        pos1 = (char *)strstr(Src, LB);
        if(pos1 !=0)
        {
            pos2 = (char *)strstr(pos1 + strlen(LB), RB);
        }
        //Repeat the process until all the values are stored to the LR parameters
     
    }while(pos1 !=0 &&pos2!=0);
 
    //Create an LR parameter that stores the count of sub strings for example "TestData_count"
    sprintf(temp, "%s_count", LRParam);
    //Save the count into the created parameter
    lr_save_int(i, temp);
    //lr_output_message("******************************************************************************************************************FindAllSubStrings =========== %s", buff);
     
    return 0;
}