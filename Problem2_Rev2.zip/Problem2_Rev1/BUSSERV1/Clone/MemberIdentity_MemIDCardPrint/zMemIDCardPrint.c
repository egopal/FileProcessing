/*
//--------------------------------------------------------------------------------------------------------------------/
	BRIEFLY DESCRIBE SCRIPT FUNCTIONALITY
    PLEASE ADD ANY COMMENTS/OBSERVATIONS RELATED TO THE SCRIPT YOU ARE WORKING ON, WE CAN TAKE ACTION BASED ON COMMENTS
//---------------------------------------------------------------------------------------------------------------------/
*/

zMemIDCardPrint(){
	
	
	//*---------------------------------------------------------------------------------------------------------------------/
	//[1] Environment and Auth Variables
    //*---------------------------------------------------------------------------------------------------------------------/

	if(strcmp(lr_eval_string("{AIP_Automation_AuthEnabled}"),"Yes") == 0){
     
		InvokeAuthService();

    	// Responses captured from Auth Call saved into Variables, Disable the ones that are not applicable to the JSON
    	// These are captured from the InvokeAuthService().   Use  them if needed, if going LTPA route. 
    	// We capture these values from InvokeAuthService() response and use them here if needed in the business service
    	// These ariables are declared if needed for the body of the request; taken from the authenticate call.
    	lr_save_string(lr_eval_string("{Auth_LTPA}"),"Auth_LTPA_val");
        lr_save_string(lr_eval_string("{Auth_birthDate}"),"Auth_BirthDate_val");
        lr_save_string(lr_eval_string("{Auth_mbrNum}"),"Auth_MbrNum_val");
        lr_save_string(lr_eval_string("{Auth_groupNumber}"),"Auth_GroupNumber_val");
        lr_save_string(lr_eval_string("{Auth_memberIdentifier}"),"Auth_MemberIdentifier_val");
        lr_save_string(lr_eval_string("{Auth_userId}"),"Auth_UserId_val");
        lr_save_string(lr_eval_string("{Auth_memberSuffix}"),"Auth_MemberSuffix_val");
        
    }
  
    //*---------------------------------------------------------------------------------------------------------------------/
    //[2] ENRICH DATA AND SET PARAM VALUES - We will be using lr_save_string to save the param value to support 12.60 JSON 
    //*---------------------------------------------------------------------------------------------------------------------/

    	// JSON HEADER - MODIFY ONLY IF THE SERVICENAME PARAM IS DIFFERENT
    	
	   	lr_save_string(lr_get_host_name( ),"hostName_val");
		lr_param_sprintf ("transId_val", "%s-%s%s", lr_eval_string("{AIP_ServiceName}"), lr_eval_string("{Sys_VUserID}"), lr_eval_string("{Sys_Iteration}"), 40);				
 		lr_save_string(lr_eval_string("{Sys_DateTime}"),"requestDateTime_val");
		
    
		// JSON BODY - MODIFY HERE - DEFINE REQUIRED DATA PARAMETERS AND ASSIGN AS *_val
    	// declare variables here that are needed for the body request  
    	//lr_save_string(lr_eval_string("{JBody_DataParam}"),"DataParam_val");
    	
    	
	//*---------------------------------------------------------------------------------------------------------------------/
    //[3] Load JSON or Get JSON from FilePath or Define JSON
  	//*---------------------------------------------------------------------------------------------------------------------/
 	
  		//ADD CORRECT JSON
  		//HEADER - RETAIN PARAM VALUES (requestDateTime_val, hostName_val, transId_val), REQUIRED FOR TRANSACTION ANALYSIS
  		//BODY   - REPLACE DATA PARAM VALUES WITH *_val HERE
  		
  		request_json_base=
"{"
"    \"requestHeader\": {"
"        \"consumer\": {"
"            \"name\": \"member_portal\","
"            \"id\": \"1234\","
"            \"businessUnit\": \"SrMarket\","
"            \"type\": \"Member Services\","
"            \"clientVersion\": \"V1\","
"            \"requestDateTime\": \"{requestDateTime_val}\","
"            \"hostName\": \"{hostName_val}\","
"            \"businessTransactionType\": \"read\","
"            \"contextId\": \"print id card\","
"            \"secondContextId\": \"\","
"            \"thirdContextId\": \"\""
"        },"
"        \"credentials\": {"
"            \"userName\": \"AUSERNAME\","
"            \"password\": \"APSWD\","
"            \"token\": \"eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJTZXJ2aWNlRGVza3RvcF9CbHVlc2hpZWxkQ0EiLCJpYXQiOjE0OTQyODY0NTMsInN1YiI6IkJsdWUgU2hpbGVkIG9mIENhbGlmb3JuaWEiLCJpc3MiOiJCbHVlc2hpZWxkQ0EiLCJleHAiOjE0OTQ1MDU0NTN9.7Pds-xLnZXkt7eWMhMSUyt0KQZmgNsrL8RMrUUENZCk\","
"            \"type\": \"JWT\""
"        },"
"        \"transactionId\": \"AIP_Mem_IDCardPrint_0010001\""
"    },"
"    \"requestBody\": {"
"        \"planMemberIdentifier\": {"
"            \"planMemberIdentifier\": \"W0052236|902507615|00|MAPD\","
"            \"planMemberIdentifierType\": \"GRPID_SUBID_SFX_MBRTYPE\""
"        }"
"    },"
"    \"transactionId\": \"{transId_val}\""
"}";


		// PLEASE DO NOT MODIFY - RESOLVING THE REQUEST CONTRACT
	    lr_save_string(lr_eval_string(request_json_base), "REQUEST_JSON_PARAM");

	    	    
 	//*---------------------------------------------------------------------------------------------------------------------/
 	//[4] RESPONSE ASSERTIONS FOR TEST ANALYSIS
	//*---------------------------------------------------------------------------------------------------------------------/

		// RESPONSE DATA - PLEASE DO NOT MODIFY
		
	    web_reg_save_param_ex("ParamName=ResponseHttp", "LB=", "RB={\"responseHeader\":{\"", LAST);
		
	    web_reg_save_param_ex("ParamName=ResponseJSON", "LB=", "RB=", SEARCH_FILTERS, "Scope=Body", LAST);

		// RESPONSE JSON - HEADER VALIDATION - RETAIN SuccessCount and WarningCount
		
	    web_reg_find("Text=\"status\":\"SUCCESS\"", "SaveCount=SuccessCount", "LAST" );		
  
		web_reg_find("Text=\"status\":\"WARNING\"", "SaveCount=WarningCount", "LAST" );
	
		// RESPONSE JSON - MODIFY BODY VALIDATION TEXT/VALUE - RETAIN PayLoadCount.
		// ADD ADDITIONAL VALIDATIONS - NAME IT RELEVANT TO THE OBJECT, say PayloadClaims, etc.
		
        web_reg_find("Text=\"renewalQuestions\":", "SaveCount=PayloadCount", LAST );
		
		
  	//*---------------------------------------------------------------------------------------------------------------------/
    //[5] SERVICE REQUESTS
    //*---------------------------------------------------------------------------------------------------------------------/
    
	   
	   	if(strcmp(lr_eval_string("{AIP_Automation_AuthEnabled}"),"Yes") == 0){
     
			// PLEASE DO NOT MODIFY
		    // ***For Member APIC Requests needed for APIC Pass Through Req with no LTPA Token:
	    	// Member Client ID and Secret for Member (MPO Portal)
    		// Required Headers for LTPA request with Authentication call
    		// ***For Member APIC Requests needed for LTPA Auth Request:
    		// LTPA Token
    		// Mmeber Data validation
    		// Member Client ID and Secret

    		web_add_header("x-ibm-client-id", "{AIP_AuthClientId}");
		    web_add_header("x-ibm-client-secret", "{AIP_AuthClientSecret}");
		    
		    web_add_header("X-BSC-LTPA-Token", "{Auth_LTPA_val}"); 
			web_add_header("mbrNum", "{Auth_MemberIdentifier_val}");
			web_add_header("birthDate", "{Auth_BirthDate_val}");
		}
    	else {		
    		web_add_header("x-ibm-client-id", "{AIP_EnvClientId}"); 
	   		web_add_header("x-ibm-client-secret", "{AIP_EnvClientSecret}"); 
		}
		
	
   		web_add_header("Content-Type", "application/json");
	
    
	    lr_save_string(lr_eval_string("{Sys_DateTime}"),"requestTime");
	
		
		// YOU MAY NEED TO INPUT CORRECT SERVICENAME PARAM WHEN THERE ARE MORE THAN ONE TRANSACTIONS
    	
		lr_start_transaction(lr_eval_string("{AIP_ServiceName}"));
			
		web_custom_request(lr_eval_string("{AIP_ServiceName}"),
	  		"URL={AIP_EnvServer}{AIP_EnvServerPath}{AIP_ServiceURL}",
	       	"Method=POST",
	     	"Mode=HTTP",
	     	"EncType=application/json",
	 	   	"Body={REQUEST_JSON_PARAM}",
     	LAST);
		
		transDuration = lr_get_transaction_duration(lr_eval_string("{AIP_ServiceName}"));

		
	//*---------------------------------------------------------------------------------------------------------------------/
    //[6] TRANSACTION PASS/FAIL DECISION CRITERIA
    //*---------------------------------------------------------------------------------------------------------------------/
  
		// ALL THE THREE CRIERIA IS MANDATORY, ADD ADDITIONAL VALIDATION WHEN NEEDED
		
		if ( (atoi(lr_eval_string("{SuccessCount}")) > 0 || atoi(lr_eval_string("{WarningCount}")) > 0 ) && ( atoi(lr_eval_string("{PayloadCount}")) > 0 ) ) {
	      	lr_end_transaction(lr_eval_string("{AIP_ServiceName}"), LR_PASS);
	    	transStatus ="PASS";
	    } else {
	    	lr_end_transaction(lr_eval_string("{AIP_ServiceName}"), LR_FAIL);
	    	transStatus ="FAIL";
	    }
		
		
	//*---------------------------------------------------------------------------------------------------------------------/
 	//[7] LOGGING - FOR EVERY TRANSACTIONS - DO NOT ENABLE UNLESS YOU WANT TO TRY THIS OUT - DISABLE WHILE RUNNING ACTUAL TESTS
    //*---------------------------------------------------------------------------------------------------------------------/
    	
    //   YOU MAY NEED TO INPUT CORRECT SERVICENAME PARAM WHEN YOU ADD MORE THAN ONE SERVICES IN THE SCRIPT
    	
     ResponseAnalysis( lr_eval_string("{transId_val}"), lr_eval_string("{AIP_ServiceURL}"), lr_eval_string("{SuccessCount}"), lr_eval_string("{PayloadCount}"), lr_eval_string("{requestTime}"), lr_eval_string(request_json_base), transStatus, transDuration);

	//*======================================================================================================================
	
	
	return 0;
	 
}