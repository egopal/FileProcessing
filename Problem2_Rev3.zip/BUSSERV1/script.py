import os 
import shutil
import json

def backup(source):
    for folder in os.listdir(source):
        if os.path.isdir(os.path.join(source,folder)):
            shutil.make_archive(os.path.join(source,folder),"zip",os.path.join(source,folder))
            print("BACKUP OF {} COMPLETED ".format(os.path.join(source,folder)))
        else:
            print("NOT A FOLDER TO BACKUP: {}".format(os.path.join(source,folder)))

def data_formatting(data_keys):
    if(data_keys["Test Operation Name"]!=None and data_keys["Test Method Name"]==None):
        data_keys["Test Method Name"] = data_keys["Test Operation Name"]
    
    if(data_keys["JVM"]!=None and data_keys["Container"]==None):
        data_keys["Container"] = data_keys["JVM"].strip()
    
    if(data_keys["ServicesEndPoint URL"]!=None and data_keys["ServicesEndPointURL"]==None):
        data_keys["ServicesEndPointURL"] = data_keys["ServicesEndPoint URL"].strip()

    if(data_keys["Other Header Info"]!=None):
        l = data_keys["Other Header Info"].split(",")
        data_keys["ClientID"] = "".join(l[:1]).strip() 
        data_keys["ClientSecret"] = ",".join(l[1:]).strip()
        if(data_keys["ClientSecret"].split(":")[0] == "ClientSecret"):
            data_keys["ClientSecret"] = ":".join(data_keys["ClientSecret"].split(":")[1:])
        
    if(data_keys["ServicesEndPointURL"]!=None and ":" in data_keys["ServicesEndPointURL"]):
        l = data_keys["ServicesEndPointURL"].split(":")
        data_keys["ServiceType"] = l[0].strip()
        data_keys["ServiceName"] = ":".join(l[1:-1])
        port = False
        if(l[-1].split("/")[0].strip().isnumeric()):
            port = True
            data_keys["ServiceName"] += ":"+l[-1].split("/")[0].strip()
        try:
            if(port):
                new_l = l[-1].split("/")[1:]
            else:
                new_l = l[-1].split("/")
            
            bsc_index = new_l.index("bsc")
            data_keys["ServicePath"] = "/"+"/".join(new_l[:bsc_index]).strip()
            data_keys["ServiceURL"] = "/"+"/".join(new_l[bsc_index:]).strip()
        except:
            print("BSC was not found in ServicesEndPointURL")

    if(data_keys["Request JSON"]!=None):
        data_keys["Request JSON"] = json.loads(data_keys["Request JSON"])
    
    if(data_keys["Response JSON"]!=None):
        data_keys["Response JSON"] = json.loads(data_keys["Response JSON"])


def edit_file(file_name,prev_text,new_text):
    temp_file = "temp.txt"
    with open(file_name,"r") as f:
        with open(temp_file,"w") as f1:
           for i in f:
                f1.write(i.replace(prev_text,new_text))
    os.remove(file_name)
    os.rename(temp_file,file_name)

def step_2(data_keys):
    global current_directory
    global targetDir 
    global targetScriptName
    global srcRootPath
    global targetRootPath

    targetRootPath = os.path.join(current_directory,"Clone")
    targetDir = data_keys["Test Suite Name"]+"_"+data_keys["Test Method Name"]
    targetScriptName = data_keys["Test Method Name"]

def step_3(data_keys,sd):

    global targetRootPath
    global targetDir
    global targetScriptName

    if(data_keys["Auth URL"].strip().endswith("test.htm")):
        srcDir = os.path.join(srcRootPath,"testing")
    else:
        srcDir = os.path.join(srcRootPath,sd)
    print("sd:",sd)
    print("srcDir:",srcDir)
    # TODO This srcDir needs to be cleaned as given on the top (First 19 lines of this doc explains that)

    try:
        shutil.copytree(srcDir, os.path.join(targetRootPath,targetDir))
    except:
        print(os.path.join(targetRootPath,targetDir),"already exisists")

def step_4(data_keys,sd):

    global targetRootPath
    global targetDir
    global targetScriptName

    filesEndingWith = [".usr",".prm"]
    for f in os.listdir(os.path.join(targetRootPath,targetDir)):
        for e in filesEndingWith:
            if(f.endswith(e)):
                os.rename(os.path.join(targetRootPath,targetDir,f),os.path.join(targetRootPath,targetDir,targetDir+"."+f.split(".")[-1]))


    l = [sd+".c",sd+"_W.dat", sd+"_F.dat", sd+"_W.sql", sd+"_F.sql", "z"+sd+".c", "z"+sd+".json"]
    for i in l:
        try:
            os.rename(os.path.join(targetRootPath,targetDir,i),os.path.join(targetRootPath,targetDir,i.replace(sd,targetScriptName))) 
        except:
            print("NO SUCH FILE:",os.path.join(targetRootPath,targetDir,i))

    edit_file(os.path.join(targetRootPath,targetDir,targetDir+".prm"),sd,targetScriptName)
    


    # conditon which was asked to add .... point 4 in TO-DO

    data = []
    with open(os.path.join(targetRootPath,targetDir,"AIP_Automation.dat"),"r") as f:
        for i in f:
            data.append(i.strip().split(","))
    
    auth_enabled = None
    for i in range(len(data[0])):
        if(data[0][i]=="AuthEnabled"):
            auth_enabled = data[1][i]
    
    if(auth_enabled!=None and auth_enabled.strip().lower()=="yes"):
        auth_url = data_keys["Auth URL"]
        req_line = None
        
        with open(os.path.join(targetRootPath,targetDir,"AIP_Auth_MemAuth.h"),"r") as f:
            start = False
            for line in f:
                if("[1]" in line):
                    start = True
                    pass
                if("[2]" in line):
                    start = False
                if(line.strip().startswith("//")==False and start==True):
                    if('"AIP_AuthServer"' in line):
                        req_line = line
        
        if(req_line!=None):
            url = req_line.split('"')[1]
        
        print("----------------------------------------------")
        if(url!=auth_url):
            print("AUTH URL DOES NOT MATCH WITH THE URL IN {} FILE. THE AUTH URL IS :{}".format(os.path.join(targetRootPath,targetDir,"AIP_Auth_MemAuth.h"),auth_url))
        else:
            print("AUTH URL MATCHES URL IN FILE")

def step_5(data_keys,sd):
    
    global targetRootPath
    global targetDir
    global targetScriptName

    edit_file(os.path.join(targetRootPath,targetDir,"default.usp"),sd,targetScriptName)
    for f in os.listdir(os.path.join(targetRootPath,targetDir)):  
        if(f.endswith(".usr")):
            # ParameterFile=AIP_Mem_Profile.prm
            edit_file(os.path.join(targetRootPath,targetDir,f),"ParameterFile={}.prm".format(sd),"ParameterFile={}.prm".format(targetDir))
            edit_file(os.path.join(targetRootPath,targetDir,f),sd,targetScriptName)
    edit_file(os.path.join(targetRootPath,targetDir,"z"+targetScriptName+".c"),sd,targetScriptName)
    

def step_6a(data_keys):

    global targetRootPath
    global targetDir
    global targetScriptName

    with open(os.path.join(targetRootPath,targetDir,"AIP_Automation.dat"),"r") as f:
        data = []
        for line in f:
            data.append(line.split(","))
    for i in range(len(data[0])):
        if(data[0][i].strip().lower()=="ScriptName".strip().lower()):
            data[1][i] = targetScriptName
        if(data[0][i].strip().lower()=="AuthEnabled".strip().lower()):
            if(len(data_keys["Auth URL"].strip())==0):
                data[1][i] = "No"
        if(data[0][i].strip().lower()=="ServiceComponentName".strip().lower()):
            data[1][i] = data_keys["Test Suite Name"]
    with open(os.path.join(targetRootPath,targetDir,"AIP_Automation.dat"),"w") as f:
        f.write(",".join(data[0]))
        f.write(",".join(data[1]))

def step_6c(data_keys):

    global targetRootPath
    global targetDir
    global targetScriptName
    
    data = []
    with open(os.path.join(targetRootPath,targetDir,"AIP_Env.dat"),"r") as f:    
        for line in f:
            data.append(line.split(","))
    
    for i in range(len(data[0])):
        if(data[0][i].strip().lower()=="Env".strip().lower()):
            if("bscedh1000" in data_keys["ServicesEndPointURL"]):
                data[1][i] = "APIConnect"
            elif("esbhdp-api.bsc.bscal.com" in data_keys["ServicesEndPointURL"]):
                data[1][i] = "Stage_DP"
        
        if(data[0][i].strip().lower()=="Server".strip().lower()):
            try:
                http_loc = data_keys["ServicesEndPointURL"].index("http")
                com_loc = data_keys["ServicesEndPointURL"].index("com")
                start = http_loc
                end = com_loc+len("com")
                if(data_keys["ServicesEndPointURL"][end]==":"):
                    # port is present
                    end+=1
                    while(end<len(data_keys["ServicesEndPointURL"]) and data_keys["ServicesEndPointURL"][end].isnumeric()):
                        end+=1
                data[1][i] = data_keys["ServicesEndPointURL"][start:end]
            except:
                print("NO HTTP,COM in the ServicesEndPointURL")
        
        if(data[0][i].strip().lower()=="ServerPath".strip().lower()):
            try:
                com_loc = data_keys["ServicesEndPointURL"].index("com")
                start = com_loc+len("com")
                if(data_keys["ServicesEndPointURL"][start]==":"):
                    # port is present
                    start+=1
                    while(start<len(data_keys["ServicesEndPointURL"]) and data_keys["ServicesEndPointURL"][start].isnumeric()):
                        start+=1
            except:
                start = 0
            end = data_keys["ServicesEndPointURL"].index("/bsc")
            data[1][i] = data_keys["ServicesEndPointURL"][start:end]
        
        if(data[0][i].strip().lower()=="ClientID".strip().lower()):
            data[1][i] = data_keys["ClientID"]
        
        if(data[0][i].strip().lower()=="ClientSecret".strip().lower()):
            data[1][i] = data_keys["ClientSecret"]
    
    with open(os.path.join(targetRootPath,targetDir,"AIP_Env.dat"),"w") as f:
        f.write(",".join(data[0]))
        f.write(",".join(data[1]))

def step_6b(data_keys):

    global targetRootPath
    global targetDir
    global targetScriptName
    
    data = []
    with open(os.path.join(targetRootPath,targetDir,"AIP_Service.dat"),"r") as f:    
        for line in f:
            data.append(line.split(","))
    
    for i in range(len(data[0])):
        if(data[0][i].strip().lower()=="Container".strip().lower()):
            data[1][i] = data_keys["Container"]
        if(data[0][i].strip().lower()=="ServiceName".strip().lower()):
            data[1][i] = targetScriptName 
        if(data[0][i].strip().lower()=="ServiceURL".strip().lower()):
            if("ServiceURL" in data_keys and data_keys["ServiceURL"]!=None):
                data[1][i] = data_keys["ServiceURL"]
            else:
                data[1][i] = data_keys["ServicesEndPointURL"] 
        if(data[0][i].strip().lower()=="JSONFileName".strip().lower()):
            data[1][i] = targetScriptName +".json"
        if(data[0][i].strip().lower()=="TestMethodName".strip().lower()):
            data[1][i] = targetScriptName

    with open(os.path.join(targetRootPath,targetDir,"AIP_Service.dat"),"w") as f:
        f.write(",".join(data[0]))
        f.write(",".join(data[1]))

    
def step_7(data_keys):

    global targetRootPath
    global targetDir
    global targetScriptName
    
    with open(os.path.join(targetRootPath,targetDir,targetScriptName+".json"),"w") as f:
        json.dump(data_keys["Request JSON"], f,indent=4)
    
    data_keys["Request JSON"]["requestHeader"]["consumer"]["requestDateTime"] = "{requestDateTime_val}"
    data_keys["Request JSON"]["requestHeader"]["consumer"]["hostName"] = "{hostName_val}"
    data_keys["Request JSON"]["transactionId"] = "{transId_val}"

    new_request_list = json.dumps(data_keys["Request JSON"],indent = 4).split("\n")

    for i in range(len(new_request_list)):
        new_request_list[i] = new_request_list[i].replace("\"",'\\"')
        new_request_list[i] = '\"'+new_request_list[i].rstrip()+'\"'

    new_request_string = "\n".join(new_request_list)+";\n"

    with open(os.path.join(targetRootPath,targetDir,"z"+targetScriptName+".c")) as f:
        with open("temp_file.txt","w") as f1:
            stop = False
            for line in f:
                if(stop==False):
                    f1.write(line)
                if("request_json_base=" in line):
                    stop = True
                if(stop==True and ";" in line):
                    f1.write(new_request_string)
                    stop = False
    os.remove(os.path.join(targetRootPath,targetDir,"z"+targetScriptName+".c"))
    os.rename("temp_file.txt",os.path.join(targetRootPath,targetDir,"z"+targetScriptName+".c"))

def step_8(data_keys):

    global targetRootPath
    global targetDir
    global targetScriptName

    for file in os.listdir(os.path.join(targetRootPath,targetDir)):
        if(file.endswith("Automation.dat")):
            data = []
            with open(os.path.join(targetRootPath,targetDir,file),"r") as f:
                for line in f:
                    data.append(line.strip().split(","))

                for i in range(len(data[0])):
                    if(data[0][i]=="NFRVolume"):
                        break
                else:
                    data[0].append("NFRVolume")
                    data[1].append("5000")
            
            with open(os.path.join(targetRootPath,targetDir,file),"w") as f:
                f.write(",".join(data[0])+"\n")
                f.write(",".join(data[1]))
    
    all_files = os.listdir(os.path.join(targetRootPath,targetDir))
    for file_name in all_files:
        if(file_name.endswith("_W.dat")):
            if(file_name[:-6]+"_W.sql" not in all_files):
                print("No SQL Files found for {} the dat file that is found, ending with _W.dat or _F.dat".format(file_name)) 
        if(file_name.endswith("_F.dat")):
            if(file_name[:-6]+"_F.sql" not in all_files):
                print("No SQL Files found for {} the dat file that is found, ending with _W.dat or _F.dat".format(file_name))                        

def process_data(data_keys):
    
    data_formatting(data_keys)

    step_2(data_keys)    
    
    print("targetDir:",targetDir)
    print("targetScriptName:",targetScriptName)
    print("targetRootPath: ",targetRootPath)
    sd = "AIP_Mem_Profile"
    
    step_3(data_keys,sd)
    step_4(data_keys,sd)
    step_5(data_keys,sd)
    step_6a(data_keys)
    step_6c(data_keys)    
    step_6b(data_keys)
    step_7(data_keys)
    step_8(data_keys)


def refresh(data_keys):
    # print(data_keys)
    print(json.dumps(data_keys, indent=4))
    for key in data_keys:
        data_keys[key] = None

# ------------------------------------------------------------------------------------------------
# MAIN CODE

current_directory = "C:\Projects\workspacePython32\BSCPerf32\BUSSERV1"
catalogFileToRead = "TestCatalog1.txt" 
srcRootPath = os.path.join(current_directory,"Template")
targetDir = None
targetScriptName = None
targetRootPath = None

data_keys = {
    "Test Suite Name": None,
    "Test Method Name":None,
    "Test Operation Name": None,
    "Container": None,
    "JVM": None,
    "Auth URL": None,
    "Auth Token": None,
    "Other Header Info": None,
    "ServicesEndPointURL":None,
    "ServicesEndPoint URL": None,
    "Request JSON": None,
    "SQL Query for Data": None,
    "Response JSON": None,
    "SQL Query to validate the data":None,
    "Test Execution Status": None
}


backup(srcRootPath)

with open(os.path.join(current_directory,catalogFileToRead),"r") as f:
    prev = None
    for line in f:
        for key in data_keys:
            if(key.lower() in line.lower()):
                if(data_keys[key]!=None):
                    process_data(data_keys)
                    refresh(data_keys)
                data_keys[key] =  ":".join(line.split(":")[1:]).strip()
                prev = key
                break
        else:
            data_keys[prev] += line
    process_data(data_keys)
    refresh(data_keys)