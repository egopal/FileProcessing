vuser_end()
{
	
	
	/************************************************************************************************************************/
	/* https://grid.bsc.bscal.com/display/SDS/Employers+Manage+ProfilesAndPreferences+Service
	/*
	/*   "requestBody": {
    /*   "userIdentifier": "E7989"  -- valid user id value from active group
    /*    }
	/* 	JSON Headers:    OAUTH Token and CLient ID and Secret for EPO Services
	/*
	/*  JSON Body   :     requestDateTime = Date/Time param %Y-%m-%d %H:%M:%S:000
	/*                    token/jwt = eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJTZXJ2aWNlRGVza3RvcF9CbHVlc2hpZWxkQ0EiLCJpYXQiOjE0OTQyODY0NTMsInN1YiI6IkJsdWUgU2hpbGVkIG9mIENhbGlmb3JuaWEiLCJpc3MiOiJCbHVlc2hpZWxkQ0EiLCJleHAiOjE0OTQ1MDU0NTN9.7Pds-xLnZXkt7eWMhMSUyt0KQZmgNsrL8RMrUUENZCk\
	/*				      trasactionid = "transname_" + Date/Time param %Y%m%d%H%M%S000
	/*                    required fields = GROUP ID (from dat file), Group Name, Reporting Year, Num of Employees and Exception Flag
	/* 
	/*  Parameterization: Dat file creation: We query the data for the dat file for the User Profile Modification service from WPRS02.
	/*                 
	/* 	SQL Data:         Dat file created from query to WPRS02.  
	/*  
	/* 
	/************************************************************************************************************************/           	

	return 0;
}

/*
ADDITIONAL NOTES
 
   	strcpy(actualReqDT, lr_eval_string("{requestTime}"));    
	strcpy(payloadCount, lr_eval_string("{payload}"));
	snprintf(rtDuration, 10, "%2.4f", transDuration);
	ResponseAnalysis(transName, actualReqDT, request_json, transStatus, payloadCount, rtDuration);

*/