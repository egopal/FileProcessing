
InvokeAuthService()
{
	char *request_json_base;
	char *request_json;
	char *transStatus;
	char *hostName;
  	char *OAUTH_Token;
  	char newServiceName[25]="";
	double transDuration;
	
	//*---------------------------------------------------------------------------------------------------------------------/
	//[1] Environment and Auth Variables
    //*---------------------------------------------------------------------------------------------------------------------/
	
    	lr_save_string("AIP_Auth_MemAuth","AIP_AuthServiceName");

	    lr_save_string("https://esbs01dp-api","AIP_AuthServer");
    	lr_save_string("/private/stage","AIP_AuthServerPath");
    	lr_save_string("/api/bsc/gateway/member/authenticate/profile/v2","AIP_AuthServiceURL");

    	
    	lr_save_string("977bbd49-0195-4891-802e-7ce0f9a28c35","AIP_AuthClientId");
		lr_save_string("oB6sV0qU4mS3oW4jK8gC7nP2pO0fB4iE3jW8kI1gC7bC8tQ0uB","AIP_AuthClientSecret");
    	
		
    //*---------------------------------------------------------------------------------------------------------------------/
    //[2] ENRICH DATA AND SET PARAM VALUES - We will be using lr_save_string to save the param value to support 12.60 JSON 
    //*---------------------------------------------------------------------------------------------------------------------/

    	// JSON HEADER - MODIFY ONLY IF THE SERVICENAME PARAM IS DIFFERENT
 
    	lr_save_string(lr_get_host_name( ),"hostName_val");
	  	lr_param_sprintf ("transId_val", "%s-%s%s", lr_eval_string("{AIP_AuthServiceName}"), lr_eval_string("{Sys_VUserID}"), lr_eval_string("{Sys_Iteration}"), 40);	   	
 		lr_save_string(lr_eval_string("{Sys_DateTime}"),"requestDateTime_val");
 		
 		// JSON BODY
 		lr_save_string(lr_eval_string("{JBody_AuthMemLogin}"),"authUserName_val");
 		lr_save_string(lr_eval_string("{JBody_AuthMemPSWD}"), "authUserPwd_val");
 		
   	
 	//*---------------------------------------------------------------------------------------------------------------------/
    //[3] Load JSON or Get JSON from FilePath or Define JSON
  	//*---------------------------------------------------------------------------------------------------------------------/
  	  	   		
  		//DO NOT MODIFY UNLESS JSON CHANGED
  		//HEADER - RETAIN PARAM VALUES (requestDateTime_val, hostName_val, transId_val), REQUIRED FOR TRANSACTION ANALYSIS
  		//BODY   - REPLACE DATA PARAM VALUES WITH *_val HERE
  		
  		request_json_base=
						"{"
							"\"requestHeader\": {"
								"\"consumer\": {"
									"\"name\": \"MEMBER\","
									"\"id\": \"MEMBER\","
									"\"businessUnit\": \"CHANNELS\","
									"\"type\": \"INTERNAL\","
									"\"clientVersion\": \"V1\","
									"\"requestDateTime\": \"{requestDateTime_val}\","
									"\"hostName\": \"{hostName_val}\","
									"\"businessTransactionType\": \"AUTHENTICATION\","
									"\"contextId\": \"\","
									"\"secondContextId\": \"\","
									"\"thirdContextId\": \"\""
								"},"
								"\"credentials\": {"
									"\"userName\": \"\","
									"\"password\": \"\","
									"\"token\": \"eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJTZXJ2aWNlRGVza3RvcF9CbHVlc2hpZWxkQ0EiLCJpYXQiOjE0OTQyODY0NTMsInN1YiI6IkJsdWUgU2hpbGVkIG9mIENhbGlmb3JuaWEiLCJpc3MiOiJCbHVlc2hpZWxkQ0EiLCJleHAiOjE0OTQ1MDU0NTN9.7Pds-xLnZXkt7eWMhMSUyt0KQZmgNsrL8RMrUUENZCk\","
									"\"type\": \"jwt\""
								"},"
								"\"transactionId\": \"{transId_val}\""
							"},"
							"\"requestBody\": {"
								"\"authenticationType\": \"USERNAME_PASSWORD\","
								"\"authenticationCredentials\": {"
									"\"authenticationCredential\": ["
										"{"
											"\"parameterName\": \"USERNAME\","
											"\"parameterValue\": \"{authUserName_val}\""
										"},"
										"{"
											"\"parameterName\": \"PASSWORD\","
											"\"parameterValue\": \"{authUserPwd_val}\""
										"}"
									"]"
								"}"
							"}"
						"}";
   				

	// PLEASE DO NOT MODIFY - RESOLVING THE REQUEST CONTRACT
    lr_save_string(lr_eval_string(request_json_base), "REQUEST_JSON_PARAM");
    
	    
 	//*---------------------------------------------------------------------------------------------------------------------/
 	//[4] RESPONSE ASSERTIONS FOR TEST VALIDATION AND ANALYSIS
	//*---------------------------------------------------------------------------------------------------------------------/

		// RESPONSE DATA - DO NOT MODIFY		
	    web_reg_save_param_ex("ParamName=ResponseHttp", "LB=", "RB=\"responseHeader\":{", LAST);
		
	    web_reg_save_param_ex("ParamName=ResponseJSON", "LB=", "RB=", SEARCH_FILTERS, "Scope=Body", LAST);

		
	    // RESPONSE JSON - HEADER VALIDATION - RETAIN SuccessCount and WarningCount
		
	    web_reg_find("Text=\"status\":\"SUCCESS\"", "SaveCount=SuccessCount", "LAST" );		
  
		web_reg_find("Text=\"status\":\"WARNING\"", "SaveCount=WarningCount", "LAST" );
	
		// RESPONSE JSON - MODIFY BODY VALIDATION TEXT/VALUE - RETAIN PayLoadCount.
		// ADD ADDITIONAL VALIDATIONS - NAME IT RELEVANT TO THE OBJECT, say PayloadClaims, etc.
		
        web_reg_find("Text=\"userName\":\"{JBody_AuthMemLogin}\"", "SaveCount=PayloadCount", LAST );
		
   //     "userName":"RT_90071374001"
	    		
		//RESPONSE JSON - MODIFY BODY VALIDATION TEXT/VALUE - RETAIN for Business Service and as Payload Validation for Authenication
		
		//Required for Member APIC Bussiness Servicec: LTPA - memberIdentifier - birthDate used for Member data validation for APIC 
		web_reg_save_param("Auth_LTPA","LB=X-BSC-LTPA-Token: ","RB=\r\n","Search=Headers",LAST);
        web_reg_save_param("Auth_birthDate","LB=\"memberBirthDate\":\"","RB=\",","Search=Body",LAST);
        web_reg_save_param("Auth_mbrNum","LB=\"subscriberIdentifier\":\"","RB=\",","Search=Body",LAST);
        web_reg_save_param("Auth_groupNumber","LB=\"groupNumber\":\"","RB=\",","Search=Body",LAST);
        web_reg_save_param("Auth_memberIdentifier","LB=\"memberIdentifier\":\"","RB=\",","Search=Body",LAST);
        web_reg_save_param("Auth_userId","LB=\"identifier\":\"","RB=\", \"identifierType\":\"USER_ID\"","Search=Body",LAST);
        web_reg_save_param("Auth_memberSuffix","LB=\"memberIdentifierSuffixNumber\":\"","RB=\",","Search=Body",LAST);

		
  	//*---------------------------------------------------------------------------------------------------------------------/
    //[5] SERVICE REQUESTS
    //*---------------------------------------------------------------------------------------------------------------------/
    
    	// PLEASE DO NOT MODIFY

    	
   	  	web_add_header("x-ibm-client-id", "{AIP_AuthClientId}");
     	web_add_header("x-ibm-client-secret", "{AIP_AuthClientSecret}"); 

    	
		//Request Time
		lr_save_string(lr_eval_string("{Sys_DateTime}"),"requestTime");
	
		
		// YOU MAY NEED TO INPUT CORRECT SERVICENAME PARAM WHEN THERE ARE MORE THAN ONE TRANSACTIONS
    	
		lr_start_transaction(lr_eval_string("{AIP_AuthServiceName}"));
	
		web_custom_request(lr_eval_string("{AIP_AuthServiceName}"),
	  		"URL={AIP_AuthServer}{AIP_AuthServerPath}{AIP_AuthServiceURL}",
	       	"Method=POST",
	     	"TargetFrame=",
	     	"Resource=0",
	     	"Referer=",
	     	"Mode=HTTP",
	     	"RecContentType=application/json",
	     	"EncType=application/json",
	 	   	"Body={REQUEST_JSON_PARAM}",
	 	  	LAST);
		
		transDuration = lr_get_transaction_duration(lr_eval_string("{AIP_AuthServiceName}"));
		
		
	//*---------------------------------------------------------------------------------------------------------------------/
    //[6] TRANSACTION PASS/FAIL DECISION CRITERIA
    //*---------------------------------------------------------------------------------------------------------------------/
  
		// ALL THE THREE CRIERIA IS MANDATORY, ADD ADDITIONAL VALIDATION WHEN NEEDED
		
		if ((atoi(lr_eval_string("{SuccessCount}")) > 0  || atoi(lr_eval_string("{WarningCount}")) > 0 ) && ( atoi(lr_eval_string("{PayloadCount}")) > 0 )) {
	      	lr_end_transaction(lr_eval_string("{AIP_AuthServiceName}"), LR_PASS);
	    	transStatus ="PASS";
	    } else {
	    	lr_end_transaction(lr_eval_string("{AIP_AuthServiceName}"), LR_FAIL);
	    	transStatus ="FAIL";
	    }
		
		
	//*---------------------------------------------------------------------------------------------------------------------/
 	//[7] LOGGING - FOR EVERY TRANSACTIONS - DO NOT ENABLE UNLESS YOU WANT TO TRY THIS OUT - DISABLE WHILE RUNNING ACTUAL TESTS
    //*---------------------------------------------------------------------------------------------------------------------/
    
//    strcpy(newServiceName, lr_eval_string("{transId_val}"));
    
//    strcat(newServiceName, lr_eval_string("{AIP_ServiceName}"));
//    lr_output_message("newServiceName = %s", newServiceName); 
    
    	//strcpy(actualReqDT, lr_eval_string("{requestTime}"));    
	//strcpy(payloadCount, lr_eval_string("{payload}"));

   	 lr_param_sprintf ("auth_trans_val", "%s-%s-%s%s", lr_eval_string("{AIP_AuthServiceName}"), lr_eval_string("{AIP_ServiceName}"), lr_eval_string("{Sys_VUserID}"), lr_eval_string("{Sys_Iteration}"), 60);
	
     ResponseAnalysis( lr_eval_string("{auth_trans_val}"), lr_eval_string("{AIP_ServiceURL}"), lr_eval_string("{SuccessCount}"), lr_eval_string("{PayloadCount}"), lr_eval_string("{requestTime}"), lr_eval_string(request_json_base), transStatus, transDuration);


return 0;

}