setSSLCert()
{

	char const *certFilePath;
    char const *keyFilePath;
	char *hostName;
    
	hostName = lr_get_host_name( );
    //lr_output_message("***hostname: %s", hostName);

    if(strstr(hostName, "BSC") !=0)
	{ 
		certFilePath = "CertFilePath=C:\\data\\certificates\\IS-EPM-COMMON.pem";
		keyFilePath = "KeyFilePath=C:\\data\\certificates\\IS-EPM-COMMON.pem";
	}
	else
	{
		certFilePath = "CertFilePath=D:\\data\\certificates\\IS-EPM-COMMON.pem";
		keyFilePath = "KeyFilePath=D:\\data\\certificates\\IS-EPM-COMMON.pem";
	}

	//lr_output_message("***%s",certFilePath);
	
    web_set_sockets_option("SSL_VERSION","TLS1.2");
		
	web_set_certificate_ex( 
		certFilePath, 
		"CertFormat=PEM", 
		keyFilePath, 
		"KeyFormat=PEM", 
    	"Password=Welcome1", 
	LAST);
	
    return 0;
   
}