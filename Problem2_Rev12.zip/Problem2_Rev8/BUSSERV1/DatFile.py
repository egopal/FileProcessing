from collections import OrderedDict
import logging
import os 

class DatFile:
    def __init__(self, file_path):
        '''
        input:
            file_path: fiel_path of the Dat file to read
        operation:
            Makes a Dat file object, and reads the content of the dat file 
        output: None 
        '''
        logger = logging.getLogger()

        logger.debug("initialing the DatFile object")
        
        if(os.path.exists(file_path)):
            # some intializations
            self.file_path = file_path
        else:
            logger.warn("the file path {} does not exists".format(file_path))
        
        # Ordered Dictionary mantains the order of the data i  which it is inserted 
        self.mapped_data = OrderedDict()
        
        # read the content of from the dat file
        self.read_file()

        logger.debug("completed the initialization of DatFile object")


    def read_file(self):
        '''
        input: None
        operation:  
            read the file content and store in the the object 
        output: None
        '''
        logger = logging.getLogger()

        logger.debug("starting reading the dat file {}".format(self.file_path))

        data = []
        
        try:
            # read the content of the file
            with open(self.file_path, "r") as f:
                for i in f:
                    if(len(i.strip()) > 0):
                        # step to ignore empty lines
                        data.append(i.strip().split(","))
            logger.info("File {} read successfully.".format(self.file_path))
        except Exception as e:
            logger.warn("Some error in while reading file {}".format(
                self.file_path), exc_info=True)

        # storing the content in the object 
        self.data = data

        logger.debug("data read: ")
        for line in self.data:
            logger.debug(line)

        # storing the data in the mapped dictionary
        for row in range(len(data)):
            if(row == 0):
                # the header line 
                for col in range(len(data[0])):
                    # creating the key and assiging it an empty line 
                    self.mapped_data[data[0][col].strip()] = []
            else:
                # the data in which is present in other lines
                for col in range(len(data[0])):
                    # appending data to the list
                    self.mapped_data[data[0][col].strip()].append(
                        data[row][col].strip())
        
        logger.debug("reformatted data:")
        for key in self.mapped_data:
            logger.debug("\"{}\": {}".format(key,self.mapped_data[key])) 

        logger.debug("completed reading the dat file")

    def set_key(self, key, new_value):
        '''
        input: 
            key: the key for which the value would be reset 
            new_value: the new value which would be added 
        operation:
            - it checks if a simmilar key exists 
            - if it exists, the last value from the list of popped and the correct value is pushed  
            - if the key does not exists, create a new key 
        output: None
        '''
        logger = logging.getLogger()

        logger.debug("starting the process of setting the value to a key")

        # check if the key is alreayd present and if a simmilar key is present, 
        # then it would return the original key name 
        exact_key = self.key_present(key)
        
        if(exact_key!=None):
            # if the key is found 
            logger.debug("for the key \"{}\" an exact key of \"{}\" was found".format(key,exact_key))
            
            # this would replace the value of the key
            self.mapped_data[exact_key].pop()
            
            # this would add a new value for the key 
            self.mapped_data[exact_key].append(new_value)

            logger.debug("key \"{}\" has a value of \"{}\"".format(exact_key,self.mapped_data[exact_key]))
        else:
            # no key was found
            logger.debug("no key with \"{}\" is present ... creating a new key {}".format(key,key))
            self.mapped_data[key] = [new_value]
        
        logger.debug("completed the process of setting the value to a key")


    def key_present(self, key):
        '''
        input: 
            key: the key to check if the key is present 
        operation:
            checks if the key or a simmilar key is present or not 
        output: the exact_key matching the key provided to us  
        '''
        logger = logging.getLogger()

        logger.debug("starting to check if the key \"{}\" is present or not".format(key))
        
        exact_key = None

        # iterate over all the keys 
        for k in self.mapped_data.keys():
            if(k.strip().lower() == key.lower()):
                exact_key = k
                logger.info("key \"{}\" has been found".format(key.lower()))
                break
        else:
            logger.warn("no key simillar to \"{}\" has been found.".format(key))
            exact_key = None
        
        logger.debug("completed to check if the key is present or not")
        
        return exact_key

    def get_key_value(self, key):
        '''
        input: key
        operation: 

        output: 
        '''
        logger = logging.getLogger()
        logger.debug(
            "getting the current value set for key = \"{}\"".format(key))

        value = None
        
        # check if the key is present 
        exact_key = self.key_present(key)
        
        if(exact_key):
            # if present
            value = self.mapped_data[exact_key]
            logger.debug(
                "found the required key = \"{}\", returning the value = \"{}\"".format(key, value))
        else:
            # if not present
            logger.debug(
                "no key with the name \"{}\" was found ... returning None".format(key))
            value = None

        logger.debug("completed the process of getting the value of the key = \"{}\" from the file {}".format(
            key, self.file_path))

        return value

    def set_default_value(self, key_name, default_value):
        '''
        input: 
            key_name:  the name of the key
            default_value: the default value to be put out 
        operation:  
            checks if the key has a value 
            if the key is not present of the value is Null or empty, the default value is assigned to the key
        output: None
        '''
        logger = logging.getLogger()

        logger.debug("started processing the file {} to set the default value of the key = \"{}\" to a value of = \"{}\"".format(
            self.file_path, key_name, default_value))

        value = self.get_key_value(key_name)

        if(value == None or (len(value) > 0 and len(value[0].strip())) == 0):
            self.set_key(key_name, default_value)
        else:
            logger.debug("We already have a value for key = \"{}\", value = \"{}\"".format(
                key_name, value))

        logger.debug("process completed of setting up the default value ")

    def sort_keys(self):
        '''
        input: None 
        operation:
            sorts keys by the name 
        output: None
        '''        
        self.mapped_data = OrderedDict(
            (k, self.mapped_data[k]) for k in sorted(self.mapped_data.keys()))

    def write_data(self):
        '''
        input: None
        operation:
            writes the data which is present in the self.mapped_data to the dat file in the correct format 
        output: None
        '''
        logger = logging.getLogger()

        logger.debug("starting writing data to the dat file")

        with open(self.file_path, "w") as f:
            
            # list of all the keys to be written 
            keys_list = list(self.mapped_data.keys())

            # write all the headers to the file 
            f.write(",".join(keys_list)+"\n")
            
            index = 0
            
            # iterate over to write all the rows for a particular column
            while(index < len(self.mapped_data[keys_list[0]])):
                
                # iterate over all the keys 
                for key_index in range(len(keys_list)):
                    
                    # this condition is just to prevent writing "," before first word. 
                    # else, it woruld be written before every word
                    if(key_index != 0):
                        f.write(",")
                    
                    # writing element of a key 
                    key = keys_list[key_index]
                    f.write(self.mapped_data[key][index])
                index += 1
                f.write("\n")
        
        logger.debug("completed writing data to the dat file")


    def add_prefix_to_all_keys(self, prefix):
        '''
        input:
            prefix: a word which has to be added as prefix to all the keys
        operation:          
            its adds prefix proided to all the keys in the prev mapping 
            and finally saves them back to the class object 
        output: None    
        '''

        self.mapped_data = OrderedDict(
            (prefix+k, self.mapped_data[k]) for k in self.mapped_data.keys())

    def get_key_list(self):
        '''
        input: None
        operation:
            return the list of all the headers in the given dat file 
        output: return the list of all the headers in the given dat file
        '''
        return list(self.mapped_data.keys())

    @staticmethod
    def write_list_data_to_dat_file(file_path, data):
        '''
        input:
            file_path: the complete file path to write the data
            data:  data as list of string to be written in the file_path 
        operation:
        output:
        '''
        logger = logging.getLogger()

        logger.debug("starting to write list to the file {}".format(file_path))

        if(os.path.exists(file_path)):
            # file path exists  
            with open(file_path, "w") as f:
                for row in data:
                    
                    row_mapped_string = list(map(str, row))
                    complete_string = ",".join(row_mapped_string)
                    # l = ["hello","w","orld"]
                    # ",".join(l)
                    # "hello,w,orld"

                    if(len(complete_string.strip()) > 0):
                        # check if the length of line writing is not an empty line  
                        f.write(complete_string+"\n")
            logger.info("the complete data provided has been written to the file")
        else:
            logger.warn("the file path {} does not exists".format(file_path))
            
        logger.debug("completed the process to write list to the file")
