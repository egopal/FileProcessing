import logging
import os
import shutil
import mysql.connector
import cx_Oracle
import json
import yaml

class Util(object):

    @staticmethod
    def cleanup_script_files(directory_path, cleanup_files_folders):
        '''
            input:
                directory_path: path of the folder where the cleanup has to be performed 
            operation:
                cleans up the source folder ... as per described in the instructions
        '''

        logger = logging.getLogger()

        logger.debug("starting the process of cleaning up the {}".format(directory_path))

        # deleteing the folders specified
        # Util.delete_files_folders(
        #         directory_path, cleanup_files_folders[s], exact_match=True)
            
        # deleting files_folders that start with a set of words
        Util.delete_files_folders(
            directory_path, set(cleanup_files_folders["starts_with"]), starts_with=True)
        
        # deleting files_folders ending with a set of words specified in a set
        Util.delete_files_folders(directory_path, set(cleanup_files_folders["ends_with"]), ends_with=True)
        
        # deleting files_folders that match exactly with the words in a set
        Util.delete_files_folders(
            directory_path, set(cleanup_files_folders["exact_match"]), exact_match=True)

        logger.debug("ending the process of cleaning up the {}".format(directory_path))

    @staticmethod
    def refresh_dict(data_keys):
        '''
            input:
                data_keys: the dictionary refrence of the object  
            operation:
                it resets all the values of all the keys to None, so than new value can be used 
        '''

        # getting logger instance
        logger = logging.getLogger()
        logger.debug(
            "Starting the process of reseting the values in the dictionary in order to extract new set of values")
        
        for key in data_keys:
            data_keys[key] = None

        logger.debug(
            "Completed the process of reseting the values in the dictionary in order to extract new set of values")
        
    @staticmethod
    def setup_logger(file_path):
        '''
            input:
                file_path: absolute path of the file which would be used for logging 
            operation:
                setups the logger at the specified location
        '''

        # creating the logger with the format i.e. all the things which need to be written
        logging.basicConfig(filename=file_path,
                            format='%(filename)s - %(lineno)s - %(funcName)s() - %(levelname)s - %(message)s',
                            filemode='w')

        # getting logger instance
        logger = logging.getLogger()

        # setting the threshold level to record the data
        logger.setLevel(logging.DEBUG)

    @staticmethod
    def delete_single_folder(folder_path):
        '''
            input:
                folder_path: path of the dolder to delete
            operation:
                deletes the folder whose path has been specified to be deleted
        '''

        # getting logger instance
        logger = logging.getLogger()
        
        logger.debug("starting the process of deleting {}".format(folder_path))

        # check if the folder can be deleted
        if(os.path.exists(folder_path) and os.path.isdir(folder_path)):
            # can be deleted
            try:
                shutil.rmtree(folder_path)
                logger.info("Successfully deleted folder {}".format(folder_path))
            except Exception as e:
                logger.warn("Some error in while deleting {}".format(
                    folder_path), exc_info=True)
        else:
            # cannot be deleted
            logger.warn("Not able to delete {} because it is not a folder".format(folder_path))

        logger.debug("completed the process of deleting {}".format(folder_path))

    # @staticmethod
    # def delete_folders(directory_path, folders_to_delete=set(), starts_with = False, ends_with = False, exact_match = False):
    #     '''
    #         input:
    #             directory_path: the path of the folder ... under which all the files and folders would be deleted
    #             folders_to_delete: the set of folder names to delete ... default value is an empty set
    #         operation:
    #             deletes all the folders specified in the set of folders 
    #     '''

    #     # getting logger instance
    #     logger = logging.getLogger()
    #     logger.debug("Starting the process of deleting folders {} in {}".format(folders_to_delete,directory_path))

    #     # looping over all the files and folds in the directory_path specified
    #     for folder_name in os.listdir(directory_path):
            
    #         # checking if the name of the folder exists in the 
    #         if(folder_name in folders_to_delete):
    #             # if the folder is persent in the list of folders to delete

    #             # getting the actual path of the folder delete and deleteing it 
    #             actualFolder = os.path.join(directory_path, folder_name) 
    #             Util.delete_single_folder(actualFolder)

    #     logger.debug("Completed the process of deleting folders {} in {}".format(folders_to_delete,directory_path))

    # @staticmethod
    # def delete_folders(dir_path, folders_to_delete=set(),
    #                  starts_with=False, ends_with=False, exact_match=False):
    #     '''
    #         input:
    #             dir_path: the directory name which would be containing the files in it 
    #             folders_to_delete: a set of files to delete ... default value is an empty set 
    #             starts_with: True/False, wheter you want to delete files starting with the names in the set files_to_delete  .... default value False
    #             ends_with: True/False, wheter you want to delete files ending with the names in the set files_to_delete  .... default value False
    #             exact_match: True/False, wheter you want to delete files matching exactly with the names in the set files_to_delete  .... default value False
    #         operation:
    #             deletes a set of files that either 
    #                 - start with a set words
    #                 - end with a set of words
    #                 - exactly match that word  
    #     '''

    #     # getting logger instance
    #     logger = logging.getLogger()
        
    #     logger.debug("starting process of deleting files in {}".format(dir_path))

    #     if(starts_with == True):
    #         # starting with the names in the set
    #         logger.debug("Deleting files starting with {}".format(files_to_delete))

    #         for file in os.listdir(dir_path):
    #             for fileType in files_to_delete:
    #                 if file.startswith(fileType):
    #                     # this file in the folder starts with a name specied in the files_to_delete set  
    #                     Util.delete_single_file(dir_path, file)

    #         logger.debug("Completed the process of deleting files starting with {}".format(files_to_delete))

    #     elif(ends_with == True):
    #         # ending with the names in the set
    #         logger.debug(
    #             "Deleting files ending with {}".format(files_to_delete))

    #         for file in os.listdir(dir_path):
    #             for fileType in files_to_delete:
    #                 if file.endswith(fileType):
    #                     # this file in the folder ends with a name specied in the files_to_delete set  
    #                     Util.delete_single_file(dir_path, file)

    #         logger.debug("Completed the process of deleting files ending with {}".format(files_to_delete))

    #     elif(exact_match == True):
    #         # matching exactly with the names in the set
    #         logger.debug(
    #             "Deleting files matching exactly with {}".format(files_to_delete))

    #         for file in os.listdir(dir_path):
    #             for fileType in files_to_delete:
    #                 if(file == fileType):
    #                     Util.delete_single_file(dir_path, file)

    #         logger.debug("Completed the process of deleting files matching exactly with {}".format(files_to_delete))

    #     else:
    #         # none of the above conditions match
    #         logger.debug(
    #             "No argument among starts_with, ends_with, exact_match was provided with the fuction call")

    #     logger.debug("completed the process of deleting files in {}".format(dir_path))
    @staticmethod
    def delete_single_file(file_path):
        '''
            input:
                file_path: path of the file to be deleted
            operation:
                checks if the file exisis in the dir_path and then deletes the file
        '''

        # getting logger instance
        logger = logging.getLogger()

        # getting exact file path to be deleted
        actual_path = file_path
        logger.debug("startig the process of deleting file {}".format(actual_path))

        if(os.path.exists(actual_path)):
            # path exixsts
            try:
                # delete the file
                os.remove(actual_path)
                logger.info("Deleted file {}".format(actual_path))
            except Exception as e:
                logger.warn("Some error in while deleting {}".format(
                    actual_path), exc_info=True)
        else:
            # path does not exists
            logger.warn("the file path {} does not exists".format(actual_path))
        
        logger.debug("completeing the process of deleting file {}".format(actual_path))


    @staticmethod
    def delete_single_file_folder(dir_path, file_folder):
        '''
            input:
                dir_path: the directory name which would be containing the files_folders in it 
                files_folders: file or foler to delete 
            operation:
                checks if the file or folder path exists and if the path exists 
                    - check if it is file, then call delete_single_file
                    - check if it is a folder, then call delete_single_folder
        '''
        logger = logging.getLogger()

        path = os.path.join(dir_path, file_folder)
        
        if(os.path.exists(path)):
            if(os.path.isdir(path)):
                # if it is a folder
                Util.delete_single_folder(path)
            else:
                # if it is a file
                Util.delete_single_file(path)
        else:
            logger.debug("the path {} does not exists.".format(path))
                

    @staticmethod
    def delete_files_folders(dir_path, files_folders_to_delete=set(),
                        starts_with=False, ends_with=False, exact_match=False):
        '''
            input:
                dir_path: the directory name which would be containing the files_folders in it 
                files_folders_to_delete: a set of files_folders to delete ... default value is an empty set 
                starts_with: True/False, wheter you want to delete files_folders starting with the names in the set files_folders_to_delete  .... default value False
                ends_with: True/False, wheter you want to delete files_folders ending with the names in the set files_folders_to_delete  .... default value False
                exact_match: True/False, wheter you want to delete files_folders matching exactly with the names in the set files_folders_to_delete  .... default value False
            operation:
                deletes a set of files_folders that either 
                    - start with a set words in files_folders_to_delete
                    - end with a set of words in files_folders_to_delete
                    - exactly match that word  
        '''

        # getting logger instance
        logger = logging.getLogger()
        
        logger.debug("starting process of deleting files_folders in {}".format(dir_path))

        if(starts_with == True):
            # starting with the names in the set
            logger.debug("Deleting files_folders starting with {}".format(files_folders_to_delete))
            print(os.path.exists(dir_path))
            for file_folder in os.listdir(dir_path):
                for fileType in files_folders_to_delete:
                    if file_folder.startswith(fileType):
                        # this file_folder in the folder starts with a name specied in the files_folders_to_delete set  
                        Util.delete_single_file_folder(dir_path, file_folder)

            logger.debug("Completed the process of deleting files_folders starting with {}".format(files_folders_to_delete))

        elif(ends_with == True):
            # ending with the names in the set
            logger.debug(
                "Deleting files_folders ending with {}".format(files_folders_to_delete))

            for file_folder in os.listdir(dir_path):
                for fileType in files_folders_to_delete:
                    if file_folder.endswith(fileType):
                        # this file_folder in the folder ends with a name specied in the files_folders_to_delete set  
                        Util.delete_single_file_folder(dir_path, file_folder)

            logger.debug("Completed the process of deleting files_folders ending with {}".format(files_folders_to_delete))

        elif(exact_match == True):
            # matching exactly with the names in the set
            logger.debug(
                "Deleting files_folders matching exactly with {}".format(files_folders_to_delete))

            for file_folder in os.listdir(dir_path):
                for fileType in files_folders_to_delete:
                    if(file_folder == fileType):
                        Util.delete_single_file_folder(dir_path, file_folder)

            logger.debug("Completed the process of deleting files_folders matching exactly with {}".format(files_folders_to_delete))

        else:
            # none of the above conditions match
            logger.debug(
                "No argument among starts_with, ends_with, exact_match was provided with the fuction call")

        logger.debug("completed the process of deleting files_folders in {}".format(dir_path))


    @staticmethod
    def backup(source_dir):
        # since after compressing the file would be placed in the same folder only so the path of that folder is only taken
        '''
            input:
                source_dir: the path of the directory to be commpressed
            operation:
                backups the current directory specified and places in the directory where it the folder is present
        '''

        # getting logger instance
        logger = logging.getLogger()

        logger.debug("starting the process of backing up process of {} ".format(source_dir))

        if(os.path.exists(source_dir) and os.path.isdir(source_dir)):
            # can compress

            # creating archieve
            try:
                shutil.make_archive(base_dir=source_dir, root_dir=source_dir, format='zip', base_name=source_dir)
                logger.info("backing up folder {} and this has been placed in {}".format(source_dir, os.path.split(source_dir)[0]))
            except Exception as e:
                logger.warn("Some error in while backing up {}".format(source_dir), exc_info=True)
        else:
            # cannot compress
            logger.warn("either the path specified dosen't exists of the path dosen't points to a direcotry. ")

        logger.debug("completed the process of backing up process of {} ".format(source_dir))

    @staticmethod
    def replace_text_in_file(file_path, prev_text, new_text):
        '''
            input: 
                file_path: path of the file where the replacement of text has to be done  
                prev_text: the text to be replaced
                new_text:  the text which would replace the current text
            operation:
                this function takes the file_path and replaces the prev_text with the new_text 
        '''

        logger = logging.getLogger()
        
        logger.debug("starting the process of replacing the content in the file {}".format(file_path))

        # a temporary file where we would be storing things temporarily
        temp_file = "temp.txt"
        
        if(os.path.exists(file_path)):
            # path exists
            
            logger.debug("file path exists {}".format(file_path))

            # reading from temp file
            with open(file_path, "r") as f:
                # writitng to temp file
                with open(temp_file, "w") as f1:
                    for i in f:
                        # but replacing the prev_text with new_text before writing 
                        f1.write(i.replace(prev_text, new_text))
        else:
            # path does not exists
            logger.warn("the file path does not exists {} ".format(file_path))
       
        # delete the old file
        os.remove(file_path)

        # rename the temp file with the old file path
        os.rename(temp_file, file_path)

        logger.debug("completed the process of replacing the content in the file {}".format(file_path))


    @staticmethod
    def clear_open_file(file_path):
        '''
            input:
                file_path: file to be cleared
            operation:
                this function empties a file and removes all of the content 
                this  fucntion also creates an empty file if the file is not present  
        '''

        # getting logger instance
        logger = logging.getLogger()
        
        logger.debug("starting the process of crating an empty file")
        
        with open(file_path, "w") as f:
            logger.info("sucessfully made an empty file {}".format(file_path))
            pass
        
        logger.debug("completed the process of crating an empty file")
        
    @staticmethod
    def read_sql(req_sql_source, sql_field_name = None):
        '''
            input:
                req_sql_source: the sorce of sql ... it can be either a dictionary or it an be file   
            operation:
                this function reads the sql from the source provided and returns the sql statment as a string
            output:
                returns a string i.e. the complete sql statement
        '''

        # getting logger instance
        logger = logging.getLogger()

        logger.debug("starting reading sql from the source provided")

        sql_data = None

        # check the source of sql 
        if(isinstance(req_sql_source, str)):
            # if it is a string => its a file name
            logger.debug(
                "the source of ql was provided to be string ... a file path")
            
            # check if a file with the name ..... exists
            if(os.path.exists(req_sql_source)):
                # file exists
                logger.debug("the file path exists {}".format(req_sql_source))
                with open(req_sql_source) as f:
                    sql_data = f.read()
                logger.debug("The SQL query extracted is as below:-")
                logger.debug(sql_data)
                logger.info("successfully read the sql query from \"{}\"".format(req_sql_source))
            else:
                # file does not exists
                logger.warn(
                    "no such file path {} exists".format(req_sql_source))
                sql_data = None

        elif(isinstance(req_sql_source, dict)):
            # if it is a dict => read the dictionary

            logger.debug("the source of sql is dictionary")
            
            # check if the key containing the sql query is present 
            if("SQL Query for Data" in req_sql_source):
                # key present 
                logger.debug(
                    "\"SQL Query for Data\" key was found which contains the sql staments")
                
                # check if the key where the ql would be present has been specied correctly or not  
                if(sql_field_name!=None and sql_field_name in req_sql_source):
                    # sql_field_name is not None and we have the key named in data_keys 
                    sql_data = req_sql_source[sql_field_name]
                    logger.debug("The SQL query extracted is as below:-")
                    logger.debug(sql_data)
                    logger.info("successfully read the sql query from \"{}\" field in the data keys".format(sql_field_name))
                else:
                    # sql_field_name is None 
                    # or 
                    # we do not have the key specified in sql_field_name present in  data_keys
                    logger.warn("Not able to access sql query from the data_keys. \
                        The field \"{}\" which was provided in the config.yaml file is \
                        either \"None\" or the key is not present in the data_keys.".format(sql_field_name))
            else:
                # key not present
                logger.warn(
                    "no key with the name \"{}\" was found".format(sql_field_name))
        else:
            # neither a string nor a dictionary
            logger.warn("the source is neither a string nor a dictionary")

        logger.debug("completed the process of reading the sql from the source")

        return sql_data

    @staticmethod
    def get_corresponding_sql_file(directory_path, dat_file_name, req_sql_file, all_files):
        '''
            input:
                directory_path:   the path of the current directory
                dat_file_name: the dat file for which the corresponding sql file is being looked
                req_sql_file: the sql file we are looking for 
                all_files: list of all files present in the current diecory
            operation:
                get the corresponding sql file from the dat file   
            output: returns the sql read from the source and if not found returns None 
        '''

        # getting logger instance
        logger = logging.getLogger()
        
        # dat file path 
        dat_file_path = os.path.join(directory_path, dat_file_name)
        # required sql file path 
        req_sql_file_path = os.path.join(directory_path, req_sql_file)

        logger.debug("Starting the process of looking the corresponding sql file for the .dat file {}".format(dat_file_name))

        sql_query = None

        # check if the sql file is present in all_files
        if(req_sql_file not in all_files):
            # required sql file is not present 
            logger.debug(
                "No corresponging SQL file is found for {}".format(dat_file_path))
            sql_query = None
        else:
            # required sql file is present 
            logger.debug("found the corrponging sql {} file for {}".format(
                req_sql_file_path, dat_file_path))
            
            # create an empty corresponding dat file 
            Util.clear_open_file(dat_file_path)
            
            # read sql from the file
            sql_query = Util.read_sql(req_sql_file_path)

        logger.debug("completed the search of sql file")
        
        # rerturn the sql which we got from the file 
        return sql_query

    @staticmethod
    def reformat_sql_query(sql_query, row_num_value):
        '''
            input:
                sql_query: the unclean sql query as string
                row_num_value:  the value which has to be put to rownum  
            operation:
                cleans the sql query, removes comments, updates rownum, and returns a clean sql query in return
            output:
                returns a clear output sql query    
        '''

        # getting logger instance
        logger = logging.getLogger()

        logger.debug("starting reformatting the sql query")

        # get the list of all the lines by splitting sql_query
        lines = sql_query.split("\n")
        
        # this list would contain the final lines of sql   
        final_lines = []
        
        row_update_made = False

        # iterate over lines and remove comments and do some more processing  
        for i in range(len(lines)):
            lines[i] = lines[i].strip()

            # removing comments 
            if("--" in lines[i]):
                logger.debug(
                    "comment found removing comment from the sql file")
                
                # check if something is left after removing the comment 

                if(len(lines[i][:lines[i].index("--")].strip()) > 0):
                    final_lines.append(lines[i][:lines[i].find("--")])

            else:
                if("rownum" in lines[i].lower()):
                    # updating the value of rownum
                    
                    logger.debug("\"rownum\" found in the line ")

                    # ending index of rownum
                    index = lines[i].lower().index("rownum")+len("rownum")

                    # move further till we come across the number after rownum
                    # bcz it would be like "rownum = " and we would increment index till wefind " " and "="
                    while(lines[i][index] in {" ", "="}):
                        index += 1

                    # marking the starting index
                    start = index

                    # move till the digits are there and the line ends 
                    while(index < len(lines[i]) and lines[i][index].isdigit()):
                        index += 1
                    
                    # and mark the end 
                    end = index

                    # updating the value of the rownum 
                    lines[i] = lines[i][:start]+str(row_num_value)+lines[i][end:]

                    row_update_made = True
                
                # finally adding the lines
                final_lines.append(lines[i])

        # making the final clean single line query
        clear_query = " ".join(final_lines)

        if(row_update_made == False):
            # if no rownum was found
            logger.warn("No RowNum is found in the sql query")
        
        logger.debug("completed the reformatting of the sql query")

        return clear_query

    @staticmethod
    def get_sql_result_in_file(sql_query, file_path, limit, mysqlconnector=False, cxconnector=False):
        '''
            input:
                sql_query: gets the resulf of the sql query to be executed
                file_path: file where eerything has to be written
                limit: limit of the no. of records to be added  
                mysqlconnector: whether to use mysql connector
                cxconnector: whether do you want ot use cxconnector 
            operation:
                runs the sql query result and returns the result
            output:
                return the clear result as output
        '''
        # getting logger instance
        logger = logging.getLogger()

        logger.debug("strating executing the sql query")

        # the list which would be captuing results
        results = []

        if(mysqlconnector==True):
            
            # get connector
            db = mysql.connector.connect(
                host="localhost",
                user="root",
                password="qwertyuiop",
                database="test1"
            )

            logger.debug("connected with the database")

            # get cursor for the connections 
            cursor = db.cursor()
            logger.debug("got the connecton of the databsse")
        
        elif(cxconnector==True):
            # get connector
            connection = cx_Oracle.connect("hr", "welcome", "localhost/orclpdb1")
            
            logger.debug("connected with the database")

            # get cursor for the connections 
            cursor = connection.cursor()
        else:
            logger.warn("none of the connnector was activated please privide atleast one connector to connect to the database")
            return

        # execute the sql query 
        cursor.execute(sql_query)
        logger.debug("executed the sql query")
        
        # this adds the column names in the list
        file_to_write = open(file_path,"w")

        # row_count_present variable to check if rowcount is prestn 
        row_count_present = False

        # results.append()
        row = [i[0].strip() for i in cursor.description]
        
        # loop to check if rowcount is already present
        for col in row:
            if("rowcount" in col.strip().lower()):
                row_count_present = True
                logger.info("row_count as a column is already present in the database result")
                break
        else:
            row.append("RowCount")
            logger.info("row_count as a column is not present in the database result")
        
        file_to_write.write(",".join(row).strip()+"\n")
        logger.debug("added all the column names")

        current_row_num = 1 

        # fetch resuls and store them 
        while(current_row_num<=limit):
            row = cursor.fetchone()

            if row == None:
                break

            row = list(row)

            # ("sagar","sagar, sehgal")

            # print("recieved",row)

            for index in range(len(row)):
                if("," in row[index]):
                    break
            else:
                # add row_count if not present
                if(row_count_present==False):
                    row.append("{:05}".format(current_row_num))
                # writing the row to the fikle
                file_to_write.write(",".join(row).strip()+"\n")
                # incrementing the current_row_num value .... so that not all records are witten
                current_row_num+=1
            
        file_to_write.close()
        # closing connection with the database
        cursor.close()
        logger.debug("closed connection with the database")  
            
        logger.debug("completed executing the sql query")

        # return results

    
    @staticmethod
    def divide_file_into_segments(file_path, separators):
        '''
            input:
                file_path: path of the file which needs to be separated
                separator: this is a list of starting of separator lines 
            operation:
                given a list of separators, eg n separators,  
                it would split the content into n+1 parts,
                by separating the content based on the words
                starting with the words in the list in order
            output:
                returns a list separated content in the list
        '''
        # getting logger instance 
        logger = logging.getLogger()

        logger.debug("starting the process of dividing the content of file {} into segments".format(file_path))

        # indexing over the sepaartors list  
        separator_index = 0

        # a list where the segments of sepaarted text would be stored
        segments = []

        data = []

        if(os.path.exists(file_path)):
            # file pth exists

            logger.debug("the file path exists".format())

            with open(file_path, "r") as file:
                # reading line by line from the file
                for line in file:
                    # chekcing if a separator exists and the current line startes witht the next sepaartor 
                    if(separator_index < len(separators) and line.strip().startswith(separators[separator_index])):
                        # if true

                        # store the complete data collecte till now 
                        segments.append(tuple(data))
                        # and clear the list collecting the data since all the data has been colected
                        data.clear()
                        # and move to the next separaotor
                        separator_index += 1
                    
                    # store the line 
                    data.append(line)
                
                # store all the data collected till now 
                segments.append(tuple(data))
                # since all data has been collected and 
                data.clear()

            logger.info("the file has been read and divided into segments")
        else:
            # file_path does not exists
            logger.warn("the file path {} does not exists".format(file_path))
        logger.debug("completed the process of dividing the content into segemnts")

        return segments

    @staticmethod
    def get_segment(column_name, param_name, select_next_row, table, 
                    delimiter=",", generate_new_val="EachIteration", original_value="",
                    out_of_range_policy="ContinueWithLast", start_row="1",
                    table_location="Local", seg_type="Table", 
                    auto_allocate_block_size="1", value_for_each_vuser=""):
        '''
            input:
                all the input elements are from the segment defined in the .prm file,
                the 3 most important ones are,
                column_name, param_name, select_next_row
                all of these are parameters of the segement 
            observation:
                based on all the info above a dictionary is built out and returned
            output:
                a dictionary contaiing the complete segment
        '''
        # getting logger instance
        logger = logging.getLogger()

        logger.debug("starting the process of creating the segemnt")

        segment =  {
            "parameter": param_name,
            "ColumnName": column_name,
            "Delimiter": delimiter,
            "GenerateNewVal": generate_new_val,
            "OriginalValue": original_value,
            "OutOfRangePolicy": original_value,
            "ParamName": param_name,
            "SelectNextRow": select_next_row,
            "StartRow": start_row,
            "Table": table,
            "TableLocation": table_location,
            "Type": seg_type,
            "auto_allocate_block_size": auto_allocate_block_size,
            "value_for_each_vuser": value_for_each_vuser,
        }

        logger.debug("the segment dictionary made and looks like below:")
        logger.debug(json.dumps(segment, indent=4))

        logger.debug("completed the process of creating the segemnt")

        return segment

    @staticmethod
    def segment_to_string(segment):
        '''
            input:
                segment: a dictionary, contain the segment
            operation:
                this process makes the segment string out of the segment dictionary and returns it 
            output: 
                returns the segment string which could be added   
        '''
        # getting logger instance
        logger = logging.getLogger()

        logger.debug("starting the process of creating the segemnt string from dictionary")

        try:
            # converting from dictionary text to string 
            segment_string= '''[parameter:{}]
\"ColumnName\"=\"{}\"
\"Delimiter\"=\"{}\"
\"GenerateNewVal\"=\"{}\"
\"OriginalValue\"=\"{}\"
\"OutOfRangePolicy\"=\"{}\"
\"ParamName\"=\"{}\"
\"SelectNextRow\"=\"{}\"
\"StartRow\"=\"{}\"
\"Table\"=\"{}\"
\"TableLocation\"=\"{}\"
\"Type\"=\"{}\"
\"auto_allocate_block_size\"=\"{}\"
\"value_for_each_vuser\"=\"{}\" 
'''.format(segment['parameter'], segment['ColumnName'], segment['Delimiter'],
            segment['GenerateNewVal'], segment['OriginalValue'], segment['OutOfRangePolicy'],
            segment['ParamName'], segment['SelectNextRow'], segment['StartRow'], segment['Table'],
            segment['TableLocation'], segment['Type'], segment['auto_allocate_block_size'], segment['value_for_each_vuser'])
            
            logger.info("the string segment made sucessfull from the dictionary")
        except:
            logger.warn("some error occured while converting the segment dictionay to dictionary")
        
        logger.debug("completed the process of creating the segemnt string from dictionary")

        return segment_string
