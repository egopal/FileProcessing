import logging
import json
import os
import shutil
from Util import Util
from DatFile import DatFile
import copy


class CatalogRequest:
    def __init__(self, data_keys, current_directory, src_root_path, src_dir_path, src_dir_name, target_root_path, sql_field):
        '''
		input:
			data_keys: the extracted info from the text in form of dictionary
			current_directory: the path of the current directory where we are present
			src_root_path: path of the source root where everyting related to source would be placed
			src_dir_path: the path path of source directory which we would be dealing with
			src_dir_name: name of the source directory which we would be using
			target_root_name: path of the root of the target where we would be placing all our directories
        '''
        self.data_keys = data_keys
        self.current_directory = current_directory
        self.src_root_path = src_root_path
        self.src_dir_path = src_dir_path
        self.src_dir_name = src_dir_name
        self.target_root_path = target_root_path
        self.sql_field = sql_field

    def data_formatting(self, alias_dict, json_fields):
        '''
		input: None
		operation:
			this joins aliases keys, for eg the key which can have more tthan 1 names
			it is also used to extract info from the a particular keys
			it is also used to convert the json fields from strign into complete json
		output: None
        '''
        # getting logger instance
        logger = logging.getLogger()

        logger.debug("starting the process of formatting the data")

        # loop over all the pairs possible
        for key in alias_dict:
            # loop over the alias keys 
            for alias in alias_dict[key]:
                self.join_alias_keys(key,alias)    
        
        self.extract_header_info()
        self.extract_services_end_point_url()

        # looping over all the keys which are json and have to be converted to json from string 
        for key in json_fields:
            self.jsonify(key)

        logger.debug("completed the process of formatting the data")

    def join_alias_keys(self, original_key, alternative_key):
        '''
		input:
			original_key : the key to which the value has to be brought down to
			alternative_key: the alernate key which can have value in place of the original key
		operation:
			- checks if the alternayte key is present and the originl key is ablse, and then the vlu eof the alternate key is put to origina key
		output: None
        '''
        logger = logging.getLogger()

        logger.debug('starting the process of joing alias keys')

        if(self.data_keys[alternative_key] != None and self.data_keys[original_key] == None):
            self.data_keys[original_key] = self.data_keys[alternative_key]
            logger.info("value for \"{}\" and \"{}\" keys brought to the original key \"{}\"".format(
                original_key, alternative_key, original_key))

        elif(original_key == alternative_key):
            logger.info("the original key \"{}\" and the alias key \"{}\" are the same".format(original_key,alternative_key))

        else:
            logger.warn("original key \"{}\" already had a value so the value from the alias key \"{}\" was not considered.".format(
                original_key, alternative_key))

        logger.debug('completed the process of joing alias keys')

    def extract_header_info(self):
        '''
		input: None
		operation:
			this is a speacial functions and extarcts various infos fromt eh header itself like:-
			- cliendID
			- clientSecret
			are extarcted from the "other header info" section
		output: None
        '''
        logger = logging.getLogger()

        logger.debug(
            "starting the process of extracting the header info from the Catalog Request")

        # checking if the key is None or not
        if(self.data_keys["Other Header Info"] != None):

            # splitting based on comma
            l = self.data_keys["Other Header Info"].split(",")

            # initial to "," is ClientID
            self.data_keys["ClientID"] = "".join(l[:1]).strip()

            # everything after "," is ClientSecret
            self.data_keys["ClientSecret"] = ",".join(l[1:]).strip()

            # check if the self.data_keys["ClientSecret"] conains "ClientSecret:" and remove it if present
            if(self.data_keys["ClientSecret"].split(":")[0].lower().strip() == "ClientSecret".lower().strip()):
                self.data_keys["ClientSecret"] = ":".join(
                    self.data_keys["ClientSecret"].split(":")[1:])

            logger.info(
                "Extarcted \"ClientSecret\" and \"ClientSecret\" from \"Other Header Info\"")
            logger.debug("\"Other Header Info\": {}".format(
                self.data_keys["Other Header Info"]))
            logger.debug("\"Extracted Client ID\": {}".format(
                self.data_keys["ClientID"]))
            logger.debug("\"Extracted Client Secret\": {}".format(
                self.data_keys["ClientSecret"]))

        else:
            logger.warn(
                "\"Other Header Info\" is set to None, so client id and secret cannot be extracted")

        logger.debug(
            "completed the process of extracting the header info from the Catalog Request")

    def extract_services_end_point_url(self):
        '''
		input: None
		operation:
			- this will extract more info from the service
			-
		output: None
        '''
        logger = logging.getLogger()

        logger.debug("starting the extraction of information from ServicesEndPointURL")

        try:
            # get the index of http
            http_loc = self.data_keys["ServicesEndPointURL"].index("http")
            
            # extracting service type
            service_type = self.data_keys["ServicesEndPointURL"][:http_loc].strip(" :")
            if(len(service_type)>0):
                self.data_keys["ServiceType"] = service_type
                logger.info("\"ServiceType\" has been extrcated successfully with a value of \"{}\"".format(service_type)) 

            # get the index of com
            com_loc = self.data_keys["ServicesEndPointURL"].index("com")
            
            # so, starting from "http" to "com" is the complete url 
            start = http_loc
            end = com_loc+len("com")
            
            # check if the port is present
            if(self.data_keys["ServicesEndPointURL"][end] == ":"):
                # port is present
                end += 1
                # loop unitil number is present ... i.e. port 
                while(end < len(self.data_keys["ServicesEndPointURL"]) and self.data_keys["ServicesEndPointURL"][end].isnumeric()):
                    end += 1
            
            server_name = self.data_keys["ServicesEndPointURL"][start:end]
            self.data_keys["ServerName"] = server_name

            logger.info("\"ServerName\" has successfully been extracted from ServicesEndPointURL with a value of \"{}\".".format(server_name))
            
        except:
            start = 0
            end = 0
            logger.warn("No HTTP,COM in the \"ServicesEndPointURL\" so the \"ServerName\" cannot be extracted")
        
        # POST:https://esbhdp-api.bsc.bscal.com:8888/private/releasetest/api/bsc/gateway/idcard/print/v1

        # get the location of startig of "/bsc"
        if("/bsc" in self.data_keys["ServicesEndPointURL"]):
            # /bsc was found and everything before /bsc would be considered as server_path
            start = end
            end = self.data_keys["ServicesEndPointURL"].index("/bsc")
        else:
            # no /bsc was found in the link 
            end = start
            logger.warn("no \"/bsc\" was found in the \"ServicesEndPointURL\"")

        server_path = self.data_keys["ServicesEndPointURL"][start:end].strip()
        if(len(server_path)>0):
            self.data_keys["ServerPath"] = server_path
            logger.info("\"ServerPath\" has been extracted successfully from ServicesEndPointURL with a value of \"{}\"".format(server_path))
        else:
            logger.warn("\"ServerPath\" couldn't be extracted from the \"ServicesEndPointURL\"")

        service_url = self.data_keys["ServicesEndPointURL"][end:].strip()
        if(len(service_url)>0):
            self.data_keys["ServiceURL"] = service_url
            logger.info("\"ServiceURL\" has been extracted successfully from \"ServicesEndPointURL\" with a value of \"{}\"".format(service_url))
        else:
            logger.warn("\"ServiceURL\" couldn't be extracted from the \"ServicesEndPointURL\"")

        logger.debug("completed the extraction of information from ServicesEndPointURL")


# # -----------------------------------------------------------------------------------------

#         logger = logging.getLogger()

#         if(self.data_keys["ServicesEndPointURL"] != None and ":" in self.data_keys["ServicesEndPointURL"]):
#             l = self.data_keys["ServicesEndPointURL"].split(":")
#             logger.debug("Info extrcated from \"ServicesEndPointURL\": {} are as below:".format(
#                 self.data_keys["ServicesEndPointURL"]))

#             self.data_keys["ServiceType"] = l[0].strip()
#             logger.debug("\"ServiceType\": {}".format(
#                 self.data_keys["ServiceType"]))

#             self.data_keys["ServiceName"] = ":".join(l[1:-1])
#             port = False

#             if(l[-1].split("/")[0].strip().isnumeric()):
#                 port = True
#                 self.data_keys["ServiceName"] += ":" + \
#                     l[-1].split("/")[0].strip()
#             logger.debug("\"ServiceName\": {}".format(
#                 self.data_keys["ServiceName"]))

#             try:
#                 if(port):
#                     new_l = l[-1].split("/")[1:]
#                 else:
#                     new_l = l[-1].split("/")

#                 bsc_index = new_l.index("bsc")

#                 self.data_keys["ServicePath"] = "/" + \
#                     "/".join(new_l[:bsc_index]).strip()
#                 logger.debug("\"ServicePath\": {}".format(
#                     self.data_keys["ServicePath"]))

#                 self.data_keys["ServiceURL"] = "/" + \
#                     "/".join(new_l[bsc_index:]).strip()
#                 logger.debug("\"ServiceURL\": {}".format(
#                     self.data_keys["ServiceURL"]))

#             except:
#                 logger.debug("Cannot extract ServicePath and ServiceURL from \"ServicesEndPointURL\" because \"bsc\" was not found in {}".format(
#                     self.data_keys["ServicesEndPointURL"]))
#         else:
#             logger.debug("Cannot extract info from ServicesEndPointURL")

    def jsonify(self, key):
        '''
		input:
			key: given the key of the self.data_keys, which we need to jsonify
		operation:
			it conevrts the string to json object
		output: None
        '''
        logger = logging.getLogger()

        logger.debug("staring the process of jsonifying the content")

        if(self.data_keys[key] != None):
            # key is present
            self.data_keys[key] = json.loads(self.data_keys[key])

            logger.debug(
                "\"{}\" has been converted to json and can be found below".format(key))
            logger.debug(json.dumps(self.data_keys[key], indent=4))
        else:
            # key not present
            logger.debug(
                "Cannot convert to json for \"{}\", as the value is None".format(key))

        logger.debug("completed the process of jsonifying the content")

    def initialize_environment_variables(self):
        '''
		input: None
		operation:
			this initializes the enviornment variables
		output: None
        '''

        logger = logging.getLogger()

        logger.debug("initializng the enviornment variables")

        # self.target_rooth_path is the name of the root directory in where atrget direcotry would be present
        # NOW HANDLED ABOVE 
        # self.target_root_path = os.path.join(target_root_name
        #     self.current_directory, self.target_root_name)

        # self.target_dir_name is just the name of the directory
        self.target_dir_name = self.data_keys["Test Suite Name"] + \
            "_"+self.data_keys["Test Method Name"]

        # self.target_dir_path is the complete path fo teh target direcotry
        self.target_dir_path = os.path.join(
            self.target_root_path, self.target_dir_name)

        self.target_script_name = self.data_keys["Test Method Name"]

        logger.debug(
            "completed the process of initializng the enviornment variables")

    def copy_scripts_from_src_to_target(self):
        '''
		input: None
		operation:
			copies the content in src_dir_path to the target_dir_path
		output: None
        '''

        logger = logging.getLogger()

        logger.debug(
            "starting the process of copying the files from source to directory to the target directory")

        # an update would be made if the fiel ends with test.htm
        if(self.data_keys["Auth URL"].strip().endswith("test.htm")):
            # auth url ends with test.htm

            logger.debug(
                "the auth url ends with \"test.htm\" so the value of src_dir_name would be updated to \"testing\"")

            self.src_dir_name = "testing"
            logger.debug("updated src_dir_name={}".format(self.src_dir_name))

            self.src_dir_path = os.path.join(
                self.src_root_path, self.src_dir_name)
            logger.debug("updated src_dir_path={}".format(self.src_dir_path))

        # check if the file path already exists
        if(os.path.exists(self.target_dir_path)):
            logger.debug("the  target dir path where we are copying already exists, so deleting the {}".format(
                self.target_dir_path))
            shutil.rmtree(self.target_dir_path)

        logger.debug("copying conent from {} to {}".format(
            self.src_dir_path, self.target_dir_path))
        shutil.copytree(self.src_dir_path, self.target_dir_path)

        logger.debug(
            "completed the process of copying the files from source to directory to the target directory")

    def change_dir_and_file_name(self):
        '''
		input: None
		operation:
            makes changes in the file name and the dir name in the target folder
		output: None
        '''

        logger = logging.getLogger()

        logger.debug(
            "starting the process of changing the names of direcory and file names")

        # change the names of the files ending with these extensions
        filesEndingWith = [".usr", ".prm"]

        for f in os.listdir(self.target_dir_path):
            for e in filesEndingWith:
                if(f.endswith(e)):
                    old_path = os.path.join(self.target_dir_path, f)
                    new_path = os.path.join(
                        self.target_dir_path, self.target_dir_name+"."+f.split(".")[-1])

                    logger.debug("found {} that ends with \"{}\" renaming {} to {}".format(
                        f, e, old_path, new_path))
                    os.rename(old_path, new_path)

        # list of files to rename ....  from src_dir_name to target_dir_path
        list_of_file_to_rename = [self.src_dir_name+".c", self.src_dir_name+"_W.dat", self.src_dir_name+"_F.dat", self.src_dir_name+"_W.sql",
                                  self.src_dir_name+"_F.sql", "z"+self.src_dir_name+".c", "z"+self.src_dir_name+".json"]

        for file_name in list_of_file_to_rename:
            old_name = os.path.join(self.target_dir_path, file_name)
            if(os.path.exists(old_name)):
                new_name = os.path.join(self.target_dir_path, file_name.replace(
                    self.src_dir_name, self.target_script_name))
                os.rename(old_name, new_name)
                logger.info("renamed {} to {}".format(old_name, new_name))
            else:
                logger.warn("no such file path:{}".format(old_name))

        # to replace text the contetn from the file with the next text
        Util.replace_text_in_file(os.path.join(self.target_dir_path,
                                               self.target_dir_name+".prm"), self.src_dir_name, self.target_script_name)

        logger.debug(
            "completed the process of changing the names of direcory and file names")

    def check_auth_url(self):
        '''
		input: None
		operation:  
            - checks if auth endabaled is true or false in  AIP_Automation.dat
            - if yes then 
            - reads the file AIP_Auth_MemAuth.h
            - and extracts the value of auth url from the file 
            - this is verified with the auth url in the data keys
		output: None
        '''
        # conditon which was asked to add .... point 4 in TO-DO

        logger = logging.getLogger()

        logger.debug("starting  the process of cross verifying the auth url")

        auth_file = os.path.join(self.target_dir_path, "AIP_Automation.dat")
        logger.debug("reading the value of auth enabled in {}".format(auth_file))
        
        automation_dat_file = DatFile(auth_file)
        # check the value of auth enabled 
        auth_enabled = automation_dat_file.get_key_value("AuthEnabled")

        if(auth_enabled != None and "yes" in [val.lower().strip() for val in auth_enabled]):
            # if auth enaled is "yes"

            logger.debug("auth enabled is 'yes'")
            
            logger.debug("cross verifying the auth url value")

            auth_url = self.data_keys["Auth URL"]
            
            logger.debug("auth url in data_keys is \"{}\"".format(auth_url))
            
            req_line = None

            with open(os.path.join(self.target_dir_path, "AIP_Auth_MemAuth.h"), "r") as f:
                start = False
                for line in f:
                    # to start looking only after we have seen [1] 
                    if("[1]" in line.strip()):
                        start = True
                    # and to stop looking after we have seen [2]
                    if("[2]" in line.strip()):
                        start = False
                    if(line.strip().startswith("//") == False and start == True):
                        if('"AIP_AuthServer"' in line):
                            req_line = line

            if(req_line != None):
                # if we are able to find the req_line using the method above
                url = req_line.split('"')[1]
                logger.debug("the value of auth url from file is \"{}\"".format(url))
            else:
                logger.warn("not able to get the value of auth url while reading the file")

            if(url != auth_url):
                logger.warn("both auth urls do not math each other. auth url in file:- {} . auth url read from the :{}".format(url, auth_url))
            else:
                logger.info("both the auth url match !!!")
            
        logger.debug("completed the process of cross verifying the auth url")


    def replace_string_in_files(self):
        '''
		input: None
		operation:
            - updates the contents invariosu files according to the info recieved in data keys
		output: None
        '''
        
        logger = logging.getLogger()

        logger.debug("starting the process of updating the contents of file")

        file_to_update = os.path.join(self.target_dir_path, "default.usp")
        logger.debug("updating the file {}".format(file_to_update))
        Util.replace_text_in_file(file_to_update, self.src_dir_name, self.target_script_name)
        
        file_to_update = os.path.join(self.target_dir_path, self.target_dir_name+".prm")
        logger.debug("updating the file {}".format(file_to_update))
        Util.replace_text_in_file(file_to_update, self.src_dir_name, self.target_script_name)
        

        # iterating over all files and replacing content in all file with the extension .usr
        for f in os.listdir(os.path.join(self.target_dir_path)):
            if(f.endswith(".usr")):
                file_to_update = os.path.join(self.target_dir_path, f)
                
                logger.debug("updating the file {}".format(file_to_update))
                
                Util.replace_text_in_file(file_to_update, "ParameterFile={}.prm".format(
                    self.src_dir_name), "ParameterFile={}.prm".format(self.target_dir_name))
                Util.replace_text_in_file(file_to_update, self.src_dir_name, self.target_script_name)
        
        file_to_update = os.path.join(self.target_dir_path, "z" + self.target_script_name+".c")
        logger.debug("updating the file {}".format(file_to_update))
        Util.replace_text_in_file(file_to_update, self.src_dir_name, self.target_script_name)

        logger.debug("completed the process fo updating the contents of file")

    def update_key_value_pair_in_automation_file(self):
        '''
		input: None 
		operation:
            update the values of various keys in the aip_automation.dat file based on the data_keys 
		output: None
        '''

        logger = logging.getLogger()

        logger.debug("starting the process of updating the automation file")

        # reading the content if the aip_automation.dat
        aip_automation_file = DatFile(os.path.join(
            self.target_dir_path, "AIP_Automation.dat"))

        # setting the key of "ScriptName" to the value of self.target_script_name
        logger.debug("updating the key \"{}\"".format("ScriptName"))
        aip_automation_file.set_key("ScriptName", self.target_script_name)
        
        # get the value of auth url
        value = self.data_keys["Auth URL"]
        
        # if the auth-url is not presrent
        if(len(value.strip()) == 0 or value == None):
            # then set the value of "AuthEnabled" to "No"
            logger.debug("updating the key \"{}\"".format("AuthEnabled"))
            aip_automation_file.set_key("AuthEnabled", "No")
        
        # updating the "ServiceComponentName" with the self.data_keys["Test Suite Name"] 
        logger.debug("updating the \"ServiceComponentName\" with the  \"{}\"".format(self.data_keys["Test Suite Name"]))
        aip_automation_file.set_key(
            "ServiceComponentName", self.data_keys["Test Suite Name"])
        
        # finally writing all the content to the file 
        logger.debug("writing all the updated details to the file")
        aip_automation_file.write_data()

        logger.debug("completed the process of updating the automation file")


    def update_key_value_pair_in_env_file(self):
        '''
		input: None
		operation:
            update the values of various keys in the aip_env.dat file based on the data_keys 
		output: None
        '''

        logger = logging.getLogger()

        logger.debug("starting the process of updating the key value pair in env file")

        # reading the dat aip_env file
        aip_env_file = DatFile(os.path.join(
            self.target_dir_path, "AIP_Env.dat"))
        
        # set the key "ServicesEndPointURL" fromt the data keys based on codition
        logger.debug("updating the key \"{}\"".format("ServicesEndPointURL"))
        
        if("bscedh1000" in self.data_keys["ServicesEndPointURL"]):
            aip_env_file.set_key("Env", "APIConnect")
        elif("esbhdp-api.bsc.bscal.com" in self.data_keys["ServicesEndPointURL"]):
            aip_env_file.set_key("Env", "Stage_DP")

        # try:
        #     # get the index of http
        #     http_loc = self.data_keys["ServicesEndPointURL"].index("http")
            
        #     # get the index of com
        #     com_loc = self.data_keys["ServicesEndPointURL"].index("com")
            
        #     # so, starting from "http" to "com" is the complete url 
        #     start = http_loc
        #     end = com_loc+len("com")
            
        #     # check if the port is present
        #     if(self.data_keys["ServicesEndPointURL"][end] == ":"):
        #         # port is present
        #         end += 1
        #         # loop unitil number is present ... i.e. port 
        #         while(end < len(self.data_keys["ServicesEndPointURL"]) and self.data_keys["ServicesEndPointURL"][end].isnumeric()):
        #             end += 1
            
        #     # set the key "Server" from the data keys based on codition 
        #     logger.debug("updating the key \"{}\"".format("Server"))
        #     aip_env_file.set_key(
        #         "Server", self.data_keys["ServicesEndPointURL"][start:end])
        # except:
        #     logger.warn("No HTTP,COM in the \"ServicesEndPointURL\"")
        
        # # POST:https://esbhdp-api.bsc.bscal.com:8888/private/releasetest/api/bsc/gateway/idcard/print/v1

        # try:
        #     # getting the index of "com"
        #     com_loc = self.data_keys["ServicesEndPointURL"].index("com")
            
        #     # get the ending point of "com"
        #     start = com_loc+len("com")
            
        #     if(self.data_keys["ServicesEndPointURL"][start] == ":"):
        #         # port is present
        #         start += 1
                
        #         # move further till the start index is present 
        #         while(start < len(self.data_keys["ServicesEndPointURL"]) and self.data_keys["ServicesEndPointURL"][start].isnumeric()):
        #             start += 1
        # except:
        #     start = 0
        
        # # get the location of startig of "/bsc"
        # end = self.data_keys["ServicesEndPointURL"].index("/bsc")
        
        logger.debug("updating the key \"{}\"".format("Server"))
        if("ServerName" in self.data_keys and self.data_keys["ServerName"]!=None):
            aip_env_file.set_key(
                "Server", self.data_keys["ServerName"])
        else:
            logger.warn("cannot update the key \"{}\" because its not present".format("Server"))

        logger.debug("updating the key \"{}\"".format("ServerPath"))
        if("ServerPath" in self.data_keys and self.data_keys["ServerPath"]!=None):
            aip_env_file.set_key(
                "ServerPath", self.data_keys["ServerPath"])
        else:
            logger.warn("cannot update the key \"{}\" because its not present".format("ServerPath"))

        # logger.debug("updating the key \"{}\"".format("ServerPath"))
        # aip_env_file.set_key(
        #     "ServerPath", self.data_keys["ServicesEndPointURL"][start:end])

        logger.debug("updating the key \"{}\"".format("ClientID"))
        aip_env_file.set_key("ClientID", self.data_keys["ClientID"])
        
        logger.debug("updating the key \"{}\"".format("ClientSecret"))
        aip_env_file.set_key("ClientSecret", self.data_keys["ClientSecret"])
        
        logger.debug("writing all the updated details to the file")
        aip_env_file.write_data()

        logger.debug("completed the process of updating the key value pair in env file")


    def update_key_value_pair_in_service_file(self):
        '''
		input: None
		operation:
			update the values of various keys in the AIP_Service.dat file based on the data_keys  
		output: None
        '''

        # getting logger instacne
        logger = logging.getLogger()
        
        logger.debug("starting the process of updating the key value pair in service file")

        # reading the dat aip_service file
        aip_service_file = DatFile(os.path.join(
            self.target_dir_path, "AIP_Service.dat"))
        
        # set the key "container" fromt the data keys
        logger.debug("updating the key \"{}\"".format("Container"))
        aip_service_file.set_key("Container", self.data_keys["Container"])
        
        # set the key "ServiceName" with the value self.target_script_name 
        logger.debug("updating the key \"{}\"".format("ServiceName"))
        aip_service_file.set_key("ServiceName", self.target_script_name)
        
        # updatig the key "ServiceURL" based on condition of availabaliy of "ServiceURL" 
        
        logger.debug("updating the key \"{}\"".format("ServiceURL"))
        if("ServiceURL" in self.data_keys and self.data_keys["ServiceURL"] != None):
            aip_service_file.set_key(
                "ServiceURL", self.data_keys["ServiceURL"])
        else:
            aip_service_file.set_key(
                "ServiceURL", self.data_keys["ServicesEndPointURL"])
        
        # updatig the key "JSONFileName" 
        logger.debug("updating the key \"{}\"".format("JSONFileName"))
        aip_service_file.set_key(
            "JSONFileName", self.target_script_name + ".json")
        
        # updatig the key "TestMethodName"  
        logger.debug("updating the key \"{}\"".format("TestMethodName"))
        aip_service_file.set_key("TestMethodName", self.target_script_name)
        
        # completeing the process and writing all the details in the file 
        aip_service_file.write_data()

        logger.debug("completed the process of updating the key value pair in service file")

    def request_json_update(self):
        '''
		input: None
		operation:
			- saves the current json to file
			- makes a deep copy of the original one and makes some changes for some key value pairs
			- then " is replaced with \" in every line and some more processing
			- then after everything is written to "z"+self.target_script_name+".c" file under a specific section
		output: None
        '''
        # getting logger instance
        logger = logging.getLogger()

        logger.debug(
            "starting the process of updating the request json and writing it in various files")

        # writing the =request json to a  file
        logger.debug("writing the Request JSON to {}".format(
            os.path.join(self.target_dir_path, self.target_script_name+".json")))
        
        with open(os.path.join(self.target_dir_path, self.target_script_name+".json"), "w") as f:
            json.dump(self.data_keys["Request JSON"], f, indent=4)

        # making a deep copy of the json so that the changes in the new copy hav no effct on the main copy
        logger.debug("making a deep copy of tthe data keys")
        updated_request = copy.deepcopy(self.data_keys)

        # some update in the updated_request before putting them into naoutehr file
        updated_request["Request JSON"]["requestHeader"]["consumer"][
            "requestDateTime"] = "{requestDateTime_val}"
        updated_request["Request JSON"]["requestHeader"][
            "consumer"]["hostName"] = "{hostName_val}"
        updated_request["Request JSON"]["requestHeader"][
            "transactionId"] = "{transId_val}"

        # converting the dictionary into list of strings line by line
        logger.debug("converting the dicionary inot list of strings")
        new_request_list = json.dumps(
            updated_request["Request JSON"], indent=4).split("\n")

        # replacing " with \"
        logger.debug('replaceing \" wiht \\" in everry line ')
        for i in range(len(new_request_list)):
            new_request_list[i] = new_request_list[i].replace("\"", '\\"')
            new_request_list[i] = '\"'+new_request_list[i].rstrip()+'\"'

        logger.debug(
            "making a sinle line of all the lines and adding a ; at the end")
        new_request_string = "\n".join(new_request_list)+";\n"

        logger.debug("updating the z" +
                     self.target_script_name+".c file content")
        
        # opening the file "z"+target_script_name+".c"
        with open(os.path.join(self.target_dir_path, "z"+self.target_script_name+".c")) as f:
            # making a temp file to save the updated data
            with open("temp_file.txt", "w") as f1:
                
                # a flag variable which would prevent reading a certain area of the file 
                stop = False
                
                for line in f:
                    if(stop == False):
                        f1.write(line)
                    
                    # if a line starts with request_json_base=
                    if("request_json_base=" in line):
                        stop = True
                    if(stop == True and ";" in line):
                        f1.write(new_request_string)
                        stop = False
        os.remove(os.path.join(self.target_dir_path,
                               "z"+self.target_script_name+".c"))
        os.rename("temp_file.txt", os.path.join(
            self.target_dir_path, "z"+self.target_script_name+".c"))

        logger.debug("storing all the changes in the file completed")

        logger.debug(
            "completed the process of updating the request json and writing it in various files")

    def automation_file_update(self,key,default_value):
        
        logger = logging.getLogger()

        # the variabe which would be used to update the sql rownum
        row_num = None
        # limit is put to infinity .... i.e. it would refer to all the number of rows we can have in the row
        limit = float("inf")

        for file in os.listdir(self.target_dir_path):
            if(file.endswith("Automation.dat")):
                file_to_process = os.path.join(self.target_dir_path, file)

                logger.debug(
                    "file found ending with {}".format(file_to_process))
                automation_dat_file = DatFile(file_to_process)

                logger.debug("setting default value of \"{}\" to \"{}\"".format(key,default_value))
                automation_dat_file.set_default_value(key, default_value)

                # storing the value of nfr_volume or production_volume 
                if(row_num==None):

                    # getting value of the key prod_volume
                    val_prod = automation_dat_file.get_key_value("prod_volume")
                    # getting value of the key NFR_Volume
                    val_nfr = automation_dat_file.get_key_value("NFR_Volume")
                    
                    # checking if the prod_volume value is present or not 
                    if(val_prod==None or len(val_prod)==0 or (len(val_prod)>0 and len(val_prod[0].strip())==0 )):
                        # prod_volume is not present 
                        logger.debug("value of prod_volume wasn't present so used nfr_volume")
                        row_num = val_nfr[0]
                    else:
                        # prod_volume is present
                        logger.debug("value of prod_volume wasn't present so used nfr_volume")
                        row_num = val_prod[0]

                    # limit would be set to nfr_volume from the uatomation file 
                    limit = int(val_nfr[0])

                logger.debug(
                    "confirming the changes by writing the changes back to the file")
                automation_dat_file.write_data()

                logger.debug(
                    "completed the setting up of default value of 'NFR_Volume' for file {}".format(file_to_process))
        
        return row_num, limit

    def clean_run_sql_write_dat_file(self, sql_query, dat_file_name, row_num, limit):
        
        logger = logging.getLogger()

        if(sql_query == None):
            logger.warn("No SQL Query found till now")
            return 

        # clean the sql query
        sql_query = Util.reformat_sql_query(sql_query, row_num)
        logger.debug("clear sql query below:")
        logger.debug(sql_query)

        # run the sql query found using mysqlconnectory
        # TODO .... update it to sql_query ... to be done by you
        file_path = os.path.join(self.target_dir_path, dat_file_name)
        Util.get_sql_result_in_file("SELECT * FROM table1", file_path=file_path,  limit=limit, mysqlconnector=True)
    

    def update_dat_file_from_sql(self):
        '''
		input: None
		operation:
            - sets the default value fo NFT_Volume key
            - looks for fat file and sql file pairs
            - if not present, it looks if only the sql file is present and creates a default dat file
            - if none of the above works, sql is extractd from the data_keys request
            - and the sql is run and the results are added in the dat file
		output: None
        '''
        
        # getting logger instance
        logger = logging.getLogger()
        logger.debug(
            "starting the process of working on sql and updating the dat")

        # looking for files ending with "Automation.dat"
        logger.debug("looking for files ending with 'Automation.dat'")

        row_num, limit = self.automation_file_update("NFR_Volume","5000")

        logger.debug(
            "completed editing for files ending with 'Automation.dat'")

        all_files = os.listdir(self.target_dir_path)
        sql_query = None
        self.dat_file_info = set()

        # looking for sql - dat pairs
        logger.debug("starting looking for sql and dat file pairs")
        for file_name in all_files:
            if(file_name.endswith("_W.dat") or file_name.endswith("_F.dat")):
                # rename file_name to dat_file_name
                dat_file_name = file_name

                if(dat_file_name.endswith("_W.dat")):
                    req_sql_file = dat_file_name[:-6]+"_W.sql"
                elif(dat_file_name.endswith("_F.dat")):
                    req_sql_file = dat_file_name[:-6]+"_F.sql"

                logger.debug("file name:{} and looking for:{}".format(
                    dat_file_name, req_sql_file))
                
                sql_query = Util.get_corresponding_sql_file(
                    self.target_dir_path, dat_file_name, req_sql_file, all_files)
                
                if(sql_query != None):
                    logger.info(
                        "found the required sql source for {}".format(dat_file_name))
                
                    self.clean_run_sql_write_dat_file(sql_query,dat_file_name,row_num,limit)
                    
                    sql_dat_file = DatFile(os.path.join(self.target_dir_path,dat_file_name))
                    
                    if(len(sql_dat_file.mapped_data)>0):
                        anchor_column_name = list(sql_dat_file.mapped_data.keys())[0]
                        for col_name in sql_dat_file.mapped_data:
                            self.dat_file_info.add((col_name,dat_file_name,anchor_column_name))
                else:
                    logger.warn("wasn't able to read the sql from \"{}\".".format(req_sql_file))


        # looking for sql files
        logger.debug(
            "no corresponding sql file was found ... now looking if any sql file exists ")
        for file_name in all_files:
            if(file_name.endswith("_W.sql") or file_name.endswith("_F.sql")):

                if(file_name.endswith("_W.sql")):
                    dat_file_name = self.target_script_name + "_W.dat"
                elif(file_name.endswith("_F.sql")):
                    dat_file_name = self.target_script_name + "_F.dat"

                logger.debug("sql file {} found and would be working with it and dat file {}".format(
                    file_name, dat_file_name))

                Util.clear_open_file(os.path.join(
                    self.target_dir_path, dat_file_name))
                    
                sql_query = Util.read_sql(os.path.join(
                    self.target_dir_path, file_name))

                if(sql_query != None):
                    logger.info(
                        "found the required sql source for {}".format(dat_file_name))
                    # self.sql_dat_file = dat_file_name

                    self.clean_run_sql_write_dat_file(sql_query,dat_file_name,row_num,limit)
                    
                    sql_dat_file = DatFile(os.path.join(self.target_dir_path,dat_file_name))
                    
                    if(len(sql_dat_file.mapped_data)>0):
                        anchor_column_name = list(sql_dat_file.mapped_data.keys())[0]
                        for col_name in sql_dat_file.mapped_data:
                            self.dat_file_info.add((col_name,dat_file_name,anchor_column_name))
                else:
                    logger.warn("wasn't able to read the sql from \"{}\".".format(file_name))

        # still no sql found
        logger.debug("looking for sql from the the request json")

        dat_file_name = self.target_script_name + "_W.dat"

        Util.clear_open_file(os.path.join(self.target_dir_path, dat_file_name))

        # reading sql from the data keys dictionary
        sql_query = Util.read_sql(self.data_keys, self.sql_field)

        # if the sql was fially found
        if(sql_query != None):
            logger.info(
                "found the required sql source for {}".format(dat_file_name))
            
            self.clean_run_sql_write_dat_file(sql_query,dat_file_name,row_num,limit)
                    
            sql_dat_file = DatFile(os.path.join(self.target_dir_path,dat_file_name))
            
            if(len(sql_dat_file.mapped_data)>0):
                anchor_column_name = list(sql_dat_file.mapped_data.keys())[0]
                for col_name in sql_dat_file.mapped_data.keys():
                    self.dat_file_info.add((col_name,dat_file_name,anchor_column_name))
        else:
            logger.warn("wasn't able to read the sql from \"{}\".".format("data_keys"))
        
        # self.clean_run_sql_write_dat_file_return_header(sql_query,row_num,limit)
        # if(sql_query == None):
        #     logger.warn("No SQL Query found till now")
        #     return 

        # # clean the sql query
        # sql_query = Util.reformat_sql_query(sql_query, row_num)
        # logger.debug("clear sql query below:")
        # logger.debug(sql_query)

        # # run the sql query found using mysqlconnectory
        # file_path = os.path.join(self.target_dir_path, self.sql_dat_file)
        # Util.get_sql_result_in_file("SELECT * FROM table1", file_path=file_path,  limit=limit, mysqlconnector=True)

        # logger.debug("adding RowCount coulumn")
        
        # for col_headers in data[0]:
        #     if(col_headers.lower().strip() == "RowCount".strip()):
        #         logger.info("we already have a column named \"{}\", so  new column won't be added".format(col_headers))
        #         break
        # else:             
        #     for i in range(1, len(data)):
        #         data[i].append("{:05}".format(i))
            
        #     DatFile.write_list_data_to_dat_file(os.path.join(
        #             self.target_dir_path, self.sql_dat_file), data)
            
        #     logger.info("added a column named \"{}\", so  new column could be added".format(col_headers))

        logger.debug(
            "completed the process of working on sql and updating the dat file")

    def update_prm_file_content(self):
        '''
		input: None
		operation:
            - making a DUP backup of the self.target_dir_name+".prm" file
            - adding a prefix of "Jbofy_" all the keys in self.sql_dat_file
            - sort all the keys by name in self.sql_dat_file
            - updating the content of the prm file
		output: None
        '''
        
        # getting logger instance
        logger = logging.getLogger()

        logger.debug(
            "starting the process of updating the content of prm files")

        prm_file_path = os.path.join(
            self.target_dir_path, self.target_dir_name+".prm")

        # making a backup file of the self.target_dir_name+".prm" file
        logger.debug(
            "backing up the original file {} so that we can edit the file later".format(prm_file_path))

        # checkig if the file exissits
        if(os.path.exists(prm_file_path)):
            # file exists
            
            # new method
            shutil.copyfile(prm_file_path, prm_file_path+".DUP")
            
            # old method 
            # with open(prm_file_path, "r") as file1:
            #     with open(prm_file_path+".DUP", "w") as file2:
            #         for line in file1:
            #             file2.write(line)
            
            logger.info("sucessfully backed up the file {} and the backup is {}".format(os.path.join(
                self.target_dir_path, self.target_dir_name+".prm"), os.path.join(self.target_dir_path, self.target_dir_name+".prm.DUP")))
        else:
            # file does not exists
            logger.warn("no such file exists {}").format(prm_file_path)

        logger.debug("completed the backing up the original file {} as {}".format(
            prm_file_path, prm_file_path+".DUP"))

        # adding "JBody_" prefix to all the keys and sorting the keys
        logger.debug(
            "started the process of adding 'JBody_' prefix to all the keys and sorting the keys")

        # dat_file = DatFile(os.path.join(
        #     self.target_dir_path, self.sql_dat_file))

        # # add prefix to all the keys
        # dat_file.add_prefix_to_all_keys("JBody_")
        # # sorting the keys
        # dat_file.sort_keys()
        # # writing the data back to the dat file
        # dat_file.write_data()

        logger.debug(
            "completed the process of adding 'JBody_' prefix to all the keys and sorting the keys")

        # diving the content of prm file into segments pbbaed on the sepaartearer
        logger.debug(
            "started the procss of updating the center_segement of the prm file")

        # 3 segments being returned after diving them using 2 segments
        top_segment, current_segment, bottom_segment = Util.divide_file_into_segments(prm_file_path,
                                                                                      ["[parameter:JBody_", "[parameter:Sys_DateTime]"])
        # list of all data segments
        data_segment = []

        # getting the path of AIP_Automation.dat file
        file_to_check_auth_enabled = os.path.join(
            self.target_dir_path, 'AIP_Automation.dat')

        # # make DatFile object of file
        # aip_automation_file = DatFile(file_to_check_auth_enabled)
        # # get the value of the key "AuthEnabled"
        # val = aip_automation_file.get_key_value("AuthEnabled")

        # if(len(val) > 0 and val[0].lower() == "yes"):
        #     # if "AuthEnabled" is yes
        #     logger.debug("auth enabled is 'yes'")

        #     logger.debug("getting login segment")

        #     login_segment = Util.get_segment(column_name="LOGIN",
        #                                      param_name="JBody_AuthMemLogin", select_next_row="Sequential", table="MemIDCardPrint_W.dat")

        #     logger.debug("getting password segment")
        #     password_segment = Util.get_segment(column_name="PASSWORD",
        #                                         param_name="JBody_AuthMemPSWD", select_next_row="Same line as JBody_AuthMemLogin", table="MemIDCardPrint_W.dat")

        #     logger.debug(
        #         "converting login segment to string and adding to the list")
        #     data_segment.append(Util.segment_to_string(login_segment))
        #     logger.debug(
        #         "converting password segment to string and adding to the list")
        #     data_segment.append(Util.segment_to_string(password_segment))

        # elif(len(val) > 0 and val[0].lower() == "no"):
        #     # if "AuthEnabled" is no

        #     logger.debug("auth endbled is 'no'")

        #     logger.debug("getting login segement")
        #     login_segment = Util.get_segment(column_name="LOGIN",
        #                                      param_name="JBody_AuthMemLogin", select_next_row="Sequential", table="MemIDCardPrint_W.dat")

        #     logger.debug(
        #         "converting login segment to string and adding to the list")
        #     data_segment.append(Util.segment_to_string(login_segment))

        # else:
        #     logger.warn(
        #         "the value of auth enabled was neither no, neither yes ... it was \"{}\"".format(val))

        
        # take headers from 1 dat file ...sort it ... make segments .... make sure making select_next_row field dynamic(from meeting)
        # and add to list ... then do it for multiple files ... then sort it again ... and then write o prm file  


        for col_seg in sorted(self.dat_file_info,key = lambda x: [i.lower() for i in x]):
            
            select_next_row_value = "Same line as JBody_"+col_seg[2]

            if(col_seg[0].lower().strip() == col_seg[2].lower().strip()):
                select_next_row_value = "Sequential"

            file_seg = Util.get_segment(column_name=col_seg[0],
                param_name="JBody_"+col_seg[0], select_next_row = select_next_row_value, table=col_seg[1])
            data_segment.append(Util.segment_to_string(file_seg))

        # # getting the list of headers in the dat file
        # logger.debug("getting the list of headers in the {}".format(
        #     dat_file.file_path))
        # headers = dat_file.get_key_list()

        # # going throught all the headers
        # for i in range(len(headers)):
        #     # getting actual column name
        #     col_name = headers[i].lstrip("JBody_")

        #     # getting the dictionary segment
        #     logger.debug("getting the {} segement".format(headers[i]))
        #     file_seg = Util.get_segment(column_name=col_name.upper(),
        #                                 param_name=headers[i], select_next_row="Same line as JBody_AuthMemLogin", table=self.sql_dat_file)

        #     # converting the segment o string and adding to list
        #     logger.debug(
        #         "converting {} segment to string and adding to the list".format(headers[i]))
        #     data_segment.append(Util.segment_to_string(file_seg))

        # writing all the segments in prm_file_path
        # logger.debug("wrting the updated segments to {}".format(prm_file_path))

        with open(prm_file_path, "w") as file:
            logger.debug("wrting top_segment to {}".format(prm_file_path))
            file.write("".join(top_segment).strip()+"\n")

            logger.debug("wrting data segement to {}".format(prm_file_path))
            file.write("".join(data_segment).strip()+"\n")

            logger.debug("wrting bottom to {}".format(prm_file_path))
            file.write("".join(bottom_segment).strip()+"\n")

        logger.debug("completed writing all the segements to the file")

        logger.debug(
            "completed the procss of updating the center_segement of the prm file")

        logger.debug(
            "completed the process of updating the content of prm files")

    def verifiy_dat_files(self):
        '''
		input: None
		operation:
										Varifies that all the .dat files have the correc format,
										i.e. they only have 1 empty line at the end
		output: None
        '''
        # getting logger instance
        logger = logging.getLogger()

        logger.debug("strting the process fo verifing the dat files")

        # iterating over all the files
        for file in os.listdir(self.target_dir_path):
            # checking ig the file is a dat file
            if(file.endswith(".dat")):
                # found the dat file

                logger.debug("found the dat file {}".format(file))
                dat_file = DatFile(os.path.join(self.target_dir_path, file))
                dat_file.write_data()
                logger.info(
                    "sucessfully verfied and updated the file {}".format(file))

        logger.debug("completed the process of varifying the dat file")

    def show(self):
        print(self.current_directory)
        print(self.src_dir_name)
        print(self.src_dir_path)
        print(self.src_root_path)
        print(self.target_dir_name)
        print(self.target_dir_path)
        print(self.target_root_path)
