import os
import shutil
import json
import logging
from collections import deque
import yaml
from CatalogRequest import CatalogRequest
from Util import Util


def get_processed_dict_data(file_dir, file_name, data_keys):
	'''
	input:
		file_dir: the current directory where we are working 
		file_name: the catalog file
		data_keys: the data keys where all the extarcted infromation would be stroed  
	operation:
		reading the file and extracting single catalogs from the testcatlog file and returing them one at a time   
	output:
		this is a generator function
		so as soon as one chunk of information is extracted from the testcatalog file
		that is returned chunk by chunk  
	'''
	
	file_path = os.path.join(file_dir, catalog_file_to_read)
	
	logger = logging.getLogger()
	logger.debug("Processing the catalog file: {}".format(file_path))

	with open(file_path, "r") as f:
		
		# this is to join the content for multi line content 
		prev_key_used = None

		for line in f:
			# this checks if any of the keys is present in the line 
			for key in data_keys:
				if(key.lower() in line.lower()):

					# if the key already has some value assigned to it, then we need to process the previous info  
					if(data_keys[key] != None):
						yield data_keys
						# this would refresh i.e. put all the values of all the keys to None
						Util.refresh_dict(data_keys)

					# if the key is present, then it is splitted by ":" and
					# value would be everything after ":" 
					value = ":".join(line.split(":")[1:]).strip()
					
					# assigning the value to the key
					data_keys[key] = value

					# stoing the key in prev_key_used
					# so that it is easy for append data for multi line data 
					prev_key_used = key
					break
			
			# if not present, then the information is assigned to the previous line 
			else:
				data_keys[prev_key_used] += line

		yield data_keys
		Util.refresh_dict(data_keys)

	logger.debug("Completed Processing the catalog file: {}".format(file_path))


if(__name__ == "__main__"):
	# start of the program 

	# getting the current directory ... independent of the OS on which it is running
	current_directory = os.getcwd()

	# loading the configuration file from config.yaml
	with open(os.path.join(current_directory, "config.yaml")) as file:
		config = yaml.load(file, Loader=yaml.FullLoader)

	# reading various values from the config file 
	catalog_file_to_read = config["catalog_file_name"]
	src_root_path = config["src_root_path"] #os.path.join(current_directory, config["src_root_name"])
	src_dir_name = config["src_dir_name"]
	log_file = config["log_file_name"]
	src_dir_path = os.path.join(src_root_path, src_dir_name)
	data_keys = {key: None for key in config["data_keys"]["keys"]}
	target_root_path = config["target_root_path"]
	alias_fields = config["data_keys"]["alias"]
	json_fields = config["data_keys"]["json_fields"] 
	cleanup_files_folders = config["cleanup"]
	sql_field = config["data_keys"]["sql_field"]	

	# setting up the logger 
	Util.setup_logger(os.path.join(current_directory, log_file))

	# backing up source directory .... i.e. Template/AIP_Mem_Profile/
	Util.backup(src_dir_path)

	# cleaning up the source directory with various conditons specifed .... i.e. Template/AIP_Mem_Profile/
	
	Util.cleanup_script_files(src_dir_path, cleanup_files_folders)
	
	# getting logger instance
	logger = logging.getLogger()

	# iterating over the chunks of information got 
	for key_value_pair in get_processed_dict_data(current_directory, catalog_file_to_read, data_keys):

		logger.debug("The parsed data is as below:")
		logger.debug(json.dumps(key_value_pair, indent=4))

		test_catalog = CatalogRequest(data_keys=key_value_pair, current_directory=current_directory,
									  src_root_path=src_root_path, src_dir_path=src_dir_path, 
									  src_dir_name= src_dir_name, target_root_path = target_root_path, 
									  sql_field = sql_field)

		test_catalog.data_formatting(alias_fields,json_fields)

		logger.debug("Data after data formatting:")
		logger.debug(json.dumps(key_value_pair, indent=4))

		print("Starting Initializing Environment Variables")
		test_catalog.initialize_environment_variables()
		print("Completed Initializing Environment Variables")
		
		print("Starting Copying Scripts from src to target")
		test_catalog.copy_scripts_from_src_to_target()
		print("Completed Copying Scripts from src to target")
		
		print("Starting Changing directory and filename")
		test_catalog.change_dir_and_file_name()
		print("Completed Changing directory and filename")
		
		print("Starting Checking Auth URL")
		test_catalog.check_auth_url()
		print("Completed Checking Auth URL")
		
		print("Starting Replacing String in files")
		test_catalog.replace_string_in_files()
		print("Completed Replacing String in files")
		
		print("Starting Updating Key Value-Pair in Automation file")
		test_catalog.update_key_value_pair_in_automation_file()
		print("Completed Updating Key Value-Pair in Automation file")
		
		print("Starting Updating key value pair in Env File")
		test_catalog.update_key_value_pair_in_env_file()
		print("Completed Updating key value pair in Env File")
		
		print("Starting Updating Key Value Pair in Service file")
		test_catalog.update_key_value_pair_in_service_file()
		print("Completed Updating Key Value Pair in Service file")
		
		print("Starting Updating Request JSON")
		test_catalog.request_json_update()
		print("Completed Updating Request JSON")
		
		print("Starting Updating dat File from SQL")
		test_catalog.update_dat_file_from_sql()
		print("Completed Updating dat File from SQL")
		
		print("Starting Updating prm File Content")
		test_catalog.update_prm_file_content()
		print("Completing Updating prm File Content")
		
		print("Starting Verifying dat Files")
		test_catalog.verifiy_dat_files()
		print("Completed Verifying dat files")
		
		print("------------------------------------")
	# end of program 