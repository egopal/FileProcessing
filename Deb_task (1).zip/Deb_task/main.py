
import os
import time

from utils.consolidate_data import consolidate
from utils.gen_max_file import generate_max_file
from utils.fill_max import find_max_for_all_months
from utils.write_to_xlsx import write_to_xlsx


dir_ = input("Enter name of the directory for csv files: ")

if not os.path.isdir(dir_):
    raise FileNotFoundError
year = input("Enter the year: ")

if len(year) != 4:
    raise ValueError

start = time.time()
# Fill all columns with data from all files except the Max(Month-Year) columns
consolidated_df = consolidate(dir_)

# Fill the Max(Month-Year) columns
consolidated_df = find_max_for_all_months(consolidated_df)

# Make a dataframe with the Max(Month-Year) columns only
max_df = generate_max_file(consolidated_df, list(consolidated_df.columns[:2]))

# Create directory for the given year
if not os.path.isdir(f'report_{year}'):
    os.system(f'mkdir report_{year}')

# Write files to the directory
write_to_xlsx(consolidated_df, f"report_{year}/consolidated_data_{year}.xlsx")
write_to_xlsx(max_df, f"report_{year}/max_consolidated_data_{year}.xlsx")

# Remove all files in the directory
# csv_files = os.path.join(dir_, '*.csv')
# os.system(f'mkdir -r {csv_files}')

print(f"\nDone....\nTotal time taken: {time.time() - start} sec")
