
def write_to_xlsx(df, output_file):
    """
        Inputs:
            df: The dataframe to write to excel file
            output_file: the file to write the dataframe to 
        Outputs:
            None
    """
    
    df.to_excel(output_file, index=False)
