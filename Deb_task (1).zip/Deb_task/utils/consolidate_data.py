
import os
import re
import glob
from collections import defaultdict
import pandas as pd

from utils.list_all_files import list_files_monthwise
from utils.read_basefile import read_basefile
from utils.config import *

# Consolidate data

def consolidate(dir_):
    """
        Inputs:
            dir_: The absolute path of the directory where the csv files exist
            
        Outputs:
            main_df: The dataframe with all the data consolidated with 'Max(<Month>-<Year>)' columns filled
    """
    
    all_months_dict = list_files_monthwise(dir_)
    
    main_df, base_cols = read_basefile(dir_)

    # if it is the basefile, check whether files for same month exist. If not fill Max column with those values
    first_list = all_months_dict[list(all_months_dict.keys())[0]]
    
    if len(first_list) == 1:
        date = re.search(r'\d{4}-\d{2}-\d{2}', first_list[0]).group()
        month = month_dict[date.split('-')[1]]
        year = date.split('-')[0]
        main_df['Max('+month+'-'+year+')'] = main_df[date]

    else:
        first_list.pop(0)
        for month, files in all_months_dict.items():
            for file in files:
                curr_df = pd.read_csv(file)

                # for common rows
                main_df = pd.merge(main_df, curr_df, how='left', on=base_cols)
                date = re.search(r'\d{4}-\d{2}-\d{2}', file).group()
                main_df[date] = main_df['count']
                main_df = main_df.drop(columns=['count'])


                # remove common rows
                cols = [*base_cols, date]
                curr_df = curr_df.rename(columns={'count': date})
                common = curr_df.merge(main_df, on=cols)[cols]
                x = pd.concat([curr_df, common])
                x = x.drop_duplicates(keep=False, ignore_index=True).dropna(axis='rows', how='all')

                # remaining rows to be copied into first dataframe
                main_df = main_df.append(x, sort=False, ignore_index=True)

        # fill all cells having NaN values with 0s
        main_df.fillna(0, inplace=True)
        
    return main_df
