
import pandas as pd

def find_max_for_all_months(df):
    """
        Inputs:
            df: The dataframe whose 'Max(<Month>-<Year>)' columns are to be filled
            
        Outputs:
            df: The dataframe with max for each month calculated
    """
    
    # Demarcate columns of a month finding the max among them
    max_col_indices = [i for i, j in enumerate(list(df.columns)) if 'Max' in j] + [len(df.columns)]
    
    for i in range(len(max_col_indices)-1):
        start, end = max_col_indices[i], max_col_indices[i+1]
        # Assign max values found to the Max(Month-Year) columns 
        df[df.columns[start]] = df[:][df.columns[start+1 : end]].max(axis='columns', numeric_only=True)
        
    return df
