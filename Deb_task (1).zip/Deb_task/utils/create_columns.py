
import os
import re
import glob
from collections import defaultdict
import pandas as pd

from utils.config import *


def date_list(month, index, year=2020):
    """
        Inputs:
            month: a 2 character string, eg, '01' for Jan, '02' for Feb
            index: values allowed are- 
                'odd' for 31 day months
                'even' for 30 day months
                'feb' for February
            year: the year, eg 1996, default is 2020
            
        Outputs:
            ret_list: A list for each day of a month with each element as a string of the form 
                      '<year>-<month>-<day>' 
    """
    
    
    # First column is the Max(Month-Year) column
    ret_list = ['Max(' + month_dict[month] + '-' + year + ')']
    end = None
    year = str(year)
    
    if index == 'feb':
        # check for leap year
        if (((int(year) % 4 == 0) and (int(year) % 100 != 0)) or (int(year) % 400 == 0)):
            end = 29
        else:
            end = 28
    # check for month having 31 days
    elif index == 'odd':
        end = 31
    else:
        end = 30
        
    for i in range(1, end+1):
        # to account for zeros while writing the day, eg 01, 21
        zeros = '0'*(2-len(str(i)))
        ret_list.append(f"{year}-{month}-{zeros}{i}")
        
    return ret_list


def create_columns(year=2020):
    """
        Inputs:
            year: the year, eg 1996, default is 2020
            
        Outputs:
            columns: A list for each day of a year with each element as a string of the form 
                     '<year>-<month>-<day>'. This list serves as columns for the consolidated dataframe
    """
    
    columns = []
    # The months which contain 31 days
    odd_months = ['01', '03', '05', '07', '08', '10', '12']
    
    for i in month_dict:
        if i in odd_months:
            columns += date_list(i, 'odd', year)
        else:
            if i == '02':
                columns += date_list(i, 'feb', year)
            else:
                columns += date_list(i, 'even', year)
                
    return columns
