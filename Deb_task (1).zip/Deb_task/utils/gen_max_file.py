
import pandas as pd

def generate_max_file(df, base_cols):
    """
        Inputs:
            df: The dataframe whose 'Max(<Month>-<Year>)' columns are to be filled
            base_cols: List of columns ['mpgw', 'api']
        Outputs:
            df: The dataframe for viewing only the max for each month of a year
    """
    
    max_cols = base_cols + [i for i in list(df.columns) if 'Max' in i]
    
    return df[max_cols]
