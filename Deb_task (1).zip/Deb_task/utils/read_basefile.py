
import os
import re
import glob
import pandas as pd

from utils.create_columns import create_columns

# Read basefile
def read_basefile(dir_):
    """
        Inputs:
            dir_: The absolute path of the directory where the base csv file exists
            
        Outputs:
            main_df: A dataframe with values copied from the basefile
            base_cols: List of columns ['mpgw', 'api']
    """
    
    # Find the basefile in dir_, assuming only one base file exists
    basefile = [i for i in glob.glob(os.path.join(dir_, '*.csv')) if 'basefile' in i.lower()][0]
    
    # fetch the date from the basefile
    date = re.search(r'\d{4}-\d{2}-\d{2}', basefile).group()

    base_df = pd.read_csv(basefile)
    # rename count column to date
    base_df = base_df.rename(columns={'count': date})
    # assuming first two columns are the columns common to all files
    base_cols = list(base_df.columns[:-1])
    
    main_df = pd.DataFrame(columns=base_cols + create_columns('2020'))       
    main_df[base_df.columns] = base_df[base_df.columns]
    
    return main_df, base_cols
