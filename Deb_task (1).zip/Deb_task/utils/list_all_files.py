
import os
import glob
from collections import defaultdict
from utils.config import *


def list_files_monthwise(dir_, year=2020):
    """
        Inputs:
            dir_: The absolute path of the directory where the csv files exist
            year: the year, eg 1996, default is 2020
            
        Outputs:
            all_months_dict: A dictionary with key=Month and value=filenames of the files for the given month
    """
    
    all_months = sorted([f for f in glob.glob(os.path.join(dir_, '*.csv')) if str(year) in f])
    all_months_dict = defaultdict(list)
    
    for month_file in all_months:
        month = month_file.split('-')[-2]
        all_months_dict[month_dict[month]].append(month_file)
        
    return all_months_dict
