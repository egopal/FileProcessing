__author__ = 'nicr'
import subprocess
from Rutility import *

if len(sys.argv) != 2:
    print "illegal arguments"
    exit(-1)

PATH=sys.argv[1]
SEP='\\'

echoFile(os.path.normcase(PATH + SEP + 'jobIdDebug.txt'), '=== killRemoteJob.py ===', 'a')
MYPID=[]
with open(os.path.normcase(PATH + SEP + 'jobIdentifier.txt'), 'r') as f:
    wordlist = [line.split(" ", 1)[0] for line in f]
MYPID.append(wordlist[0].rstrip())

echoFile(os.path.normcase(PATH + SEP + 'jobIdDebug.txt'), '=== call getHadoopStatus.py ===', 'a')
NOEXITDUMMY = subprocess.check_call("python getHadoopStatus.py " + PATH)
with open(os.path.normcase(PATH + SEP + 'jobStatus.txt'), 'r') as f:
    wordlist = [line.split(" ", 1)[0] for line in f]
MYSTATE=wordlist[0].rstrip()

if (MYSTATE ==  "running" ) or ( MYSTATE == "queued" ) or ( MYSTATE == "undetermined" ):
    for CURPID in MYPID:
        echoFile(os.path.normcase(PATH + SEP + 'jobIdDebug.txt'), 'Killing CURPID: ' + CURPID, 'a')
        p = pgrep("R.exe")
        MYTESTPID = grep(CURPID.strip(),p)
        if MYTESTPID == None:
            DUMMY=1234
            echoFile(os.path.normcase(PATH + SEP + 'jobIdDebug.txt'), 'Process not found', 'a')
        else:
            echoFile(os.path.normcase(PATH + SEP + 'killJobPidLog.txt'), str(MYTESTPID), 'a')
            kill_proc_tree(MYTESTPID)
            MYUUID=uuid.uuid4()
            fname = os.path.normcase(PATH + SEP + str(MYUUID))
            echoFile(fname, 'canceled', 'w')
            shutil.move(fname, PATH + SEP + 'jobStatus.txt')
time.sleep(1)
