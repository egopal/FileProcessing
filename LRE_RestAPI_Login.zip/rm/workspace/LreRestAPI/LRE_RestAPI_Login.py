import requests
import os
import urllib3

urllib3.disable_warnings()
# server = os.environ['lreorgprod4-pst.saas.microfocus.com']
# port = os.environ['']

# url = "https://lreorgprod4-pst.saas.microfocus.com/Loadtest/rest/authentication-point/authenticate?tenant=88aa399d-b069-4115-8058-82621b2e1755%27"
url = "https://rest.kegg.jp/link/pathway/hsa:10458+ece:Z5100"
page = requests.get(url, stream=True)
for line in page.iter_lines():
    print(line)

# lreUserName = os.environ['LRE_USER']
# lrePassword = os.environ['LRE_PASSWORD']
#
# def getCookie():
#     headers = {'Content-Type': "application/xml"}
#     response = requests.request("GET", url, headers=headers, auth=(lreUserName, lrePassword), verify=False)
#     cookies = response.cookies
#     returnCookie = None
#     for cookie in cookies:
#         returnCookie = cookie.value
#         break
#     return returnCookie
#
# def getHeaders():
#     headers = {'Content-Type': "application/xml"}
#     response = requests.request("GET", url, headers=headers, auth=(lreUserName, lrePassword), verify=False)
#     allheaders = response.headers
#     return allheaders

# print(getCookie())
