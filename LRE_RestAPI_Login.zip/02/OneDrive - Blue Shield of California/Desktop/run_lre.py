# Version 0.97
import requests
import  base64
import urllib3
import xml.etree.ElementTree as ET
import xml.dom.minidom
import  argparse
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from sys import exit

# Initiate the parser
parser = argparse.ArgumentParser(description='Run load test with LRE')

# Add long and short argument
parser.add_argument("--name", "-n", help="Test name", dest="test_name", required=True)
parser.add_argument("--server", "-s", help="Server name with http/https", dest="server", required=True)
parser.add_argument("--login", "-l", help="LRE login name", dest="first", required=True)
parser.add_argument("--password", "-p", help="LRE password", dest="second", required=True)
parser.add_argument("--domain", "-d", help="LRE domain", dest="domain", required=True)
parser.add_argument("--project", "-j", help="LRE project", dest="project", required=True)
parser.add_argument("--hours", "-th", help="timeslot duration in hours", required=True)
parser.add_argument("--minutes", "-tm", help="timeslot duration in minutes 00-59", required=True)

# Read arguments from the command line
args = parser.parse_args()

#if args.test_name:
#    print("Trying to start test "+args.test_name)
#exit()

hours=args.hours    #PARAM
minutes=args.minutes  #PARAM
server=args.server #PARAM
path=f"/LoadTest/rest/domains/{args.domain}/projects/{args.project}/" #PARAM

total=args.first+":"+args.second
encodedBytes = base64.b64encode(total.encode("utf-8"))
encodedStr = str(encodedBytes, "utf-8")
ssnOne = requests.Session()
url = server+'/LoadTest/rest/authentication-point/authenticate'
#print("Sending auth: "+encodedStr)
data = b"Basic "+encodedBytes
#data = encodedBytes
try:
    response = ssnOne.get(url, headers={"Authorization":data}, verify=False)
    print("Auth status: " + str(response.status_code))
except Exception as err:
    print(str(err))
    exit(1)
#print(ssnOne.cookies.get_dict())

if response.status_code != 200:
    xml = xml.dom.minidom.parseString(response.content.decode("utf-8"))
    print(xml.toprettyxml(newl=""))
    exit(2)
#exit()

print("Requesting test list...")
url = server+path+"tests"
response = ssnOne.get(url, headers={'Accept':'application/xml'}, verify=False)
#print(response.content)
#print("*"+str(response.content,"utf-8")+"*")
# Change to call
#tree = ET.parse("tests3.xml") # Из файла
#root = tree.getroot()
# From response
root = ET.fromstring(response.content.decode("utf-8") ) 
found=0
count=0
for child in root.iter():
#    print(child.tag)
    if child.tag == '{http://www.hp.com/PC/REST/API}ID':
        #print(child.tag+" # "+child.text.strip())
        count+=1
        i = child.text.strip()
    if child.tag == '{http://www.hp.com/PC/REST/API}Name':
        name=child.text.strip()
        #print("Name: "+name)
        if name == args.test_name: #PARAM
            found+=1
            id=i
            testname=name
if found==1:
    print(f"Found one test: '{testname}' with ID:{id} ({count} tests total)")
elif found>1:
    print("Error! More than one '"+args.test_name+"' test found")
    exit(3)
else:
    print("Error! Test named '"+args.test_name+"' not found")
    exit(4)

#exit()
#GET Test instance ID (testid in docs, but only test-id works with PC)
url = server+path+'testInstances?query={test-id["'+id+'"]}'
#print(url)

response = ssnOne.get(url,headers={'Accept':'application/xml'}, verify=False) #headers={'Accept':'application/xml'}, verify=False
print("Get instance status: " + str(response.status_code))
if response.status_code != 200:
#    print(response.content) #BYTES
    xml = xml.dom.minidom.parseString(response.content.decode("utf-8"))
    print(xml.toprettyxml(newl=""))
    exit(5)

responseXml = ET.fromstring(response.content.decode("utf-8"))
#instId = responseXml[0][2].text
#for ti in responseXml.iter('TestInstanceID'):
#        print(ti.text)
#print("Done")
#instId=responseXml.find('TestInstance').find('TestInstanceID').text
##for ti in responseXml.findall('{http://www.hp.com/PC/REST/API}TestInstance'):
##    print(ti.find('{http://www.hp.com/PC/REST/API}TestInstanceID').text)
instId=responseXml.find('{http://www.hp.com/PC/REST/API}TestInstance').find('{http://www.hp.com/PC/REST/API}TestInstanceID').text
print("Instance Id "+instId)
print("Ready to start "+args.test_name)
url = server+path+'Runs'

#Do Not Collate -Add transfer via parameter
#Collate Results 
#Collate And Analyze

data = '''<Run xmlns="http://www.hp.com/PC/REST/API">
 <PostRunAction>Collate Results</PostRunAction>
<TestID> '' ' + id + ' '' </TestID>
 <TestInstanceID>'''+instId+'''</TestInstanceID>
 <TimeslotDuration>
  <Hours>'''+hours+'''</Hours>
  <Minutes>'''+minutes+'''</Minutes>
 </TimeslotDuration>
 <VudsMode>false</VudsMode>
</Run>'''
#print(data)
#print(url)

#### Именно Content-type, не Accept
response = ssnOne.post(url, data=data, headers={'Content-Type':'application/xml'}, verify=False) 
#response = ssnOne.post(url, data=data, headers={'Content-Type':'application/xml'}, verify=False)
#print(response.status_code)
#print(response.content)
print("Run status: " + str(response.status_code))
#b'<Run xmlns="http://www.hp.com/PC/REST/API">\r\n  <TestID>23227</TestID>\r\n  <TestInstanceID>47518</TestInstanceID>\r\n  <PostRunAction>Collate And Analyze</PostRunActi
#on>\r\n  <TimeslotID>1197</TimeslotID>\r\n  <VudsMode>false</VudsMode>\r\n  <ID>190243</ID>\r\n  <Duration>0</Duration>\r\n  <RunState>Initializing</RunState>\r\n</Run>'
if response.status_code != 201:
#    print(response.content) #BYTES
    xml = xml.dom.minidom.parseString(response.content.decode("utf-8"))
    print(xml.toprettyxml(newl=""))
    exit(6)
else:
    responseXml = ET.fromstring(response.content.decode("utf-8"))
    runId=responseXml.find('{http://www.hp.com/PC/REST/API}ID').text
    ts=responseXml.find('{http://www.hp.com/PC/REST/API}TimeslotID').text
    print(f"Test is initializing. Run ID {runId} with Timeslot {ts}.")
# Add test wait (with parameter) with this ID