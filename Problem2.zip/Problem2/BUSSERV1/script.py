import os 
import shutil
import json

sourceDir = "Template"
backupDir = "Template_backup"
targetDir = None
targetScriptName = None

# 0) Back up the Template or Scripts Dir
def backup(source,target):
    try:
        shutil.copytree(source,target)
        print("backed up {source} at {target}".format(source=source,target=target) )
    except:
        print("already backed up")

backup(sourceDir,backupDir)


# 1) Read the file TestCatalog.txt containing multiple sets
#    ALWAYS READ AS KEY PAIR VALUE (We may end up using .csv file also (Column/Row mapping))
#    Get the First set of data (this is structured)
#    Save it as dict (key-pair)
#    The key value we need, get it from the TestCatalog.txt file :
# 	TestSuiteName: 
# 	TestMethodName:  This is same as Test Operation Name 
# 	Container:  This is same as JVM
# 	AuthURL: 
# 	AuthToken: 
# 	OtherHeaderInfo: 
# 	ServicesEndPointURL: 
# 	RequestJSON: 
#     SQLQueryforData:
# 	ResponseJSON:
#     SQLQueryForVerification:
# 	TestExecutionStatus:
	
# 	-> Parse the Other Header Info: 9875-6ttutu-763, ClientSecret:h;sppewmkjkjjhjhjhjhjhhggfs_ds'
# 	You will get two additional key and value as
# 		ClientID: 9875-6ttutu-763
# 		ClientSecret: h;sppewmkjkjjhjhjhjhjhhggfs_ds'
# 	From the ServicesEndPointURL POST:https://esbhdp-api.bsc.bscal.com:8888/private/releasetest/api/bsc/gateway/idcard/print/v1
# 	You will get the following four additional key and value
# 		ServiceType: POST
# 		ServerName: https://esbhdp-api.bsc.bscal.com:8888
# 		ServerPath: /private/releasetest/api
# 		ServiceURL: /bsc/gateway/idcard/print/v1
# 	Some times some values won't present
	
#     RequestJSON should not have empty lines. - 	Format the JSON using a JSON formatter.
# 	In the TestCatalog first example it is alreay formatted, In the second example it is not.

def data_formatting(data_keys):
    if(data_keys["Test Operation Name"]!=None and data_keys["Test Method Name"]==None):
        data_keys["Test Method Name"] = data_keys["Test Operation Name"]
    
    if(data_keys["JVM"]!=None and data_keys["Container"]==None):
        data_keys["Container"] = data_keys["JVM"].strip()
    
    if(data_keys["ServicesEndPoint URL"]!=None and data_keys["ServicesEndPointURL"]==None):
        data_keys["ServicesEndPointURL"] = data_keys["ServicesEndPoint URL"].strip()

    if(data_keys["Other Header Info"]!=None):
        l = data_keys["Other Header Info"].split(",")
        data_keys["ClientID"],data_keys["ClientSecret"] = "".join(l[:1]).strip(), ",".join(l[1:]).strip()
    
    if(data_keys["ServicesEndPointURL"]!=None and ":" in data_keys["ServicesEndPointURL"]):
        l = data_keys["ServicesEndPointURL"].split(":")
        data_keys["ServiceType"] = l[0].strip()
        data_keys["ServiceName"] = ":".join(l[1:-1])
        port = False
        if(l[-1].split("/")[0].strip().isnumeric()):
            port = True
            data_keys["ServiceName"] += ":"+l[-1].split("/")[0].strip()
        try:
            if(port):
                new_l = l[-1].split("/")[1:]
            else:
                new_l = l[-1].split("/")
            
            bsc_index = new_l.index("bsc")
            data_keys["ServicePath"] = "/"+"/".join(new_l[:bsc_index]).strip()
            data_keys["ServiceURL"] = "/"+"/".join(new_l[bsc_index:]).strip()
        except:
            print("BSC was not found in ServicesEndPointURL")

    if(data_keys["Request JSON"]!=None):
        data_keys["Request JSON"] = json.loads(data_keys["Request JSON"])
    
    if(data_keys["Response JSON"]!=None):
        data_keys["Response JSON"] = json.loads(data_keys["Response JSON"])


def edit_file(file_name,prev_text,new_text):
    temp_file = "temp.txt"
    with open(file_name,"r") as f:
        with open(temp_file,"w") as f1:
           for i in f:
                f1.write(i.replace(prev_text,new_text))
    os.remove(file_name)
    os.rename(temp_file,file_name)

def process_data(data_keys):
    
    data_formatting(data_keys)

    # 2) DEFINE;
    # targetDir         -> (Value of the key TestSuiteName) +"_"+(Value of the key TestMethodName)
    # targetScriptName  -> (Value of the key TestMethodName)
    global targetDir
    global targetScriptName
    targetDir = data_keys["Test Suite Name"]+"_"+data_keys["Test Method Name"]
    targetScriptName = data_keys["Test Method Name"]
    print("targetDir:",targetDir)
    print("targetScriptName:",targetScriptName)

    # define: srcDir
    sd = "AIP_Mem_Profile"
    if(data_keys["Auth URL"].strip().endswith("test.htm")):
        srcDir = os.path.join(sourceDir,"testing")
    else:
        srcDir = os.path.join(sourceDir,sd)
    print("sd:",sd)
    print("srcDir:",srcDir)
    # TODO This srcDir needs to be cleaned as given on the top (First 19 lines of this doc explains that)

    try:
        shutil.copytree(srcDir, targetDir)
    except:
        print(targetDir,"already exisists")

    # ->Change the Following File names with TargetDirName
    # Files ending with 
    #   *.usr
	#   *.prm
    filesEndingWith = [".usr",".prm"]
    for f in os.listdir(targetDir):
        for e in filesEndingWith:
            if(f.endswith(e)):
                os.rename(os.path.join(targetDir,f),os.path.join(targetDir,targetDir+"."+f.split(".")[-1]))

    # ->Change the Following File names with targetScriptName
    #   srcDir+".c" will become targetScriptName
	#   srcDir"_W.dat" will become targetScriptName+"_W.dat" or srcDir+"_F.dat" will become targetScriptName+"_F.dat"
	#   srcDir+"_W.sql" will become targetScriptName+"_W.sql" or srcDir+"_F.sql" will become targetScriptName+"_F.sql"
	#    (This will have changes in .prm file)
	#   "z"+srcDir.c to "z"+targetScriptName+".c"
	#   "z"+srcDir.json to "z"+targetScriptName+".json"
    l = [sd+".c",sd+"_W.dat", sd+"_F.dat", sd+"_W.sql", sd+"_F.sql", "z"+sd+".c", "z"+sd+".json"]
    for i in l:
        try:
            os.rename(os.path.join(targetDir,i),os.path.join(targetDir,i.replace(sd,targetScriptName))) 
        except:
            print("NO SUCH FILE:",os.path.join(targetDir,i))
    # (This will have changes in .prm file)
    edit_file(os.path.join(targetDir,targetDir+".prm"),sd,targetScriptName)
    
    # 5) Update the File Contents

    # Replace the text srcDir to targetScriptName in all of the file contents below
    
    # a) default.usp
    # b) targetDir.prm (same as Files ending in .prm
    # c) *.usr (
    #     ParameterFile=targetDir.prm
    #     For others, replace srcDir with targetScriptName
    #     )
    #     d) srcDir+".c"
    edit_file(os.path.join(targetDir,"default.usp"),sd,targetScriptName)
    for f in os.listdir(targetDir):  
        if(f.endswith(".usr")):
            # ParameterFile=AIP_Mem_Profile.prm
            edit_file(os.path.join(targetDir,f),"ParameterFile={}.prm".format(sd),"ParameterFile={}.prm".format(targetDir))
            edit_file(os.path.join(targetDir,f),sd,targetScriptName)
    edit_file(os.path.join(targetDir,"z"+targetScriptName+".c"),sd,targetScriptName)
    
    # 6) Update the Files ending with .Dat File Content
    # a) AIP_Automation.dat
    #     Read the file
    #     Key pair value
    #     For Key=ScriptName, the value should be targetScriptName
    #     If AuthURL is Null (para 3 above), then Set for Key=AuthEnabled,  the value should be No
    #     For the key= ServiceComponentName, the value is the Value of the key TestSuiteName
    with open(os.path.join(targetDir,"AIP_Automation.dat"),"r") as f:
        data = []
        for line in f:
            data.append(line.split(","))
    for i in range(len(data[0])):
        if(data[0][i].strip().lower()=="ScriptName".strip().lower()):
            data[1][i] = targetScriptName
        if(data[0][i].strip().lower()=="AuthEnabled".strip().lower()):
            if(len(data_keys["Auth URL"].strip())==0):
                data[1][i] = "No"
        if(data[0][i].strip().lower()=="ServiceComponentName".strip().lower()):
            data[1][i] = data_keys["Test Suite Name"]
    with open(os.path.join(targetDir,"AIP_Automation.dat"),"w") as f:
        f.write(",".join(data[0]))
        f.write(",".join(data[1]))
    

    # C) AIP_Env.dat
    #     Read the file
    #     Key pair value
    #     Env -> the value is from ServiceEndPointUrl from TestCatalog (Step 1) 
    #             if the value contains "bscedh1000"
    #                 then the value of Env is "APIConnect"
    #             if the value contains "esbhdp-api.bsc.bscal.com"
    #                 then the value of Env is "Stage_DP"
    #     Server-> the value is from ServiceEndPointUrl from TestCatalog (Step 1) 
    #             The value starts from http and ends at .com plus port (if any). It is possible not to have a Port
    #     ServerPath-> The value is from ServiceEndPointUrl from TestCatalog (Step 1) 
    #             The value starts from the end of Server (as above) but before /bsc
    #     ClientID -> (Step 1) 
    #     ClientSecret -> (Step 1)
    with open(os.path.join(targetDir,"AIP_Env.dat"),"r") as f:
        data = []
        for line in f:
            data.append(line.split(","))
    
    for i in range(len(data[0])):
        if(data[0][i].strip().lower()=="Env".strip().lower()):
            if("bscedh1000" in data_keys["ServicesEndPointURL"]):
                data[1][i] = "APIConnect"
            elif("esbhdp-api.bsc.bscal.com" in data_keys["ServicesEndPointURL"]):
                data[1][i] = "Stage_DP"
        
        if(data[0][i].strip().lower()=="Server".strip().lower()):
            try:
                http_loc = data_keys["ServicesEndPointURL"].index("http")
                com_loc = data_keys["ServicesEndPointURL"].index("com")
                start = http_loc
                end = com_loc+len("com")
                if(data_keys["ServicesEndPointURL"][end]==":"):
                    # port is present
                    end+=1
                    while(end<len(data_keys["ServicesEndPointURL"]) and data_keys["ServicesEndPointURL"][end].isnumeric()):
                        end+=1
                data[1][i] = data_keys["ServicesEndPointURL"][start:end]
            except:
                print("NO HTTP,COM in the ServicesEndPointURL")
        
        if(data[0][i].strip().lower()=="ServerPath".strip().lower()):
            try:
                com_loc = data_keys["ServicesEndPointURL"].index("com")
                start = com_loc+len("com")
                if(data_keys["ServicesEndPointURL"][start]==":"):
                    # port is present
                    start+=1
                    while(start<len(data_keys["ServicesEndPointURL"]) and data_keys["ServicesEndPointURL"][start].isnumeric()):
                        start+=1
                print("##",start,data_keys["ServicesEndPointURL"][start])
            except:
                start = 0
            end = data_keys["ServicesEndPointURL"].index("/bsc")
            data[1][i] = data_keys["ServicesEndPointURL"][start:end]
        
        if(data[0][i].strip().lower()=="ClientID".strip().lower()):
            data[1][i] = data_keys["ClientID"]
        
        if(data[0][i].strip().lower()=="ClientSecret".strip().lower()):
            data[1][i] = data_keys["ClientSecret"]
    

    # with open(os.path.join(targetDir,"AIP_Service.dat"),"w") as f:
    #     f.write(",".join(data[0]))
    #     f.write(",".join(data[1]))

    # b) AIP_Service.dat
    #     Read the file
    #     Key pair value
    #     For Key=Container, the value should be Container from TestCatalog (Step 1)
    #     For Key=ServiceName, the value is targetScriptsName
    #     For Key=ServiceURL, the value is from the ServicesEndPointURL from TestCatalog (Step 1)
    #         Parse the value and get value starting from /bsc so in this case it will be /bsc/gateway/idcard/print/v1		  
    #     For JSONFileName, the value is targetScriptName+".json"
    #     For TestMethodName, the value should be TestMethodName from TestCatalog (Step 1)
    #             which is same as targetScriptName
    with open(os.path.join(targetDir,"AIP_Service.dat"),"r") as f:
        data = []
        for line in f:
            data.append(line.split(","))
    
    for i in range(len(data[0])):
        if(data[0][i].strip().lower()=="Container".strip().lower()):
            data[1][i] = data_keys["Container"]
        if(data[0][i].strip().lower()=="ServiceName".strip().lower()):
            data[1][i] = targetScriptName 
        if(data[0][i].strip().lower()=="ServiceURL".strip().lower()):
            if("ServiceURL" in data_keys and data_keys["ServiceURL"]!=None):
                data[1][i] = data_keys["ServiceURL"]
            else:
                data[1][i] = data_keys["ServicesEndPointURL"] 
        if(data[0][i].strip().lower()=="JSONFileName".strip().lower()):
            data[1][i] = targetScriptName +".json"
        if(data[0][i].strip().lower()=="TestMethodName".strip().lower()):
            data[1][i] = targetScriptName

    with open(os.path.join(targetDir,"AIP_Service.dat"),"w") as f:
        f.write(",".join(data[0]))
        f.write(",".join(data[1]))

    # 7) File content changes  .json (Later we can sync this with row from AIP_Service.dat)
    #         Empty the existing file
    #         Write the value from RequestJSON from TestCatalog (Step 1) to targetScriptName+".json" save and close the file.  Please make sure empty lines should not exist
    #         In the memory or as a variable Modify the RequestJSON as follows:
    #             Replace all the single " with \"
    #             In everyline begining put a "
    #             and Everyline end put another "
    #             No quotes for empty lines, means empty lines should not exist
    #         Now Update value for certain keys, specifically three values 
    #         In the requestHeader section (not requestBody) section, the value for the following key will be updated.
    #             "requestDateTime": "35",
    #             "hostName": "33hh",
    #             "transactionId": "AIP_Mem_IDCardPrint_0010001"	
    #         After update it will be changed to
    #             "\"requestDateTime\": \"{requestDateTime_val}\","
    #             "\"c\": \"{hostName_val}\","
    #             "\"transactionId\": \"{transId_val}\""
    #         Now, read the srcDir+".c" file
    #             Search for "request_json_base="
    #             If that exists and the next row starts with "{"   THEN DELETE THE LINE TILL YOU SEE ; (IT CAN APPEAR IN A SINGLE LINE OR IT COULD BE "}";  WITH OR WITHOUT SPACES
    #             Now Write all the updated JSON from the above steps.
    #         Save and Close the file.
    
    
    with open(os.path.join(targetDir,targetScriptName+".json"),"w") as f:
        json.dump(data_keys["Request JSON"], f,indent=4)
    
    data_keys["Request JSON"]["requestDateTime"] = "{requestDateTime_val}"
    data_keys["Request JSON"]["hostName"] = "{hostName_val}"
    data_keys["Request JSON"]["transactionId"] = "{transId_val}"

    new_request_list = json.dumps(data_keys["Request JSON"],indent = 4).split("\n")

    for i in range(len(new_request_list)):
        new_request_list[i] = new_request_list[i].replace("\"",'\\"')
        new_request_list[i] = '\"'+new_request_list[i].rstrip()+'\"'

    new_request_string = "\n".join(new_request_list)+";\n"

    with open(os.path.join(targetDir,"z"+targetScriptName+".c")) as f:
        with open("temp_file.txt","w") as f1:
            stop = False
            for line in f:
                if(stop==False):
                    f1.write(line)
                if("request_json_base=" in line):
                    stop = True
                if(stop==True and ";" in line):
                    f1.write(new_request_string)
                    stop = False
    os.remove(os.path.join(targetDir,"z"+targetScriptName+".c"))
    os.rename("temp_file.txt",os.path.join(targetDir,"z"+targetScriptName+".c"))




def refresh(data_keys):
    print(data_keys)
    for key in data_keys:
        data_keys[key] = None

data_keys = {
    "Test Suite Name": None,
    "Test Method Name":None,
    "Test Operation Name": None,
    "Container": None,
    "JVM": None,
    "Auth URL": None,
    "Auth Token": None,
    "Other Header Info": None,
    "ServicesEndPointURL":None,
    "ServicesEndPoint URL": None,
    "Request JSON": None,
    "SQL Query for Data": None,
    "Response JSON": None,
    "SQL Query to validate the data":None,
    "Test Execution Status": None
}

with open("TestCatalog.txt","r") as f:
    prev = None
    for line in f:
        for key in data_keys:
            if(key.lower() in line.lower()):
                if(data_keys[key]!=None):
                    process_data(data_keys)
                    refresh(data_keys)
                data_keys[key] =  ":".join(line.split(":")[1:]).strip()
                prev = key
                break
        else:
            data_keys[prev] += line
    process_data(data_keys)
    refresh(data_keys)
    