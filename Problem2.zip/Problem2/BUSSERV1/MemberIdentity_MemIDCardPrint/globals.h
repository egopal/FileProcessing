#ifndef _GLOBALS_H
#define _GLOBALS_H

//--------------------------------------------------------------------
// Include Files
#include "lrun.h"
#include "web_api.h"
#include "lrw_custom_body.h"
#include "Utils.c"
#include "AIP_Auth_MemAuth.h"
#include "AIP_Initialize.h"
#include "AIP_ResponseAnalysis.h"
#include <time.h>   // for gettimeofday()

//#include "C:\\Projects\\AIP\\CustomCode\\AIP_WriteToFile.h"

//--------------------------------------------------------------------
// Global Variables

char *request_json_base;
char *request_json;
char *transStatus;
char *hostName;
char TestDataBuffer[];
char transName[50]="";    // May need modification
char transId_val;
char *OAUTH_Token;
  	
double transDuration;

#endif // _GLOBALS_H