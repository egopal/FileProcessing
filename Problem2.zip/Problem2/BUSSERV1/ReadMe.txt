-----------------------------
The following are complete:
-----------------------------

Delete Unwanted Files from SourceDir

a) Delete result1 folder
b) Delete Files Starting with combined_
c) Delete Files Ending with
		all *.idx
		all *.bak
		all *.txt
		all *.tmp
		all *.sdf
		all *.log
		all *c.pickle
		all *.ci
		all *.xml
d) File name pre_cci.c 		

-----------------------------
To Do:
-----------------------------


0) Back up the Template or Scripts Dir

1) Read the file TestCatalog.txt containing multiple sets
   ALWAYS READ AS KEY PAIR VALUE (We may end up using .csv file also (Column/Row mapping))
   Get the First set of data (this is structured)
   Save it as dict (key-pair)
   The key value we need, get it from the TestCatalog.txt file :
	TestSuiteName: 
	TestMethodName:  This is same as Test Operation Name 
	Container:  This is same as JVM
	AuthURL: 
	AuthToken: 
	OtherHeaderInfo: 
	ServicesEndPointURL: 
	RequestJSON: 
    SQLQueryforData:
	ResponseJSON:
    SQLQueryForVerification:
	TestExecutionStatus:
	
	-> Parse the Other Header Info: 9875-6ttutu-763, ClientSecret:h;sppewmkjkjjhjhjhjhjhhggfs_ds'
	You will get two additional key and value as
		ClientID: 9875-6ttutu-763
		ClientSecret: h;sppewmkjkjjhjhjhjhjhhggfs_ds'
	From the ServicesEndPointURL POST:https://esbhdp-api.bsc.bscal.com:8888/private/releasetest/api/bsc/gateway/idcard/print/v1
	You will get the following four additional key and value
		ServiceType: POST
		ServerName: https://esbhdp-api.bsc.bscal.com:8888
		ServerPath: /private/releasetest/api
		ServiceURL: /bsc/gateway/idcard/print/v1
	Some times some values won't present
	
    RequestJSON should not have empty lines. - 	Format the JSON using a JSON formatter.
	In the TestCatalog first example it is alreay formatted, In the second example it is not.

2) DEFINE;
targetDir         -> (Value of the key TestSuiteName) +"_"+(Value of the key TestMethodName)
targetScriptName  -> (Value of the key TestMethodName)

3) From Source (Template Dir and Files) Copy to Target Dir

   DEFINE SrcDir:
   The SrcDir is selected based on AuthURL
   If AuthURL== "\test.htm"
      SourceDir = C:template\testing
   else then 
     default src directory 
	  SrcDir	 = AIP_Mem_Profile
	  SrcDirPath = \Template\AIP_Mem_Profile
   
   This srcDir needs to be cleaned as given on the top (First 19 lines of this doc explains that)

   PERFORM COPY DIR 
   shutil.copytree(srcDir, targetDir) 
   




4) Rename the Files in the TargetDirectory
   ->Change the Following File names with TargetDirName
    Files ending with 
      *.usr
	  *.prm
   ->Change the Following File names with targetScriptName
      srcDir+".c" will become targetScriptName
	  srcDir"_W.dat" will become targetScriptName+"_W.dat" or srcDir+"_F.dat" will become targetScriptName+"_F.dat"
	  srcDir+"_W.sql" will become targetScriptName+"_W.sql" or srcDir+"_F.sql" will become targetScriptName+"_F.sql"
	   (This will have changes in .prm file)
	  "z"+srcDir.c to "z"+targetScriptName+".c"
	  "z"+srcDir.json to "z"+targetScriptName+".json"
	     
5) Update the File Contents

   Replace the text srcDir to targetScriptName in all of the file contents below
   
   a) default.usp
   b) targetDir.prm (same as Files ending in .prm
   c) *.usr (
	  ParameterFile=targetDir.prm
	  For others, replace srcDir with targetScriptName
	  )
	d) srcDir+".c"
	

6) Update the Files ending with .Dat File Content
   a) AIP_Automation.dat
	  Read the file
	  Key pair value
	   For Key=ScriptName, the value should be targetScriptName
	   If AuthURL is Null (para 3 above), then Set for Key=AuthEnabled,  the value should be No
	   For the key= ServiceComponentName, the value is the Value of the key TestSuiteName
   C) AIP_Env.dat
       Read the file
	   Key pair value
	   Env -> the value is from ServiceEndPointUrl from TestCatalog (Step 1) 
	          if the value contains "bscedh1000"
				then the value of Env is "APIConnect"
		      if the value contains "esbhdp-api.bsc.bscal.com"
				then the value of Env is "Stage_DP"
	   Server-> the value is from ServiceEndPointUrl from TestCatalog (Step 1) 
	          The value starts from http and ends at .com plus port (if any). It is possible not to have a Port
	   ServerPath-> The value is from ServiceEndPointUrl from TestCatalog (Step 1) 
	   		  The value starts from the end of Server (as above) but before /bsc
	   ClientID -> (Step 1) 
	   ClientSecret -> (Step 1) 
   b) AIP_Service.dat
	  Read the file
	  Key pair value
	   For Key=Container, the value should be Container from TestCatalog (Step 1)
	   For Key=ServiceName, the value is targetScriptsName
	   For Key=ServiceURL, the value is from the ServicesEndPointURL from TestCatalog (Step 1)
           Parse the value and get value starting from /bsc so in this case it will be /bsc/gateway/idcard/print/v1		  
	   For JSONFileName, the value is targetScriptName+".json"
	   For TestMethodName, the value should be TestMethodName from TestCatalog (Step 1)
	          which is same as targetScriptName


7) File content changes  .json (Later we can sync this with row from AIP_Service.dat)
		Empty the existing file
		Write the value from RequestJSON from TestCatalog (Step 1) to targetScriptName+".json" save and close the file.  Please make sure empty lines should not exist
		In the memory or as a variable Modify the RequestJSON as follows:
		    Replace all the single " with \"
			In everyline begining put a "
			and Everyline end put another "
			No quotes for empty lines, means empty lines should not exist
        Now Update value for certain keys, specifically three values 
		In the requestHeader section (not requestBody) section, the value for the following key will be updated.
			"requestDateTime": "35",
			"hostName": "33hh",
			"transactionId": "AIP_Mem_IDCardPrint_0010001"	
		After update it will be changed to
			"\"requestDateTime\": \"{requestDateTime_val}\","
			"\"hostName\": \"{hostName_val}\","
			"\"transactionId\": \"{transId_val}\""
		Now, read the srcDir+".c" file
			Search for "request_json_base="
			If that exists and the next row starts with "{"   THEN DELETE THE LINE TILL YOU SEE ; (IT CAN APPEAR IN A SINGLE LINE OR IT COULD BE "}";  WITH OR WITHOUT SPACES
			Now Write all the updated JSON from the above steps.
		Save and Close the file.

	
8) File exits with name ending with _W|F.dat and _W|F.sql
		If the file ending with _W.dat or _F.dat exits, Please check if the corresponding _W.sql file or _W.sql file exists 
		If not print the file that does not exists.
		If any of the _W.dat or _F.dat exists and their corresponding W_.sql or _F.sql file exist
         then
		 Read the first row (column header) save each value as a variable or key in Memory.		 
		 Empty the contents of the existing dat File
		   Run the corresponding sql against the Oracle db
		   Get the column name and write to the .dat file
		   Get the value and write to the .dat file
		   While writing each row,
		    read each cell and ensure no comma (,) exists in the value, which will make the row out of sync in .csv format (.dat file works as a .csv file)
		Save and close the file
		
   # -- Copy SQL, Execute SQL, Column Name to Dat File name, .prm File Changes
   # -- SQL wrapper for RowNum

