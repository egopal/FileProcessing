1) Read the template.txt file first row as columnHeader
   FirstName,LastName,DOB,Address,City,State 
   You will write the columnHeader names to a Output_example.csv file in the same order (same sequence, same names)

2) Read the FileToRead.txt file
   If you parse the file using Delimiter "~~", you will get two sets of records

3) From the first set, parse the data in a logical manner to write

4) You will extract and write the data in two rows in a csv format

5) The Output_example.txt you create should look like ExpectedOutput.csv file.

Processing Logic:
2) Write the column name as
   FirstName,LastName,DOB,Address,City,State 
1) Split the content by delimiter ~~
2) Now Process each row
   If it contains FirstName- Yes or No
   Yes, Write the FirstName to FirstName (then pop the data out)
   If No, find out if it contains the LastName
   Yes, Write the last name (then pop the data out)
   If No, Find out if it contains Name
   Yes, split and write to FirstName and LastName (then pop the data out)
   Now DOB, (see first row), parse and get the data and write to csv file (pop the data out)
   continue till State 
   now look at the remaining data
   the key is Notes and the the value is key data
   the Country is USA
   While parsing second set of row, You will get Place of Birth as a column key and the value "San Francisco"

Please note not all column can be present, or more column can be present.
Please note there will be multiple rows so you may have to loop through the row.
There will be multiple set of column/data rows starts with c:\ or empty lines.  
The text can be dictionary containing unstructured key pair value.
Need to write to the File in the same order as template and add relevant values from the FileToRead.txt file:
If no value, have the column name from template, and no need to add the data

