   
=====================================
Methods to support Main Section
=====================================


DeleteDir(srcRootDirPath, srcDir, DirName)
 if...
 else
 
 If NotFound(LogMessage)

CleanUpScriptFiles(srcRootDirPath, srcDir)
  The code is in the attached .py file

	Delete Unwanted Files from SourceDir
	The path is before the DirNameAnd you will zip the Dir
	Only one directory should be there in the zip, means it should not be zipped as Dir/dir/contents.

		a) Delete result1 folder
			DeleteDir(srcRootDirPath, srcDir, {"result1", "result2"})	
			
		b) DeleteFiles(srcRootDirPath, srcDir, startsWith, {"combined_", "testing"})
			
		c) DeleteFiles(srcRootDirPath, srcDir, endsWith, {".idx",".bak",".txt",".tmp",".log",".c.pickle})

			all *.idx
			all *.bak
			all *.txt
			all *.tmp
			all *.sdf
			all *.log
			all *c.pickle
			all *.ci
			all *.xml
			
		d) DeleteFiles(srcRootDirPath, srcDir, exactMatch, {"Pre_cci.c", "test.txt"})
	
ZipFile(srcRootDirPath, srcDir, zipRootDir, ZipDir)
   
	source
	target
	Code to Zip the file using the source and place it in target
   

JSONFormatter(String) - return JSON Formatted data in String Format
	
	RequestJSON should not have empty lines.	
	Format the JSON using a JSON formatter.


ProcessRawDataGetFinalDict(?)
    
		parse and get Key Pair value
		Save each data lines as Dict (key-pair) in the following standards
		TestSuiteName: 
		TestMethodName:  This is same as Test Operation Name 
		Container:  This is same as JVM
		AuthURL: 
		AuthToken: 
		OtherHeaderInfo: 
			Parse to get two additional key and value as
			ClientID: 9875-6ttutu-763
			ClientSecret: h;sppewmkjkjjhjhjhjhjhhggfs_ds'
		ServicesEndPointURL:
			From the ServicesEndPointURL POST:https://esbhdp-api.bsc.bscal.com:8888/private/releasetest/api/bsc/gateway/idcard/print/v1
			You will get the following four additional key and value
				ServiceType: POST
				ServerName: https://esbhdp-api.bsc.bscal.com:8888
				ServerPath: /private/releasetest/api
				ServiceURL: /bsc/gateway/idcard/print/v1
				Some times some values won't present				
		RequestJSON: 
			JSONFormatter(String)			
		SQLQueryforData:
		ResponseJSON:
		SQLQueryForVerification:
		TestExecutionStatus:
	Return ProcessedKeyPairData


SrcDirToClone(srcRootDirPath+srcDir, tartgetRootDirPath, AuthURL)

	The SrcDir is selected based on AuthURL
		If AuthURL== "\test.htm"
			SourceDir = "C:template\testing"
		else
			srcRootDirPath+"\\"+srcDir   #default src directory
			
        PERFORM COPY DIR 
	    shutil.copytree(srcRootDirPath+"\\"+srcDir, tartgetRootDirPath)


ChangeFileNames(Path, targetDir)

    Files = {".usr", ".prm"}
		->Change the Following File names with TargetDirName
			Files ending with 
			*.usr
			*.prm


ChangeFileNames(Path, targetScriptName)
		
		This method is same as above, so either you need to have a distinct method name or put a logic in place to handle it.

		->Change the Following File names with targetScriptName
			srcDir+".c" will become targetScriptName
			srcDir"_W.dat" will become targetScriptName+"_W.dat" or srcDir+"_F.dat" will become targetScriptName+"_F.dat"
			srcDir+"_W.sql" will become targetScriptName+"_W.sql" or srcDir+"_F.sql" will become targetScriptName+"_F.sql"
			(This will have changes in .prm file)
			"z"+srcDir.c to "z"+targetScriptName+".c"
			"z"+srcDir.json to "z"+targetScriptName+".json"


ReplaceStringInFiles(Path, sourceName, targetDir, targetScriptName )
    sourceName - Existing String
	targetScriptName - New String
	
		a) 	default.usp
		b) 	targetDir.prm (same as Files ending in .prm
		c) 	*.usr (
				ParameterFile=targetDir.prm
				For others, replace srcDir with targetScriptName
			)
		d) 	srcDir+".c"

	   
ReadDatFileGetKeyPairValue(FilePath, FileName)  # Added to support next three functions and more
		Read the file
		Key pair value
    Return Dict


UpdateDatFile(FilePath, FileName, Key, value)   /// Use this function as much as possible
	If not success, Log it
	
	
UpdateAIPAutomationFile(FilePath, AIP_Automation.dat, ProcessedKeyPairData)
		For File read Use ReadDatFileGetKeyPairValue(FilePath, FileName)
		
		For Key=ScriptName, the value should be targetScriptName
		The ProcessedKeyPairData contains AuthURL.
		If AuthURL is Null (para 3 above), then Set for Key=AuthEnabled, the value should be No
		For the key= ServiceComponentName, the value is the Value of the key TestSuiteName
		
		For Key Value update, Use UpdateDatFile fn 
		If you open file, close file


UpdateAIPEnvFile(FilePath, AIP_Env.dat, ProcessedKeyPairData)
		For File read Use ReadDatFileGetKeyPairValue(FilePath, FileName)
		
		Env -> the value is from ServiceEndPointUrl from ProcessedKeyPairData 
			  if the value contains "bscedh1000"
				then the value of Env is "APIConnect"
			  if the value contains "esbhdp-api.bsc.bscal.com"
				then the value of Env is "Stage_DP"
		Server-> the value is from ServiceEndPointUrl from ProcessedKeyPairData 
			  The value starts from http and ends at .com plus port (if any). It is possible not to have a Port
		ServerPath-> The value is from ServiceEndPointUrl from ProcessedKeyPairData 
			  The value starts from the end of Server (as above) but before /bsc
		ClientID -> From ProcessedKeyPairData
		ClientSecret -> From ProcessedKeyPairData
	   
	   	For Key Value update, Use UpdateDatFile fn 
		If you open file, close file


UpdateAIPServiceFile((FilePath, AIP_Service.dat, targetScriptsName, ProcessedKeyPairData)
		For File read Use ReadDatFileGetKeyPairValue(FilePath, FileName)
	
		For Key=Container, the value should be From Container from ProcessedKeyPairData 
		For Key=ServiceName, the value is targetScriptsName
		For Key=ServiceURL, the value is from the ServicesEndPointURL from ProcessedKeyPairData 
			Parse the value and get value starting from /bsc so in this case it will be /bsc/gateway/idcard/print/v1		  
		For JSONFileName, the value is targetScriptName+".json"
		For TestMethodName, the value should be TestMethodName from ProcessedKeyPairData 
			which is same as targetScriptName
			
		For Key Value update, Use UpdateDatFile fn 
		If you open file, close file
			
ProcessJSon(FilePath, JSONFileName, targetScriptsName, ProcessedKeyPairData)	
	Empty the existing file if Exist
	Write the value from RequestJSON from TestCatalog to targetScriptName+".json" save and close the file.  Please make sure empty lines should not exist
	
	In the memory or as a variable Modify the RequestJSON as follows:
		    Replace all the single " with \"
			In everyline begining put a "
			and Everyline end put another "
			No quotes for empty lines, means empty lines should not exist
        Now Update value for certain keys, specifically three values 
		In the requestHeader section (not requestBody) section, the value for the following key will be updated.
	    	"requestDateTime": "35",
			"hostName": "33hh",
	    	"transactionId": "AIP_Mem_IDCardPrint_0010001"	
		After update it will be changed to
	        "\"requestDateTime\": \"{requestDateTime_val}\","
            "\"hostName\": \"{hostName_val}\","
            "\"transactionId\": \"{transId_val}\""
		Now, read the srcDir+".c" file
			Search for "request_json_base="
			If that exists and the next row starts with "{"   THEN DELETE THE LINE TILL YOU SEE ; (IT CAN APPEAR IN A SINGLE LINE OR IT COULD BE "}";  WITH OR WITHOUT SPACES
			Now Write all the updated JSON from the above steps.
		In the last line, ensure it ends with semi-colon once.
		
	Save and Close the file.

sqlFileProcess(?)
   
PrmFileUpdateForJSONData(?)

FinalCheck()
   

====================================
Main Section
====================================

CreateALogFile() in the busserv directory not inside clone

CleanUpScriptFiles(srcRootDirPath, srcDir)

#Backup Template

	srcRootDirPath = 
	srcDir =
	zipRootDir=
	ZipDir = 
	CleanUpScriptFiles(srcRootDirPath, srcDir)
	ZipFile(srcRootDirPath, srcDir, zipRootDir, ZipDir)

# ReadTheCatalogFileAndDefineTheData

	FileDir =
	FileName =
	actualPath =   srcRootDirPath+'\\'+FileDir+'\\'+FileName
	row=0
	delimiter="~~"
	fileType = txt
	tartgetRootDirPath =
   
 	
	Your Looping code looks good, reformat the inner calls to look like the steps given below
	with open(os.path.join(current_directory,catalogFileToRead),"r") as f:
	//f.open (fileName, "r")
	
	{
   		For Each DataSet
		parse/cleanup and get the Data Row in Key-Pair value(Dict) as ProcessedKeyPairData -> Create a Method call as ProcessRawDataGetFinalDict(?)
	       
		2) 	DEFINE;
			targetDir         -> (Value of the key TestSuiteName) +"_"+(Value of the key TestMethodName)
			targetScriptName  -> (Value of the key TestMethodName)

		3) 	From Source (Template Dir and Files) Copy to Target Dir
            SrcDirToClone(srcRootDirPath+srcDir, tartgetRootDirPath+?, AuthURL)
			
		4) 	Rename the Files in the TargetDirectory
			ChangeFileNames(Path?, targetDir)
			ChangeFileNames(Path?, targetScriptName)
		 
		5) 	Update the File Contents
			ReplaceStringInFiles(Path, sourceName, targetDir, targetScriptName )
	   
		6) 	Update the Files ending with .Dat File Content
			UpdateAIPAutomationFile(FilePath, AIP_Automation.dat, ProcessedKeyPairData)
			UpdateAIPEnvFile((FilePath, AIP_Env.dat, ProcessedKeyPairData)
			UpdateAIPServiceFile((FilePath, AIP_Service.dat, targetScriptsName, ProcessedKeyPairData)
			
		7) 	ProcessJSon(FilePath, JSONFileName, targetScriptsName, ProcessedKeyPairData)	
	   	
		8) 	sqlFileProcess(?)
   
		9) 	PrmFileUpdateForJSONData(?)
		
		10) FinalCheck()
   
	}
    
=====================================
ORIGINAL
=====================================

0) 	Back up the Template or Scripts Dir
      
1) 	Read the file TestCatalog.txt containing multiple sets
		ALWAYS READ AS KEY PAIR VALUE (We may end up using .csv file also (Column/Row mapping))
		Get the First set of data (this is structured)
		Save it as dict (key-pair)
		The key value we need, get it from the TestCatalog.txt file :
			TestSuiteName: 
			TestMethodName:  This is same as Test Operation Name 
			Container:  This is same as JVM
			AuthURL: 
			AuthToken: 
			OtherHeaderInfo: 
			ServicesEndPointURL: 
			RequestJSON: 
			SQLQueryforData:
			ResponseJSON:
			SQLQueryForVerification:
			TestExecutionStatus:
		
	-> 	Parse the Other Header Info: 9875-6ttutu-763, ClientSecret:h;sppewmkjkjjhjhjhjhjhhggfs_ds'
		You will get two additional key and value as
			ClientID: 9875-6ttutu-763
			ClientSecret: h;sppewmkjkjjhjhjhjhjhhggfs_ds'
		From the ServicesEndPointURL POST:https://esbhdp-api.bsc.bscal.com:8888/private/releasetest/api/bsc/gateway/idcard/print/v1
		You will get the following four additional key and value
			ServiceType: POST
			ServerName: https://esbhdp-api.bsc.bscal.com:8888
			ServerPath: /private/releasetest/api
			ServiceURL: /bsc/gateway/idcard/print/v1
		Some times some values won't present
	
		RequestJSON should not have empty lines. - 	Format the JSON using a JSON formatter.
		In the TestCatalog first example it is alreay formatted, In the second example it is not.
  
2) 	DEFINE;
		targetDir         -> (Value of the key TestSuiteName) +"_"+(Value of the key TestMethodName)
		targetScriptName  -> (Value of the key TestMethodName)

3) 	From Source (Template Dir and Files) Copy to Target Dir

	DEFINE SrcDir:
	The SrcDir is selected based on AuthURL
	If AuthURL== "\test.htm"
		SourceDir = C:template\testing
	else then 
		default src directory 
		SrcDir	 = AIP_Mem_Profile
		SrcDirPath = \Template\AIP_Mem_Profile
  
	PERFORM COPY DIR 
	shutil.copytree(srcDir, targetDir) 
   

4) 	Rename the Files in the TargetDirectory
	->	Change the Following File names with TargetDirName
		Files ending with 
			*.usr
			*.prm
   ->	Change the Following File names with targetScriptName
			srcDir+".c" will become targetScriptName
			srcDir"_W.dat" will become targetScriptName+"_W.dat" or srcDir+"_F.dat" will become targetScriptName+"_F.dat"
			srcDir+"_W.sql" will become targetScriptName+"_W.sql" or srcDir+"_F.sql" will become targetScriptName+"_F.sql"
			(This will have changes in .prm file)
			"z"+srcDir.c to "z"+targetScriptName+".c"
			"z"+srcDir.json to "z"+targetScriptName+".json"
			 
5) 	Update the File Contents

	Replace the text srcDir to targetScriptName in all of the file contents below
   
	a) 	default.usp
	b) 	targetDir.prm (same as Files ending in .prm
	c) 	*.usr (
			ParameterFile=targetDir.prm
			For others, replace srcDir with targetScriptName
		)
	d) 	srcDir+".c"
	

6) 	Update the Files ending with .Dat File Content
	a) 	AIP_Automation.dat
			Read the file
			Key pair value
			For Key=ScriptName, the value should be targetScriptName
			If AuthURL is Null (para 3 above), then Set for Key=AuthEnabled,  the value should be No
			For the key= ServiceComponentName, the value is the Value of the key TestSuiteName
	b) 	AIP_Env.dat
			Read the file
			Key pair value
			Env -> the value is from ServiceEndPointUrl from TestCatalog (Step 1) 
				  if the value contains "bscedh1000"
					then the value of Env is "APIConnect"
				  if the value contains "esbhdp-api.bsc.bscal.com"
					then the value of Env is "Stage_DP"
			Server-> the value is from ServiceEndPointUrl from TestCatalog (Step 1) 
				  The value starts from http and ends at .com plus port (if any). It is possible not to have a Port
			ServerPath-> The value is from ServiceEndPointUrl from TestCatalog (Step 1) 
				  The value starts from the end of Server (as above) but before /bsc
			ClientID -> (Step 1) 
			ClientSecret -> (Step 1) 
   c) 	AIP_Service.dat
			Read the file
			Key pair value
			For Key=Container, the value should be Container from TestCatalog (Step 1)
			For Key=ServiceName, the value is targetScriptsName
			For Key=ServiceURL, the value is from the ServicesEndPointURL from TestCatalog (Step 1)
			   Parse the value and get value starting from /bsc so in this case it will be /bsc/gateway/idcard/print/v1		  
			For JSONFileName, the value is targetScriptName+".json"
			For TestMethodName, the value should be TestMethodName from TestCatalog (Step 1)
				  which is same as targetScriptName


7) 	File content changes  .json (Later we can sync this with row from AIP_Service.dat)
		Empty the existing file
		Write the value from RequestJSON from TestCatalog (Step 1) to targetScriptName+".json" save and close the file.  Please make sure empty lines should not exist
		In the memory or as a variable Modify the RequestJSON as follows:
		    Replace all the single " with \"
			In everyline begining put a "
			and Everyline end put another "
			No quotes for empty lines, means empty lines should not exist
        Now Update value for certain keys, specifically three values 
		In the requestHeader section (not requestBody) section, the value for the following key will be updated.
	    	"requestDateTime": "35",
			"hostName": "33hh",
	    	"transactionId": "AIP_Mem_IDCardPrint_0010001"	
		After update it will be changed to
	        "\"requestDateTime\": \"{requestDateTime_val}\","
            "\"hostName\": \"{hostName_val}\","
            "\"transactionId\": \"{transId_val}\""
		Now, read the srcDir+".c" file
			Search for "request_json_base="
			If that exists and the next row starts with "{"   THEN DELETE THE LINE TILL YOU SEE ; (IT CAN APPEAR IN A SINGLE LINE OR IT COULD BE "}";  WITH OR WITHOUT SPACES
			Now Write all the updated JSON from the above steps.
		Save and Close the file.
	

8) 	SQL Operation to Create Data  
		
	Go to Automation.dat File, Find the value for the key NFRVolume
		If the value is found, then NFRVolume= value for the key "NFRVolume" in Automation.dat 
		If the value is not found, then NFRVolume=5000 ( a default volume)
			
    If you are reading the file from files, then
	    If the file ending with _W.dat or _F.dat exits, Please check if the corresponding _W.sql file or _W.sql file exists 
		If no sql file exists, print("No SQL Files found for "+targetDir + the dat file that is found, ending with _W.dat or _F.dat)
		Exit processing further and continue to check for others
		If any of the _W.dat or _F.dat exists and their corresponding W_.sql or _F.sql file exist
		then sqlFile = ending with (_W.dat or _F.dat)
         then Proceed
		 
	    Empty the contents of the existing dat File
		dataFileName = targetScriptName+"_F.dat" or targetScriptName+"_W.dat" 
	     		
	ProcessTheSQL sqlString
    Read the sqlString from the file 

	If you are reading from a Text File TestCatalog.txt, get it from the SQLQueryforData.
	If you are reading it from the _F.sql or _W.sql then get it from the relevant sql file.
		
	If more than one sql, loop.
	Read the first SQL from the file
	
	If text line is found, Modify the sql... remove the comment lines (single comment and multi line comment, and "--" and ";")
		Make the whole string as one without a next line 
        e.g. 	if ((!line.contains("\n"))) {
		        	sql.append(line);
	            	}
        If the sqlString contains rownum at the end and has value change the value to NFRVolume
		If the sqlString does not contain rownum and value at the end, then print Message "No RowNum is found in the .dat file"


	IGNORE 
	-------------
		If the sqlString contains (Facets or SBSB_ID or GRGR_ID) then 
		   connectionString =FAC_DB
		   if sqlFile does not exist (writetheStringToASQLFile(sqlString, targetScriptName+"_F.dat)) Close the sqlFile
		else the 
		   connectionString=SYSTEM_DB
		   if sqlFile does not exist (writetheStringToASQLFile(sqlString, targetScriptName+"_W.dat)) Close the sqlFile
		
		Make DB Connection(connectionString)
		 if (connectionString == FAC_DB)
		     connectDB = FacetsDB()
			 if dataFileName not defined earler, then
			 Create a file dataFileName = targetScriptName+"_F.dat", write mode
	
	     else (
		     connectDB = SystemDB()
			 if dataFileName not defined earler, then
			 Create a file dataFileName = targetScriptName+"_W.dat", write mode
		 )
		 
		ExecuteSQLusing the connection (connectDB, sqlString, dataFileName)
		If success,
		  Ready to write to the file dataFileName
		    
	PROCESS THE FOLLOWING Data Separately
	--------------------------
	
		Claims, Member, Address, City
		6666, 18328383, 2333 San Bruno, San Francisco
		7777, 23175678, 4355,CountryDrive, Fremont
		8888, 2318,2314, 1000,Whitehead, Union City,CA
		
		After processing only one record will survive.
		
		Anothe Data
		Memberid,CustomerId
		5000, 9999999
		99999, XEH123456
	
		The column count and comma count logic will be verified with above two sets of data
		
		Read each row and ensure no extra comma (,) exists in the value, which will make the row out of sync in .csv format (.dat file works as a .csv file)

		ProcessColumnName:
			Get Column headers, with comma delimiter value
			Count the number of columns  
			If the number of column is nc, then the number of comma is colCommaCount=nc-1
			If the column does not contain RowNum in the column name,
			write RowNum to the ColumnHeader in the same first row with comma prefix
		  
		Process Each row retuned by the server one by one till the last row in a Loop
			For the first row, get the count of comma, it should be equal to colCommaCount
			If it is not same as colCommaCount, ignore the row, do not write to the file
			If it is same as colCommaCount, then add 1 in a format 00001 for the row and write the data to the file.
			You will increment the RowCount by 1 when you write the data to the file.
		Go on a loop till you process NFRVolume
	
		Close the dataFileName.


9) SQL Impact on .prm File

    a) 	Backup the targetDir.prm File with targetDir.prm.DUP
		Ensure it is able to back up overriting a file if it exists

	b)	find how many column from the _W|F.dat file handled above
		For each column name, replace the name a prefix JBody_
		So the new values will be JBody_<theColumnName1>, JBody_<theColumnName2>, etc.
		Sort the JBody_columnname in ascending order
	
	Read the targetDir.prm file
	Split the segments as below
		topSegment
		dataSegment
		bottomSegment
	The segments can be a variable or file.
	
	Go to AIP_Automation.dat
	Find the value for the Key=AuthEnabled,
	If the AuthEnabled is No
	
	Search for the text starting with [parameter:JBody_
	If found, all the lines of code prior to that are to be saved as topSegment, pop all the previous lines
	Search for the next text starting with [parameter:Sys_DateTime]
	If found, save all the string including [parameter:Sys_DateTime] in to a bottomSegment
	Now the text left are dataSegment or simply a current segments
	Delete all the text in current segment, so we can recreate
	the following data can be saved as key pair value or just a text set, which will be modified
	
	YOU WILL CREATE A BLOCK OF DATA THAT WILL BE CALLED dataSegments, and they should be sorted by Parameter:JBody_
	
	Find the value for the Key=AuthEnabled,
	If the AuthEnabled is Yes
			We need to enure Login and Password data set
			c) 	For Login it will be 
					[parameter:JBody_AuthMemLogin]
					ColumnName="LOGIN"
					Delimiter=","
					GenerateNewVal="EachIteration"
					OriginalValue=""
					OutOfRangePolicy="ContinueWithLast"
					ParamName="JBody_AuthMemLogin"
					SelectNextRow="Sequential"
					StartRow="1"
					Table="MemIDCardPrint_W.dat"
					TableLocation="Local"
					Type="Table"
					auto_allocate_block_size="1"
					value_for_each_vuser=""
				The parameter: name for this is not same that of JBody_ColumnName
				Ensure the ColumnName value is same as the value of the column name in the dat file, IF NOT, FIND out the one similar to the LOGIN and enter that value here
				The table= value should be the correct dat file where this column name is available
				The parameter and the ParamName= values should match
			
			d)  For password
				[parameter:JBody_AuthMemPSWD]
					ColumnName="PASSWORD"
					Delimiter=","
					GenerateNewVal="EachIteration"
					OriginalValue=""
					OutOfRangePolicy="ContinueWithLast"
					ParamName="JBody_AuthMemPSWD"
					SelectNextRow="Same line as JBody_AuthMemLogin"
					StartRow="1"
					Table="MemIDCardPrint_W.dat"
					TableLocation="Local"
					Type="Table"
					auto_allocate_block_size="1"
					value_for_each_vuser=""
			
				The parameter: name for this is not same that of JBody_ColumnName
				Ensure the ColumnName value is same as the value of the column name in the dat file, IF NOT, FIND out the one similar to the password and enter that value here
				The Table= value should be the correct dat file where this column name is available
				The parameter and the ParamName= values should match
				Since this data depends on the Member Login id first, so SelectNextRow="Same line as JBody_AuthMemLogin"
				
			e)  Add additional data sets here
				[parameter:JBody_COLUMN_NAME]
					ColumnName="COLUMN_NAME"
					Delimiter=","
					GenerateNewVal="EachIteration"
					OriginalValue=""
					OutOfRangePolicy="ContinueWithLast"
					ParamName="JBody_COLUMN_NAME"
					SelectNextRow="Same line as JBody_AuthMemLogin"
					StartRow="1"
					Table="MemIDCardPrint_W.dat"
					TableLocation="Local"
					Type="Table"
					auto_allocate_block_size="1"
					value_for_each_vuser=""
				
			    The parameter: name for this is SAME that of JBody_ColumnName
				Ensure the ColumnName value is same as the value of the column name in the dat file ( SAME AS ABOVE WITHOUT THE JBody_ )
				The Table= value should be the correct dat file where this column name is available
				The parameter and the ParamName= values should match
				Since this data depends on the Member Login id first, so Set SelectNextRow="Same line as JBody_AuthMemLogin"
		
			d) Repeat the step c  for all other Data values
			
	If the AuthEnabled is No
	You will skip the a and b above which provides login and password
			No Login and Password data need to be set

			For the first JSON_ColumnName, you will do the following
			
					[parameter:JBody_AuthMemLogin]
					ColumnName="LOGIN"
					Delimiter=","
					GenerateNewVal="EachIteration"
					OriginalValue=""
					OutOfRangePolicy="ContinueWithLast"
					ParamName="JBody_AuthMemLogin"
					SelectNextRow="Sequential"
					StartRow="1"
					Table="MemIDCardPrint_W.dat"
					TableLocation="Local"
					Type="Table"
					auto_allocate_block_size="1"
					value_for_each_vuser=""
	
				The parameter: name for this is SAME that of JBody_ColumnName (9 b) the columnName is the first column in the dat file
				Ensure the ColumnName value is same as the value of the column name in the dat file ( SAME AS ABOVE WITHOUT THE JBody_ )
				The parameter and the ParamName= values should match
				Since this is the first data on the list, so it will be set up SelectNextRow="Sequential"
				The Table= value should be the correct dat file where this column name is available

		   Add additional data sets here
					[parameter:JBody_COLUMN_NAME]
					ColumnName="COLUMN_NAME"
					Delimiter=","
					GenerateNewVal="EachIteration"
					OriginalValue=""
					OutOfRangePolicy="ContinueWithLast"
					ParamName="JBody_COLUMN_NAME"
					SelectNextRow="Same line as JBody_AuthMemLogin"
					StartRow="1"
					Table="MemIDCardPrint_W.dat"
					TableLocation="Local"
					Type="Table"
					auto_allocate_block_size="1"
					value_for_each_vuser=""
				
			    The parameter: name for this is SAME that of JBody_ColumnName
				Ensure the ColumnName value is same as the value of the column name in the dat file ( SAME AS ABOVE WITHOUT THE JBody_ )
				The parameter and the ParamName= values should match
				Since this data depends on the previous data so Set SelectNextRow="Same line as JBody_AuthMemLogin" 
					Here you will replace with the right value for JBody_AuthMemLogin, it will be replaced with the previous Parameter value
					So, the correct value will be "JBody_ColumnName1", hence it will be SelectNextRow="Same line as JBody_ColumnName1" , this will be followed in all the subsequent JBody_Column segments
				The Table= value should be the correct dat file where this column name is available
		
			d) Repeat the above Additional data step for all other Data values
  

    ALL THE BLOCK OF DATASEGMENTS NOW BE MERGED IN TO A SINGLE FILE AS FOLLOWS
	In the file write the
		topSegment
	And then,
	    dataSegment
	And then,
	    bottomSegment
		
	The file name ends with .prm
	Please verify the line in .prm file and ensure that the text are in key value pair without no data mess.
	
	
10) Final Check
    Handle with methods
	Go through all the files ending in .dat  in the target directory
	1) Ensure the count of commas is same in each line, if not Log Message(TargetDir, DatFileName)
	2) Ensure only one empty line exists
		If no empty line, insert empty line
		If more than one empty line, delete all lines except one.
		
	
================================
Things to REMEMBER:
================================
1) Instead of relative path use actual path with the following changes:

	a)  Put a dirpath for srcRootPath, what I mean this that the root dir for the srcDir is like "C:\Projects\workspacePython32\BUSSERV1\Templates"
	b)  Put a dirPath for targetRootPath "C:\Projects\workspacePython32\BUSSER1\Clone"
	c)  Put a dirPath for Logs as logRootPath "C:\Projects\workspacePython32\BUSSERV1\"
	Use the path in and update the code to do the work
	
    d)  The targetDir should be placed inside the targetRootPath

	e)	The template backup should be placed inside Template dir itself as a .zip file
		So, it will be AIP_Mem_Profile.zip

	f) 	The log file should appear inside logRootPath


2)  Point 6 c

    The env value should be Stage_DP but not updated
    The Server address should be https://esbhdp-api.bsc.bscal.com:8888 (the port info is missing)
    The ServerPath should be /private/releasetest/api (/api is missing)
    ClientID -> (Step 1) the value should be updated in the AIP_Env.dat file
	ClientSecret -> (Step 1) the value should be updated in the AIP_Env.dat file 

	
3)  Point 7

   	Write the value from RequestJSON from TestCatalog (Step 1) to targetScriptName+".json" save and close the file.  Please make sure empty lines should not exist
	the file MemIDCardPrint.json does not have the new JSON, so update needs to be checked.
	
	This is added at the end, so it is a duplicate
	"    \"requestDateTime\": \"{requestDateTime_val}\","
	"    \"hostName\": \"{hostName_val}\","
	"    \"transactionId\": \"{transId_val}\""

    Use Collection - Dict format (Key value pair)
	For matching key, replace value
	Use Support for JSON data
	
    Find the requestDateTime and replace the value string with {requestDateTime_val}
	Find the hostName and replace the value string with {hostName_val}
	Find the transactionId and replace the value string with {transactionId_val}
	
	Here is the original Notes:
		In the requestHeader section (not requestBody) section, the value for the following key will be replaced with the string inside the curly brackets.
	    	"requestDateTime": "35",
			"hostName": "33hh",
	    	"transactionId": "AIP_Mem_IDCardPrint_0010001"	
		After update on the relevant line, it will be changed to
	        "\"requestDateTime\": \"{requestDateTime_val}\","
            "\"hostName\": \"{hostName_val}\","
            "\"transactionId\": \"{transId_val}\""

			
4) Add One Condition

	Go to AIP_Automation.dat
	Find the value for the Key=AuthEnabled,
	If the value is Yes,
	Then Get AuthURL:  from Step 1 on the top
	Get Auth URL from the file hFile=AIP_Auth_MemAuth.h
	
	How?
	 Read AIP_Auth_MemAuth.h file
	 Use Delimitor startsWith [1] and EndsWith[2]
	 You will get a set of text in lines
	 Loop the lines and look for the line containing the text "AIP_AuthServer" lr_save_string("https://esbhdp-api.bsc.bscal.com","AIP_AuthServer");
	 Get the URL value, which is https://esbhdp-api.bsc.bscal.com
	 If the URL in this does not match with AuthURL
     Print "Auth URL Does not Match and Print .h file :"+ hFile +" the AuthURL is :"+  AuthURL  


5) Add Code for Step 8 and 9


==========================================

6) Changes: Just a Note not for Coding
    1) File Changes (Init, Action, End)
	2) FileName Changes
	3) Some Action Changes  (+, -, Modification)
	4) Report Analysis Changes (the Call and the File)
	5) Library File Changes  (+, -, Modification)
	6) Parameter Changes  (+, -, Modification)
	7) Some Column Name changes (+, -, Modification)
	8) Things that affects
	9) Things that do not affect 