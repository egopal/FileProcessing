
# Import required modules
import os
import re
import glob
import logging
from collections import defaultdict
import pandas as pd


class ConsolidateData:
    
    # init serves as the constructor in Python
    def __init__(self, logger, source_directory, target_directory, year=2020):
        self.logger = logger
        self.src = source_directory
        self.tgt = target_directory
        self.year = str(year)
        
        # A list of columns for the main dataframe
        self.columns = []
        # A list of all csv files in source directory
        self.all_months = []
        self.month_dict = {'01': 'Jan', '02': 'Feb', '03': 'Mar', '04': 'Apr', '05': 'May', '06': 'Jun', 
                           '07': 'Jul', '08': 'Aug', '09': 'Sep', '10': 'Oct', '11': 'Nov', '12': 'Dec'}
        
        self.logger.info(f"Source directory: {os.path.abspath(self.src)}")
        self.logger.info(f"Target directory: {os.path.abspath(self.tgt)}")
        self.logger.info(f"Year is: {self.year}")
        self.logger.info("All constructor variables initialized!")
        
        self.all_months_dict = defaultdict(list)
        
        # Populates self.columns meant for each day of year for the main dataframe, main_df
        self.create_columns()
        self.logger.info(f"Dataframe columns generated! Total columns: {len(self.columns)}")
        
        # Populates self.all_months_dict, a dictionary with key=Month and value=filenames of the files for the given month
        self.list_files_monthwise()
        
        # Read the basefile assuming it to be the first file for the year
        self.read_basefile()
        self.logger.info("BaseFile read and dataframe populated!")
        
        
        
    def date_list(self, month, index):
        """
            Inputs:
                object
                month: a 2 character string, eg, '01' for Jan, '02' for Feb
                index: values allowed are- 
                    'odd' for 31 day months
                    'even' for 30 day months
                    'feb' for February

            Outputs:
                ret_list: A list for each day of a month with each element as a string of the form 
                          '<year>-<month>-<day>' 
        """

        # First column is the Max(Month-Year) column
        ret_list = ['Max(' + self.month_dict[month] + '-' + self.year + ')']
        end = None

        if index == 'feb':
            # check for leap year
            if (((int(self.year) % 4 == 0) and (int(self.year) % 100 != 0)) or (int(self.year) % 400 == 0)):
                end = 29
            else:
                end = 28
        # check for month having 31 days
        elif index == 'odd':
            end = 31
        else:
            end = 30

        for i in range(1, end+1):
            # to account for zeros while writing the day, eg. 01, 21
            zeros = '0'*(2-len(str(i)))
            ret_list.append(f"{self.year}-{month}-{zeros}{i}")

        return ret_list


    def create_columns(self):
        """
            Inputs:
                object

            Outputs:
                Populates self.columns which is a list for each day of a year with each element as a string 
                of the form '<year>-<month>-<day>'. This list serves as columns for the consolidated dataframe
        """

        # The months which contain 31 days
        odd_months = ['01', '03', '05', '07', '08', '10', '12']

        for i in self.month_dict:
            if i in odd_months:
                self.columns += self.date_list(i, 'odd')
            else:
                if i == '02':
                    self.columns += self.date_list(i, 'feb')
                else:
                    self.columns += self.date_list(i, 'even')
                    
                
    def list_files_monthwise(self):
        """
            Inputs:
                object

            Outputs:
                Populates self.all_months_dict which is a dictionary with key=Month 
                and value=filenames of the files for the given month
        """

        self.all_months = sorted([f for f in glob.glob(os.path.join(self.src, '*.csv')) if self.year in f])
        for month_file in self.all_months:
            month = month_file.split('-')[-2]
            self.all_months_dict[self.month_dict[month]].append(month_file)
            
            
            
    # Read basefile
    def read_basefile(self):
        """
            Inputs:
                object

            Outputs:
                Populates self.main_df which is a dataframe with values copied from the basefile.
                Populates self.base_cols which is a list of columns ['mpgw', 'api'].
        """

        # Find the basefile in dir_, assuming only one base file exists
        basefile = self.all_months[0]

        # fetch the date from the basefile
        date = re.search(r'\d{4}-\d{2}-\d{2}', basefile).group()

        base_df = pd.read_csv(basefile)
        # rename count column to date
        base_df = base_df.rename(columns={'count': date})
        # assuming first two columns are the columns common to all files
        base_cols = list(base_df.columns[:-1])
        
        # Create main_df and copy columns from basefile
        main_df = pd.DataFrame(columns=base_cols + self.columns)       
        main_df[base_df.columns] = base_df[base_df.columns]

        self.main_df = main_df
        self.base_cols = base_cols
        
        
    # Consolidate data
    def consolidate(self):
        """
            Inputs:
                object

            Outputs:
                Populates self.main_df which is a dataframe with all the data consolidated 
                with 'Max(<Month>-<Year>)' columns filled
        """

        # if it is the basefile, check whether files for same month exist. If not fill Max column with those values
        first_list = self.all_months_dict[list(self.all_months_dict.keys())[0]]
        
        # remove the first file because it has already been written into self.main_df
        first_list.pop(0)
        
        # Iterate over files of each month
        for month, files in self.all_months_dict.items():
            for file in files:
                curr_df = pd.read_csv(file)

                # find common rows between main_df and curr_df using leftJoin(main_df, curr_df)
                # and update main_df, a new column 'count' is formed
                self.main_df = pd.merge(self.main_df, curr_df, how='left', on=self.base_cols)
                # find the date from the filename
                date = re.search(r'\d{4}-\d{2}-\d{2}', file).group()
                # copy values from 'count' column to the <date> column
                self.main_df[date] = self.main_df['count']
                # drop the 'count' column
                self.main_df = self.main_df.drop(columns=['count'])


                # cols contains columns commmon to main_df and curr_df
                cols = [*self.base_cols, date]
                # rename the 'count' column in curr_df
                curr_df = curr_df.rename(columns={'count': date})
                # find common rows between curr_df and main_df using leftJoin(curr_df, main_df)
                common = curr_df.merge(self.main_df, on=cols)[cols]
                # remove such common rows
                x = pd.concat([curr_df, common])
                x = x.drop_duplicates(keep=False, ignore_index=True).dropna(axis='rows', how='all')
                # remaining rows to be copied into first df
                self.main_df = self.main_df.append(x, sort=False, ignore_index=True)

        # fill all cells having NaN values with 0s
        self.main_df.fillna(0, inplace=True)
        self.logger.info('Consolidated Dataframe formed!')
        

    def find_max_for_all_months(self):
        """
            Inputs:
                object

            Outputs:
                Populates the Max(Month-Year) columns of self.main_df
        """

        # List of columns which are Max(Month-Year) columns
        max_col_indices = [i for i, j in enumerate(list(self.main_df.columns)) if 'Max' in j] + [len(self.main_df.columns)]

        for i in range(len(max_col_indices)-1):
            start, end = max_col_indices[i], max_col_indices[i+1]
            # Calculate max values for each month the Max(Month-Year) columns 
            self.main_df[self.main_df.columns[start]] = \
                self.main_df[:][self.main_df.columns[start+1 : end]].max(axis='columns', numeric_only=True)
            
        self.logger.info('Max(Month-Year) columns populated!')
        
        
            
    def generate_max_df(self):
        """
            Inputs:
                object
            Outputs:
                Generates self.max_df which is a  dataframe for viewing only the max for each month of a year
        """
        
        # Copy over columns 'mpgw', 'api' and Max(Month-Year) columns to another dataframe, max_df
        max_cols = self.base_cols + [i for i in list(self.main_df.columns) if 'Max' in i]
        self.max_df = self.main_df[max_cols]
        
        # Find the max hits for a given year
        self.max_df[f'Max({self.year})'] = self.max_df[:][max_cols[2:]].max(axis='columns', numeric_only=True)
        
        self.logger.info('Max Dataframe generated!')
        
        
    def write_to_xlsx(self, df, output_file):
        # write the dataframe to an output xlsx file
        outfile = os.path.join(self.tgt, output_file)
        df.to_excel(outfile, index=False)
        
        self.logger.info(f'Dataframe written to: {outfile}')
