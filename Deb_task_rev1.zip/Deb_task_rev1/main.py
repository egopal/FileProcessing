
import os
import time
import warnings
import logging
import re

from utils import ConsolidateData

warnings.filterwarnings('ignore')


# Enter source directory path
dir_ = input("Enter absolute path for source directory: ")

# If such a path does not lead to a directory, raise Error
if not os.path.isdir(dir_):
    raise FileNotFoundError("Invalid path!")
    
# Enter the year, if nothing is pressed-> 2020 is taken as default
year = input("Enter the year: ") or '2020'

# Raise error if year is invalid
if len(year) != 4 and re.match('^[0-9]*$', year):
    raise ValueError("Invalid year!")
    
# Enter target directory name
tgt_dir_ = input("Enter target directory: ")
                
# Absolute path of source directory is appended
tgt_dir_ = os.path.join(os.path.dirname(os.path.abspath(dir_)), tgt_dir_)

# Create target directory if not found
if not os.path.isdir(tgt_dir_):
    print("\nTarget directory not found! Creating target directory...")
    os.system(f"mkdir '{tgt_dir_}'")

# Start calculating time
start = time.time()

# Create a custom logger for logging steps
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Create handlers for output stdout stream and file output stream
c_handler = logging.StreamHandler()
f_handler = logging.FileHandler(f'{year}_logs.log')

# Create formatters and add it to handlers
c_format = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
f_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
c_handler.setFormatter(c_format)
f_handler.setFormatter(f_format)

# Add handlers to the logger
logger.addHandler(c_handler)
logger.addHandler(f_handler)

# Create the object
cons_data = ConsolidateData(logger, dir_, tgt_dir_, year)

# Fill the Max(Month-Year) columns
cons_data.consolidate()
cons_data.find_max_for_all_months()

# Make a dataframe with the Max(Month-Year) columns and a Max(Year) column for max in each month
cons_data.generate_max_df()

# Write files to the directory
cons_data.write_to_xlsx(cons_data.main_df, 'consolidated_data.xlsx')
cons_data.write_to_xlsx(cons_data.max_df, 'max_consolidated_data.xlsx')

# Remove all files in the directory
# csv_files = os.path.join(dir_, '*.csv')
# os.system(f'rm -r {csv_files}')

print(f"\nDone....\nTotal time taken: {time.time() - start} sec")
