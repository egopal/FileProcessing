import os 
import shutil
import json
import logging



def edit_file(file_name,prev_text,new_text):
	temp_file = "temp.txt"
	with open(file_name,"r") as f:
		with open(temp_file,"w") as f1:
			for i in f:
				f1.write(i.replace(prev_text,new_text))
	os.remove(file_name)
	os.rename(temp_file,file_name)

def step_2(data_keys):
	global current_directory
	global target_dir 
	global target_script_name
	global src_root_path
	global target_root_path

	target_root_path = os.path.join(current_directory,"Clone")
	target_dir = data_keys["Test Suite Name"]+"_"+data_keys["Test Method Name"]
	target_script_name = data_keys["Test Method Name"]

def step_3(data_keys,sd):

	global target_root_path
	global target_dir
	global target_script_name

	if(data_keys["Auth URL"].strip().endswith("test.htm")):
		srcDir = os.path.join(src_root_path,"testing")
	else:
		srcDir = os.path.join(src_root_path,sd)
	print("sd:",sd)
	print("srcDir:",srcDir)
	# TODO This srcDir needs to be cleaned as given on the top (First 19 lines of this doc explains that)

	try:
		shutil.copytree(srcDir, os.path.join(target_root_path,target_dir))
	except:
		print(os.path.join(target_root_path,target_dir),"already exisists")

def step_4(data_keys,sd):

	global target_root_path
	global target_dir
	global target_script_name

	filesEndingWith = [".usr",".prm"]
	for f in os.listdir(os.path.join(target_root_path,target_dir)):
		for e in filesEndingWith:
			if(f.endswith(e)):
				os.rename(os.path.join(target_root_path,target_dir,f),os.path.join(target_root_path,target_dir,target_dir+"."+f.split(".")[-1]))


	l = [sd+".c",sd+"_W.dat", sd+"_F.dat", sd+"_W.sql", sd+"_F.sql", "z"+sd+".c", "z"+sd+".json"]
	for i in l:
		try:
			os.rename(os.path.join(target_root_path,target_dir,i),os.path.join(target_root_path,target_dir,i.replace(sd,target_script_name))) 
		except:
			print("NO SUCH FILE:",os.path.join(target_root_path,target_dir,i))

	edit_file(os.path.join(target_root_path,target_dir,target_dir+".prm"),sd,target_script_name)
	


	# conditon which was asked to add .... point 4 in TO-DO

	data = []
	with open(os.path.join(target_root_path,target_dir,"AIP_Automation.dat"),"r") as f:
		for i in f:
			data.append(i.strip().split(","))
	
	auth_enabled = None
	for i in range(len(data[0])):
		if(data[0][i]=="AuthEnabled"):
			auth_enabled = data[1][i]
	
	if(auth_enabled!=None and auth_enabled.strip().lower()=="yes"):
		auth_url = data_keys["Auth URL"]
		req_line = None
		
		with open(os.path.join(target_root_path,target_dir,"AIP_Auth_MemAuth.h"),"r") as f:
			start = False
			for line in f:
				if("[1]" in line):
					start = True
					pass
				if("[2]" in line):
					start = False
				if(line.strip().startswith("//")==False and start==True):
					if('"AIP_AuthServer"' in line):
						req_line = line
		
		if(req_line!=None):
			url = req_line.split('"')[1]
		
		print("----------------------------------------------")
		if(url!=auth_url):
			print("AUTH URL DOES NOT MATCH WITH THE URL IN {} FILE. THE AUTH URL IS :{}".format(os.path.join(target_root_path,target_dir,"AIP_Auth_MemAuth.h"),auth_url))
		else:
			print("AUTH URL MATCHES URL IN FILE")

def step_5(data_keys,sd):
	
	global target_root_path
	global target_dir
	global target_script_name

	edit_file(os.path.join(target_root_path,target_dir,"default.usp"),sd,target_script_name)
	for f in os.listdir(os.path.join(target_root_path,target_dir)):  
		if(f.endswith(".usr")):
			# ParameterFile=AIP_Mem_Profile.prm
			edit_file(os.path.join(target_root_path,target_dir,f),"ParameterFile={}.prm".format(sd),"ParameterFile={}.prm".format(target_dir))
			edit_file(os.path.join(target_root_path,target_dir,f),sd,target_script_name)
	edit_file(os.path.join(target_root_path,target_dir,"z"+target_script_name+".c"),sd,target_script_name)
	

def step_6a(data_keys):

	global target_root_path
	global target_dir
	global target_script_name

	with open(os.path.join(target_root_path,target_dir,"AIP_Automation.dat"),"r") as f:
		data = []
		for line in f:
			data.append(line.split(","))
	for i in range(len(data[0])):
		if(data[0][i].strip().lower()=="ScriptName".strip().lower()):
			data[1][i] = target_script_name
		if(data[0][i].strip().lower()=="AuthEnabled".strip().lower()):
			if(len(data_keys["Auth URL"].strip())==0):
				data[1][i] = "No"
		if(data[0][i].strip().lower()=="ServiceComponentName".strip().lower()):
			data[1][i] = data_keys["Test Suite Name"]
	with open(os.path.join(target_root_path,target_dir,"AIP_Automation.dat"),"w") as f:
		f.write(",".join(data[0]))
		f.write(",".join(data[1]))

def step_6c(data_keys):

	global target_root_path
	global target_dir
	global target_script_name
	
	data = []
	with open(os.path.join(target_root_path,target_dir,"AIP_Env.dat"),"r") as f:    
		for line in f:
			data.append(line.split(","))
	
	for i in range(len(data[0])):
		if(data[0][i].strip().lower()=="Env".strip().lower()):
			if("bscedh1000" in data_keys["ServicesEndPointURL"]):
				data[1][i] = "APIConnect"
			elif("esbhdp-api.bsc.bscal.com" in data_keys["ServicesEndPointURL"]):
				data[1][i] = "Stage_DP"
		
		if(data[0][i].strip().lower()=="Server".strip().lower()):
			try:
				http_loc = data_keys["ServicesEndPointURL"].index("http")
				com_loc = data_keys["ServicesEndPointURL"].index("com")
				start = http_loc
				end = com_loc+len("com")
				if(data_keys["ServicesEndPointURL"][end]==":"):
					# port is present
					end+=1
					while(end<len(data_keys["ServicesEndPointURL"]) and data_keys["ServicesEndPointURL"][end].isnumeric()):
						end+=1
				data[1][i] = data_keys["ServicesEndPointURL"][start:end]
			except:
				print("NO HTTP,COM in the ServicesEndPointURL")
		
		if(data[0][i].strip().lower()=="ServerPath".strip().lower()):
			try:
				com_loc = data_keys["ServicesEndPointURL"].index("com")
				start = com_loc+len("com")
				if(data_keys["ServicesEndPointURL"][start]==":"):
					# port is present
					start+=1
					while(start<len(data_keys["ServicesEndPointURL"]) and data_keys["ServicesEndPointURL"][start].isnumeric()):
						start+=1
			except:
				start = 0
			end = data_keys["ServicesEndPointURL"].index("/bsc")
			data[1][i] = data_keys["ServicesEndPointURL"][start:end]
		
		if(data[0][i].strip().lower()=="ClientID".strip().lower()):
			data[1][i] = data_keys["ClientID"]
		
		if(data[0][i].strip().lower()=="ClientSecret".strip().lower()):
			data[1][i] = data_keys["ClientSecret"]
	
	with open(os.path.join(target_root_path,target_dir,"AIP_Env.dat"),"w") as f:
		f.write(",".join(data[0]))
		f.write(",".join(data[1]))

def step_6b(data_keys):

	global target_root_path
	global target_dir
	global target_script_name
	
	data = []
	with open(os.path.join(target_root_path,target_dir,"AIP_Service.dat"),"r") as f:    
		for line in f:
			data.append(line.split(","))
	
	for i in range(len(data[0])):
		if(data[0][i].strip().lower()=="Container".strip().lower()):
			data[1][i] = data_keys["Container"]
		if(data[0][i].strip().lower()=="ServiceName".strip().lower()):
			data[1][i] = target_script_name 
		if(data[0][i].strip().lower()=="ServiceURL".strip().lower()):
			if("ServiceURL" in data_keys and data_keys["ServiceURL"]!=None):
				data[1][i] = data_keys["ServiceURL"]
			else:
				data[1][i] = data_keys["ServicesEndPointURL"] 
		if(data[0][i].strip().lower()=="JSONFileName".strip().lower()):
			data[1][i] = target_script_name +".json"
		if(data[0][i].strip().lower()=="TestMethodName".strip().lower()):
			data[1][i] = target_script_name

	with open(os.path.join(target_root_path,target_dir,"AIP_Service.dat"),"w") as f:
		f.write(",".join(data[0]))
		f.write(",".join(data[1]))

	
def step_7(data_keys):

	global target_root_path
	global target_dir
	global target_script_name
	
	with open(os.path.join(target_root_path,target_dir,target_script_name+".json"),"w") as f:
		json.dump(data_keys["Request JSON"], f,indent=4)
	
	data_keys["Request JSON"]["requestHeader"]["consumer"]["requestDateTime"] = "{requestDateTime_val}"
	data_keys["Request JSON"]["requestHeader"]["consumer"]["hostName"] = "{hostName_val}"
	data_keys["Request JSON"]["transactionId"] = "{transId_val}"

	new_request_list = json.dumps(data_keys["Request JSON"],indent = 4).split("\n")

	for i in range(len(new_request_list)):
		new_request_list[i] = new_request_list[i].replace("\"",'\\"')
		new_request_list[i] = '\"'+new_request_list[i].rstrip()+'\"'

	new_request_string = "\n".join(new_request_list)+";\n"

	with open(os.path.join(target_root_path,target_dir,"z"+target_script_name+".c")) as f:
		with open("temp_file.txt","w") as f1:
			stop = False
			for line in f:
				if(stop==False):
					f1.write(line)
				if("request_json_base=" in line):
					stop = True
				if(stop==True and ";" in line):
					f1.write(new_request_string)
					stop = False
	os.remove(os.path.join(target_root_path,target_dir,"z"+target_script_name+".c"))
	os.rename("temp_file.txt",os.path.join(target_root_path,target_dir,"z"+target_script_name+".c"))

def step_8(data_keys):

	global target_root_path
	global target_dir
	global target_script_name

	for file in os.listdir(os.path.join(target_root_path,target_dir)):
		if(file.endswith("Automation.dat")):
			data = []
			with open(os.path.join(target_root_path,target_dir,file),"r") as f:
				for line in f:
					data.append(line.strip().split(","))

				for i in range(len(data[0])):
					if(data[0][i]=="NFRVolume"):
						break
				else:
					data[0].append("NFRVolume")
					data[1].append("5000")
			
			with open(os.path.join(target_root_path,target_dir,file),"w") as f:
				f.write(",".join(data[0])+"\n")
				f.write(",".join(data[1]))
	
	all_files = os.listdir(os.path.join(target_root_path,target_dir))
	for file_name in all_files:
		if(file_name.endswith("_W.dat")):
			if(file_name[:-6]+"_W.sql" not in all_files):
				print("No SQL Files found for {} the dat file that is found, ending with _W.dat or _F.dat".format(file_name)) 
		if(file_name.endswith("_F.dat")):
			if(file_name[:-6]+"_F.sql" not in all_files):
				print("No SQL Files found for {} the dat file that is found, ending with _W.dat or _F.dat".format(file_name))                        

# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
def join_alias_keys(data_keys,original_key, alternative_key):
	logger = logging.getLogger()
	
	if(data_keys[alternative_key]!=None and data_keys[original_key]==None):
		data_keys[original_key] = data_keys[alternative_key]		
		logger.debug("value for \"{}\" and \"{}\" keys brought to the value of \"{}\"".format(original_key,alternative_key,original_key))	

	else:
		logger.debug("value for \"{}\" and \"{}\" keys cannot be brought together".format(original_key,alternative_key))

def extract_header_info(data_keys):
	logger = logging.getLogger()

	if(data_keys["Other Header Info"]!=None):
		l = data_keys["Other Header Info"].split(",")
		
		data_keys["ClientID"] = "".join(l[:1]).strip() 
		data_keys["ClientSecret"] = ",".join(l[1:]).strip()
		
		if(data_keys["ClientSecret"].split(":")[0].lower() == "ClientSecret".lower()):
			data_keys["ClientSecret"] = ":".join(data_keys["ClientSecret"].split(":")[1:])
		
		logger.debug("Extarcted \"ClientSecret\" and \"ClientSecret\" from \"Other Header Info\"")
		logger.debug("\"Other Header Info\": {}".format(data_keys["Other Header Info"]))
		logger.debug("\"Extracted Client ID\": {}".format(data_keys["ClientID"]))
		logger.debug("\"Extracted Client Secret\": {}".format(data_keys["ClientSecret"]))
	
	else:
		logger.debug("\"Other Header Info\" is set to None, so client id and secret cannot be extracted")

def extract_services_end_point_url(data_keys):
	logger = logging.getLogger()
	
	if(data_keys["ServicesEndPointURL"]!=None and ":" in data_keys["ServicesEndPointURL"]):
		l = data_keys["ServicesEndPointURL"].split(":")
		logger.debug("Info extrcated from \"ServicesEndPointURL\": {} are as below:".format(data_keys["ServicesEndPointURL"]))
		
		data_keys["ServiceType"] = l[0].strip()
		logger.debug("\"ServiceType\": {}".format(data_keys["ServiceType"]))
		
		data_keys["ServiceName"] = ":".join(l[1:-1])
		port = False
		
		if(l[-1].split("/")[0].strip().isnumeric()):
			port = True
			data_keys["ServiceName"] += ":"+l[-1].split("/")[0].strip()
		logger.debug("\"ServiceName\": {}".format(data_keys["ServiceName"]))
		
		try:
			if(port):
				new_l = l[-1].split("/")[1:]
			else:
				new_l = l[-1].split("/")
			
			bsc_index = new_l.index("bsc")
			
			data_keys["ServicePath"] = "/"+"/".join(new_l[:bsc_index]).strip()
			logger.debug("\"ServicePath\": {}".format(data_keys["ServicePath"]))
			
			data_keys["ServiceURL"] = "/"+"/".join(new_l[bsc_index:]).strip()
			logger.debug("\"ServiceURL\": {}".format(data_keys["ServiceURL"]))
		
		except:
			logger.debug("Cannot extract ServicePath and ServiceURL from \"ServicesEndPointURL\" because \"bsc\" was not found in {}".format(data_keys(data_keys["ServicesEndPointURL"])))
	else:
		logger.debug("Cannot extract info from ServicesEndPointURL")

def jsonify(data_keys,key):
	logger = logging.getLogger()

	if(data_keys[key]!=None):
		data_keys[key] = json.loads(data_keys[key])
		
		logger.debug("\"{}\" has been converted to json and can be found below".format(key))
		logger.debug(json.dumps(data_keys[key],indent = 4))
	else:
		logger.debug("Cannot convert to json for \"{}\", as the value is None".format(key))
	
def data_formatting(data_keys):

	join_alias_keys(data_keys,"Test Method Name","Test Operation Name")
	join_alias_keys(data_keys,"Container","JVM")
	join_alias_keys(data_keys,"ServicesEndPointURL","ServicesEndPoint URL")
	extract_header_info(data_keys)
	extract_services_end_point_url(data_keys)
	jsonify(data_keys,"Request JSON")
	jsonify(data_keys,"Response JSON")


def get_processed_dict_data(file_dir,file_name, data_keys):

	file_path = os.path.join(current_directory,catalog_file_to_read)
	
	logger = logging.getLogger()
	logger.debug("Processing the catalog file: {}".format(file_path))

	with open(file_path,"r") as f:	
		prev_key_used = None

		for line in f:
			for key in data_keys:
				if(key.lower() in line.lower()):

					if(data_keys[key]!=None):		
						yield data_keys
						refresh_dict(data_keys)
					
					value = ":".join(line.split(":")[1:]).strip()
					data_keys[key] =  value
					prev_key_used = key
					break
			else:
				data_keys[prev_key_used] += line

		yield data_keys
		refresh_dict(data_keys)
	
	logger.debug("Completed Processing the catalog file: {}".format(file_path))


# -----------------------------------------------------------------------------
def refresh_dict(data_keys):
	logger=logging.getLogger()
	logger.debug("reseting the values in the dictionary in order to extract new set of values")
	for key in data_keys:
		data_keys[key] = None

def setup_logger(file_name):
	logging.basicConfig(filename=os.path.join(current_directory,file_name), 
			format='%(name)s - %(levelname)s - %(message)s', 
			filemode='w')
	logger=logging.getLogger()
	logger.setLevel(logging.DEBUG) 

def backup(source_dir):
	# since after compressing the file would be placed in the same folder only so the path of that folder is only taken
	
	logger = logging.getLogger()
	
	logger.debug("backing up process of {} has started".format(source_dir))
	
	if(os.path.exists(source_dir) and os.path.isdir(source_dir)):
		shutil.make_archive(source_dir,"zip",source_dir)
		shutil.make_archive(base_dir=source_dir, root_dir=source_dir, format='zip', base_name=source_dir)
		logger.debug("backing up files in {} and would be placed in {}".format(source_dir, os.path.split(source_dir)[0]))
	
	else:
		logger.error("some error occered during backing up brocess")
		
def delete_single_folder(folderPath):
	logger = logging.getLogger()
	if(os.path.isdir(folderPath)):
		try:
			shutil.rmtree(folderPath)
			logger.debug("Deleted folder {}".format(folderPath))
		except Exception as e:
			logger.error("Some error in while deleting {}".format(folderPath), exc_info=True)
	else:
		logger.debug("No able to delete {} because it is not a folder".format(folderPath))

def delete_folders(directory_path, folders = set()):
	
	logger = logging.getLogger()
	logger.debug("Deleting folders {}".format(folders))

	for folder_name in os.listdir(directory_path):
		if(folder_name in folders):
			actualFolder = os.path.join(directory_path, folder_name)
			delete_single_folder(actualFolder)
	
	logger.debug("Process complete")

def delete_single_file(dir_name, file):
	
	logger = logging.getLogger()
	
	actualFile = os.path.join(dir_name, file)
	try:
		os.remove(actualFile)
		logger.debug("Deleted file {}".format(actualFile))
	except Exception as e:
		logger.error("Some error in while deleting {}".format(actualFile), exc_info=True)

def delete_files(dir_name, files_to_delete = set(), 
		starts_with=False, ends_with = False, exact_match = False):
	
	logger = logging.getLogger()
	
	if(starts_with==True):
		logger.debug("Deleting files starting with {}".format(files_to_delete))
		
		for file in os.listdir(dir_name):
			for fileType in files_to_delete:
				if file.startswith(fileType):
					delete_single_file(dir_name,file)
		
		logger.debug("Process complete")

	elif(ends_with==True):
		logger.debug("Deleting files ending with {}".format(files_to_delete))
		
		for file in os.listdir(dir_name):
			for fileType in files_to_delete:
				if file.endswith(fileType):
					delete_single_file(dir_name,file)
					
		logger.debug("Process complete")

	elif(exact_match==True):
		logger.debug("Deleting files matching exactly with {}".format(files_to_delete))

		for file in os.listdir(dir_name):
			for fileType in files_to_delete:
				if(file == fileType):
					delete_single_file(dir_name,file)

		logger.debug("Process complete")
	
	else:
		logger.debug("No argument among starts_with, ends_with, exact_match was provided with the fuction call")

def cleanup_script_files(directory_path):
	delete_folders(directory_path, {"result1", "result2"})    
	delete_files(directory_path, {"combined_", "testing"}, starts_with=True)
	delete_files(directory_path, {".idx",".bak",".txt",".tmp",".log",".c.pickle"},ends_with=True)
	delete_files(directory_path, {"Pre_cci.c", "test.txt"},exact_match=True)
	

# ------------------------------------------------------------------------------------------------
# MAIN CODE


if(__name__=="__main__"):
	
	current_directory = os.getcwd()
	catalog_file_to_read = "TestCatalog.txt" 
	src_root_path = os.path.join(current_directory,"Template")
	target_dir = None
	target_script_name = None
	target_root_path = None
	log_file = "app.log"


	data_keys = {
		"Test Suite Name": None,
		"Test Method Name":None,
		"Test Operation Name": None,
		"Container": None,
		"JVM": None,
		"Auth URL": None,
		"Auth Token": None,
		"Other Header Info": None,
		"ServicesEndPointURL":None,
		"ServicesEndPoint URL": None,
		"Request JSON": None,
		"SQL Query for Data": None,
		"Response JSON": None,
		"SQL Query to validate the data":None,
		"Test Execution Status": None
	}

	setup_logger(log_file)

	backup(os.path.join(src_root_path,"AIP_Mem_Profile"))

	cleanup_script_files(os.path.join(src_root_path,"AIP_Mem_Profile"))

	logger = logging.getLogger()

	for key_value_pair in get_processed_dict_data(current_directory, catalog_file_to_read, data_keys):
		logger.debug("The parsed data is as below:")
		logger.debug(json.dumps(key_value_pair,indent = 4))
		
		data_formatting(data_keys)
		
		logger.debug("Data after data formatting:")
		logger.debug(json.dumps(key_value_pair,indent = 4))
		
		print("step_2_s")
		step_2(data_keys)    
		print("step_2_e")
		

		print("target_dir:",target_dir)
		print("target_script_name:",target_script_name)
		print("target_root_path: ",target_root_path)
		sd = "AIP_Mem_Profile"

		print("step_3_s")
		step_3(data_keys,sd)
		print("step_3_e")
		print("step_4_s")		
		step_4(data_keys,sd)
		print("step_4_e")
		print("step_5_s")		
		step_5(data_keys,sd)
		print("step_5_e")
		print("step_6a_s")		
		step_6a(data_keys)
		print("step_6a_e")
		print("step_6c_s")		
		step_6c(data_keys)    
		print("step_6c_e")
		print("step_6b_s")		
		step_6b(data_keys)
		print("step_6b_e")
		print("step_7_s")		
		step_7(data_keys)
		print("step_7_e")
		print("step_8_s")		
		step_8(data_keys)
		print("step_8_e")
		
	

