import os
import pathlib
import collections
import glob
import shutil
from os import rename

sourceDir          = "Template"
targetDir          = "Clone"
templateDir        = "AIP_Mem_Profile"
newCloneDir        = "CloneTesting"
logFileToList      = "CloneRun.txt"

srcScriptsDir      = os.path.join(sourceDir,templateDir)
targetScriptsDir   = os.path.join(targetDir,newCloneDir)

saveLogFileToList = open(os.path.join(sourceDir,logFileToList), "w")

fileExtnWithClone    = ('.usr','.test')

#-------------------------------------------------------------------------------
# Source Dir - Delete Unwanted Files  
#-------------------------------------------------------------------------------

# Delete result1 folder
resultsDir = os.path.join(srcScriptsDir,"result1")

#status = os.path.exists(resultsDir)
if (os.path.exists(resultsDir) == True):
    print(resultsDir)
    shutil.rmtree(resultsDir)

# Delete Files Starting With and Ending with
filesStartingWith = ('combined_','test')
filesEndingWith = ('.idx','.bak','.txt','.tmp','.sdf','.log','.pickle','.ci', '.xml')

for file in os.listdir(srcScriptsDir):
    actualFile = os.path.join(srcScriptsDir, file)
    for fileType in filesStartingWith:
        if file.startswith(fileType):
            if os.path.exists(actualFile):
                print(actualFile)
                os.remove(actualFile)
    for fileType in filesEndingWith:
        if actualFile.endswith(fileType):
            if os.path.exists(actualFile):
                print(actualFile)
                os.remove(actualFile)

#-------------------------------------------------------------------------------
# Delete the Target Dir if Exist
#-------------------------------------------------------------------------------
# Sagar - > Do we need a try and catch? If yes, why?

# Delete target folder
if (os.path.exists(targetScriptsDir) == True):
     shutil.rmtree(targetScriptsDir)
     print("Deleted : " +targetScriptsDir) 

#-------------------------------------------------------------------------------
# Copy src Dir with Files to target Dir using shutil.copytree() method  
#-------------------------------------------------------------------------------

# shutil.copytree(srcScriptsDir, targetScriptsDir) 
# print(os.listdir(targetScriptsDir))
# print("Dir and File Copy completed: targetScriptsDir")  

# Sagar -> Try and see if you can call the method defined below instead of the above
# 
def copyDir(src, dest):
    try:
        shutil.copytree(src, dest) 
    # Directories are the same
    except shutil.Error as e:
        print('Directory not copied. Error: %s' % e)
    # Any error saying that the directory doesn't exist
    except OSError as e:
        print('Directory not copied. Error: %s' % e)

copyDir(srcScriptsDir,targetScriptsDir)

# Change File names matching the string
    

#-------------------------------------------------------------------------------
# Clone Source Scripts to Destination Folder with a name
# -- Read from txt File
# -- Read from csv file
# -- Read from curl file
# Dir/File name changes
# Changes in text in all files
#-------------------------------------------------------------------------------

# Python program to copy Dir using shutil.copytree() method  
   
# List files and directories  
   
# Copy the content of  
# source to destination  
#>>>> destination = shutil.copytree(srcScriptsDir, targetScriptsDir)  
#>>>> print("After copying file:")  
#print(os.listdir(destination))

#>>>> def copyDir(src, dest):
#>>>>     try:
#>>>>         shutil.copytree(src, dest) 
#>>>>     # Directories are the same
#>>>>     except shutil.Error as e:
#>>>>         print('Directory not copied. Error: %s' % e)
#>>>>     # Any error saying that the directory doesn't exist
#>>>>     except OSError as e:
#>>>>         print('Directory not copied. Error: %s' % e)

# Change File names matching the string

for file in os.listdir(srcScriptsDir):
    actualFile = os.path.join(srcScriptsDir, file)
    print(actualFile)
    for fileType in filesStartingWith:
        print(fileType)
        if file.startswith(fileType):
            print(actualFile)
            if os.path.exists(actualFile):
                print(actualFile)
                os.remove(actualFile)
    for fileType in filesEndingWith:
        if actualFile.endswith(fileType):
            if os.path.exists(actualFile):
                print(actualFile)
                os.remove(actualFile)

