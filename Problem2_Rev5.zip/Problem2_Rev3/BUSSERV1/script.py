import os 
import shutil
import json
import logging
from collections import deque
import mysql.connector
	


def edit_file(file_name,prev_text,new_text):
	temp_file = "temp.txt"
	with open(file_name,"r") as f:
		with open(temp_file,"w") as f1:
			for i in f:
				f1.write(i.replace(prev_text,new_text))
	os.remove(file_name)
	os.rename(temp_file,file_name)

def step_2(data_keys):
	global current_directory
	global target_dir 
	global target_script_name
	global src_root_path
	global target_root_path

	target_root_path = os.path.join(current_directory,"Clone")
	target_dir = data_keys["Test Suite Name"]+"_"+data_keys["Test Method Name"]
	target_script_name = data_keys["Test Method Name"]

def step_3(data_keys,sd):

	global target_root_path
	global target_dir
	global target_script_name

	if(data_keys["Auth URL"].strip().endswith("test.htm")):
		srcDir = os.path.join(src_root_path,"testing")
	else:
		srcDir = os.path.join(src_root_path,sd)
	print("sd:",sd)
	print("srcDir:",srcDir)
	# TODO This srcDir needs to be cleaned as given on the top (First 19 lines of this doc explains that)

	try:
		shutil.copytree(srcDir, os.path.join(target_root_path,target_dir))
	except:
		print(os.path.join(target_root_path,target_dir),"already exisists")

def step_4(data_keys,sd):

	global target_root_path
	global target_dir
	global target_script_name

	filesEndingWith = [".usr",".prm"]
	for f in os.listdir(os.path.join(target_root_path,target_dir)):
		for e in filesEndingWith:
			if(f.endswith(e)):
				os.rename(os.path.join(target_root_path,target_dir,f),os.path.join(target_root_path,target_dir,target_dir+"."+f.split(".")[-1]))


	l = [sd+".c",sd+"_W.dat", sd+"_F.dat", sd+"_W.sql", sd+"_F.sql", "z"+sd+".c", "z"+sd+".json"]
	for i in l:
		try:
			os.rename(os.path.join(target_root_path,target_dir,i),os.path.join(target_root_path,target_dir,i.replace(sd,target_script_name))) 
		except:
			print("NO SUCH FILE:",os.path.join(target_root_path,target_dir,i))

	edit_file(os.path.join(target_root_path,target_dir,target_dir+".prm"),sd,target_script_name)
	


	# conditon which was asked to add .... point 4 in TO-DO

	data = []
	with open(os.path.join(target_root_path,target_dir,"AIP_Automation.dat"),"r") as f:
		for i in f:
			data.append(i.strip().split(","))
	
	auth_enabled = None
	for i in range(len(data[0])):
		if(data[0][i]=="AuthEnabled"):
			auth_enabled = data[1][i]
	
	if(auth_enabled!=None and auth_enabled.strip().lower()=="yes"):
		auth_url = data_keys["Auth URL"]
		req_line = None
		
		with open(os.path.join(target_root_path,target_dir,"AIP_Auth_MemAuth.h"),"r") as f:
			start = False
			for line in f:
				if("[1]" in line):
					start = True
					pass
				if("[2]" in line):
					start = False
				if(line.strip().startswith("//")==False and start==True):
					if('"AIP_AuthServer"' in line):
						req_line = line
		
		if(req_line!=None):
			url = req_line.split('"')[1]
		
		print("----------------------------------------------")
		if(url!=auth_url):
			print("AUTH URL DOES NOT MATCH WITH THE URL IN {} FILE. THE AUTH URL IS :{}".format(os.path.join(target_root_path,target_dir,"AIP_Auth_MemAuth.h"),auth_url))
		else:
			print("AUTH URL MATCHES URL IN FILE")

def step_5(data_keys,sd):
	
	global target_root_path
	global target_dir
	global target_script_name

	edit_file(os.path.join(target_root_path,target_dir,"default.usp"),sd,target_script_name)
	for f in os.listdir(os.path.join(target_root_path,target_dir)):  
		if(f.endswith(".usr")):
			# ParameterFile=AIP_Mem_Profile.prm
			edit_file(os.path.join(target_root_path,target_dir,f),"ParameterFile={}.prm".format(sd),"ParameterFile={}.prm".format(target_dir))
			edit_file(os.path.join(target_root_path,target_dir,f),sd,target_script_name)
	edit_file(os.path.join(target_root_path,target_dir,"z"+target_script_name+".c"),sd,target_script_name)
	

def step_6a(data_keys):

	global target_root_path
	global target_dir
	global target_script_name

	with open(os.path.join(target_root_path,target_dir,"AIP_Automation.dat"),"r") as f:
		data = []
		for line in f:
			data.append(line.split(","))
	for i in range(len(data[0])):
		if(data[0][i].strip().lower()=="ScriptName".strip().lower()):
			data[1][i] = target_script_name
		if(data[0][i].strip().lower()=="AuthEnabled".strip().lower()):
			if(len(data_keys["Auth URL"].strip())==0):
				data[1][i] = "No"
		if(data[0][i].strip().lower()=="ServiceComponentName".strip().lower()):
			data[1][i] = data_keys["Test Suite Name"]
	with open(os.path.join(target_root_path,target_dir,"AIP_Automation.dat"),"w") as f:
		f.write(",".join(data[0]))
		f.write(",".join(data[1]))

def step_6c(data_keys):

	global target_root_path
	global target_dir
	global target_script_name
	
	data = []
	with open(os.path.join(target_root_path,target_dir,"AIP_Env.dat"),"r") as f:    
		for line in f:
			data.append(line.split(","))
	
	for i in range(len(data[0])):
		if(data[0][i].strip().lower()=="Env".strip().lower()):
			if("bscedh1000" in data_keys["ServicesEndPointURL"]):
				data[1][i] = "APIConnect"
			elif("esbhdp-api.bsc.bscal.com" in data_keys["ServicesEndPointURL"]):
				data[1][i] = "Stage_DP"
		
		if(data[0][i].strip().lower()=="Server".strip().lower()):
			try:
				http_loc = data_keys["ServicesEndPointURL"].index("http")
				com_loc = data_keys["ServicesEndPointURL"].index("com")
				start = http_loc
				end = com_loc+len("com")
				if(data_keys["ServicesEndPointURL"][end]==":"):
					# port is present
					end+=1
					while(end<len(data_keys["ServicesEndPointURL"]) and data_keys["ServicesEndPointURL"][end].isnumeric()):
						end+=1
				data[1][i] = data_keys["ServicesEndPointURL"][start:end]
			except:
				print("NO HTTP,COM in the ServicesEndPointURL")
		
		if(data[0][i].strip().lower()=="ServerPath".strip().lower()):
			try:
				com_loc = data_keys["ServicesEndPointURL"].index("com")
				start = com_loc+len("com")
				if(data_keys["ServicesEndPointURL"][start]==":"):
					# port is present
					start+=1
					while(start<len(data_keys["ServicesEndPointURL"]) and data_keys["ServicesEndPointURL"][start].isnumeric()):
						start+=1
			except:
				start = 0
			end = data_keys["ServicesEndPointURL"].index("/bsc")
			data[1][i] = data_keys["ServicesEndPointURL"][start:end]
		
		if(data[0][i].strip().lower()=="ClientID".strip().lower()):
			data[1][i] = data_keys["ClientID"]
		
		if(data[0][i].strip().lower()=="ClientSecret".strip().lower()):
			data[1][i] = data_keys["ClientSecret"]
	
	with open(os.path.join(target_root_path,target_dir,"AIP_Env.dat"),"w") as f:
		f.write(",".join(data[0]))
		f.write(",".join(data[1]))

def step_6b(data_keys):

	global target_root_path
	global target_dir
	global target_script_name
	
	data = []
	with open(os.path.join(target_root_path,target_dir,"AIP_Service.dat"),"r") as f:    
		for line in f:
			data.append(line.split(","))
	
	for i in range(len(data[0])):
		if(data[0][i].strip().lower()=="Container".strip().lower()):
			data[1][i] = data_keys["Container"]
		if(data[0][i].strip().lower()=="ServiceName".strip().lower()):
			data[1][i] = target_script_name 
		if(data[0][i].strip().lower()=="ServiceURL".strip().lower()):
			if("ServiceURL" in data_keys and data_keys["ServiceURL"]!=None):
				data[1][i] = data_keys["ServiceURL"]
			else:
				data[1][i] = data_keys["ServicesEndPointURL"] 
		if(data[0][i].strip().lower()=="JSONFileName".strip().lower()):
			data[1][i] = target_script_name +".json"
		if(data[0][i].strip().lower()=="TestMethodName".strip().lower()):
			data[1][i] = target_script_name

	with open(os.path.join(target_root_path,target_dir,"AIP_Service.dat"),"w") as f:
		f.write(",".join(data[0]))
		f.write(",".join(data[1]))

	
def step_7(data_keys):

	global target_root_path
	global target_dir
	global target_script_name
	
	with open(os.path.join(target_root_path,target_dir,target_script_name+".json"),"w") as f:
		json.dump(data_keys["Request JSON"], f,indent=4)
	
	data_keys["Request JSON"]["requestHeader"]["consumer"]["requestDateTime"] = "{requestDateTime_val}"
	data_keys["Request JSON"]["requestHeader"]["consumer"]["hostName"] = "{hostName_val}"
	data_keys["Request JSON"]["transactionId"] = "{transId_val}"

	new_request_list = json.dumps(data_keys["Request JSON"],indent = 4).split("\n")

	for i in range(len(new_request_list)):
		new_request_list[i] = new_request_list[i].replace("\"",'\\"')
		new_request_list[i] = '\"'+new_request_list[i].rstrip()+'\"'

	new_request_string = "\n".join(new_request_list)+";\n"

	with open(os.path.join(target_root_path,target_dir,"z"+target_script_name+".c")) as f:
		with open("temp_file.txt","w") as f1:
			stop = False
			for line in f:
				if(stop==False):
					f1.write(line)
				if("request_json_base=" in line):
					stop = True
				if(stop==True and ";" in line):
					f1.write(new_request_string)
					stop = False
	os.remove(os.path.join(target_root_path,target_dir,"z"+target_script_name+".c"))
	os.rename("temp_file.txt",os.path.join(target_root_path,target_dir,"z"+target_script_name+".c"))

def set_value_to_dat_file(dat_file_path,key_name,value):

	logger = logging.getLogger()

	logger.debug("starting to write for the key = {} a value of {} in the file {}".format(key_name,value,dat_file_path))

	try:
		with open(dat_file_path,"r") as f:	
			logger.debug("started reading the file {}".format(key_name))

			data = []
			
			for line in f:
				data.append(line.strip().split(","))

			for i in range(len(data[0])):
				if(data[0][i].lower().strip()=="NFR_Volume".lower().strip()):
					data[1][i]= "5000"	
					logger.debug("key found with the name {} and set to the default value of {}".format(key_name,value))
					break
			else:
				data[0].append("NFR_Volume")
				data[1].append("5000")
				logger.debug("no key with the name \"{}\" was found ... so setting it up to the default value of \"{}\"".fomat(key_name,value))
			
			logger.debug("completed reading the file {}".fomat(dat_file_path))
		
		try:
			with open(dat_file_path,"w") as f:
				logger.debug("started writing on the file {}".fomat(dat_file_path))
				f.write(",".join(data[0])+"\n")
				f.write(",".join(data[1])+"\n")
				logger.debug("completed writing the file {}".format(dat_file_path))
		except:
			logger.debug("unable to write on the file {}".format(dat_file_path))

	except:
		logger.debug("unable to read the file {}".format(dat_file_path))

	logger.debug("completd writing the key value pain in the file {}".format(dat_file_path))

def get_value_from_dat_file(dat_file_path,key_name):
	logger = logging.getLogger()
	
	logger.debug("getting the current value set for key = \"{}\"".format(key_name))
	
	try:
		with open(dat_file_path) as file:
			data = []
			
			for line in file:
				data.append(line.strip().split(","))
			
			for i in range(len(data[0])):
				if(key_name.lower().strip()==data[0][i].lower()):
					value = data[1][i]
					logger.debug("found the required key = \"{}\", returning the value = \"{}\"".format(key_name,value))
					return value
			else:
				logger.debug("no key with the name \"{}\" was found ... returning None".fomat(key_name))
				return None
	except:
		logger.debug("not able to read the file {}".format(dat_file_path))
	
	logger.debug("completed the process of getting the value of the key = \"{}\" from the file {}".format(key_name,dat_file_path))

def set_default_value(file_to_process, key_name, default_value):
	logger = logging.getLogger()

	logger.debug("started processing the file {} to set the default value of the key = \"{}\" to a value of = \"{}\"".format(file_to_process,key_name,default_value))

	value = get_value_from_dat_file(file_to_process, key_name)
	
	if(value == None or len(value.strip())==0):
		set_value_to_dat_file(file_to_process, key_name, default_value)
	else:
		logger.debug("We already have a value for key = \"{}\", value = \"{}\"".format(key_name,value))

	logger.debug("process completed of setting up the default value ")

def clear_open_file(file_path):
	logger = logging.getLogger()

	logger.debug("crating an empty file {}".format(file_path))
	with open(file_path,"w") as f:
		pass
	logger.debug("sucessfully made an empty file {}".format(file_path))
	

def read_sql(req_sql_source):
	logger = logging.getLogger()

	logger.debug("starting reading sql from the source provided")

	sql_data = None

	if(isinstance(req_sql_source,str)):
		logger.debug("the source of ql was provided to be string ... a file path")
		if(os.path.exists(req_sql_source)):
			logger.debug("the file path exists {}".format(req_sql_source))
			with open(req_sql_source) as f:
				sql_data = f.read()
		else:
			logger.debug("no such file path {} exists".format(req_sql_source))
			sql_data = None

	elif(isinstance(req_sql_source,dict)):
		logger.debug("the source of sql is dictionary")
		if("SQL Query for Data" in req_sql_source):
			logger.debug("\"SQL Query for Data\" key was found which contains the sql staments")
			sql_data =  req_sql_source["SQL Query for Data"]
		else:
			logger.debug("no key with the name \"SQL Query for Data\" was found")
			sql_data=  None
	else:
		logger.debug("the source is neither a string nor a dictionary")
		sql_data= None

	logger.debug("reading the sql from the source completed")

	return sql_data

def get_corresponding_sql_file(directory_path, dat_file_name, req_sql_file, all_files):
	logger = logging.getLogger()

	dat_file_path = os.path.join(directory_path,dat_file_name)
	req_sql_file_path = os.path.join(directory_path,req_sql_file)

	logger.debug("got the .dat file {} looking for corresponding sql file".format(dat_file_name))

	sql_query = None

	if(req_sql_file not in all_files):
		logger.debug("No corresponging SQL file is found for {}".format(dat_file_path)) 
		sql_query =  None
	else:
		logger.debug("found the corrponging sql {} file for {}".format(req_sql_file_path,dat_file_path))

		clear_open_file(dat_file_path)
		sql_query = read_sql(req_sql_file_path)

	logger.debug("completed the search of sql file")

	return sql_query

def reformat_sql_query(sql_query):
	logger = logging.getLogger()
	
	logger.debug("starting reformatting the sql query")

	lines = sql_query.split("\n")
	final_lines = []
	
	for i in range(len(lines)):
		lines[i] = lines[i].strip()

		if("--" in  lines[i]):
			logger.debug("comment found removing comment from the sql file")
			if(len(lines[i][:lines[i].index("--")].strip())>0):
				final_lines.append(lines[i][:lines[i].find("--")])
		
		else:
			if("rownum" in lines[i].lower()):
				logger.debug("\"rownum\" found in the line ")

				index = lines[i].lower().index("rownum")+len("rownum")
				
				while(lines[i][index] in {" ","="}):
					index+=1
				
				start = index
				
				while(index<len(lines[i]) and lines[i][index].isdigit()):
					index+=1
				end = index
				
				lines[i] = lines[i][:start]+"TODO"+lines[i][end:]

				row_update_made = True

			final_lines.append(lines[i])
	
	clear_query = " ".join(final_lines)
	
	if(row_update_made==False):
		print("No RowNum is found in the .dat file")
	
	return clear_query

def get_sql_result(sql_query):
	
	db = mysql.connector.connect(
		host="localhost",
		user="root",
		password="qwertyuiop",
		database="test1"
	)

	cursor = db.cursor()
	cursor.execute(sql_query)
	
	results = []
	
	results.append([i[0] for i in cursor.description])

	while True:
		row = cursor.fetchone()

		if row == None:
			break
		
		row_list = list(row)
		
		for index in range(len(row_list)):
			row_list[index] = " ".join(row_list[index].split(","))
		
		results.append(row_list)

	cursor.close()
	
	return results

def write_data_to_dat_file(file_path,data):
	with open(file_path,"w") as f:
		for row in data:
			if(len(row)>0):
				row_string = list(map(str,row)) 
				f.write(",".join(row_string)+"\n")

def step_8(data_keys):

	global target_root_path
	global target_dir
	global target_script_name

	logger = logging.getLogger()
	logger.debug("starting working on step 8")

	for file in os.listdir(os.path.join(target_root_path,target_dir)):
		if(file.endswith("Automation.dat")):
			file_to_process = os.path.join(target_root_path,target_dir,file)
			logger.debug("file found ending with {}".format(file_to_process))
			set_default_value(file_to_process,"NFR_Volume","5000")
			logger.debug("setting up of default value completed for file {}".format(file_to_process))
	
	all_files = os.listdir(os.path.join(target_root_path,target_dir))
	sql_query  = None
	global sql_dat_file
	sql_dat_file = None
	
	
	for file_name in all_files:
		if(sql_query==None and (file_name.endswith("_W.dat") or file_name.endswith("_F.dat"))):
			
			if(file_name.endswith("_W.dat")):
				req_sql_file = file_name[:-6]+"_W.sql"
			elif(file_name.endswith("_F.dat")):
				req_sql_file = file_name[:-6]+"_F.sql"
			
			sql_query = get_corresponding_sql_file(os.path.join(target_root_path,target_dir),file_name,req_sql_file,all_files)
			if(sql_query!=None):
				sql_dat_file = file_name

	if(sql_query==None):
		for file_name in all_files:
			if(file_name.endswith("_W.sql") or file_name.endswith("_F.sql")):
				
				if(file_name.endswith("_W.sql")):
					req_dat_file = target_script_name + "_W.dat"
				elif(file_name.endswith("_F.sql")):
					req_dat_file = target_script_name + "_F.dat"
				
				clear_open_file(os.path.join(target_root_path,target_dir,req_dat_file))
				sql_query = read_sql(os.path.join(target_root_path,target_dir,file_name))
				if(sql_query!=None):
					sql_dat_file = req_dat_file

	if(sql_query==None):
		sql_query = read_sql(data_keys)
		if(sql_query!=None):
			req_dat_file = target_script_name +"_W.dat"
			clear_open_file(os.path.join(target_root_path,target_dir,req_dat_file))
			sql_dat_file = req_dat_file
				
	if(sql_query!=None):
		# TODO TODO .....START lGGGING FROM HERE
		sql_query = reformat_sql_query(sql_query)
		print("clear sql query")
		print(sql_query)
	else:
		print("SQL query not found")
	
	data = get_sql_result("SELECT * FROM table1")

	data[0].append("RowCount")
	for i in range(1,len(data)):
		data[i].append(data[i].append("{:05}".format(i)))

	write_data_to_dat_file(os.path.join(target_root_path,target_dir,sql_dat_file),data)
	
def read_data_from_dat_file(dat_file_path,only_headers=False):
	data = []
	with open(dat_file_path,"r") as file:
		for line in file:
			if(len(line.strip())!=0):
				data.append(line.strip().split(","))
	if(only_headers):
		return data[0]
	else:
		return data

def transpose(data):
	data_cols = []
	for column in range(len(data[0])):
		col = []
		for line in range(len(data)):
			col.append(data[line][column])
		data_cols.append(col)
	return data_cols

def sort_data(data):
	data_tuples = transpose(data)
	data_tuples.sort()
	data_sorted = transpose(data_tuples)
	return data_sorted

def divide_file_into_segments(file_path,separators):
	separator_index = 0
	segments = []

	data = []
	with open(file_path,"r") as file:
		for line in file:
			if(separator_index<len(separators) and line.strip().startswith(separators[separator_index])):
				segments.append(tuple(data))
				data.clear()
				separator_index+=1
			data.append(line)
		segments.append(tuple(data))
		data.clear()  
	
	return segments

def step_9(data_keys):
	global target_root_path
	global target_dir
	global target_script_name
	global sql_dat_file

	# a)    Backup the targetDir.prm File with targetDir.prm.DUP
	# Ensure it is able to back up overriting a file if it exists
	
	with open(os.path.join(target_root_path,target_dir,target_dir+".prm"),"r") as file1:
		with open(os.path.join(target_root_path,target_dir,target_dir+".prm.DUP"),"w") as file2:
			for line in file1:
				file2.write(line)
	
	# b)	find how many column from the _W|F.dat file handled above TODO
	# For each column name, replace the name a prefix JBody_
	# So the new values will be JBody_<theColumnName1>, JBody_<theColumnName2>, etc.
	# Sort the JBody_columnname in ascending order

	data = read_data_from_dat_file(os.path.join(target_root_path,target_dir,sql_dat_file))
	
	if(len(data)>0):
		for i in range(len(data[0])):
			if(data[0][i].startswith("JBody_")):
				continue
			else:
				data[0][i] = "JBody_"+data[0][i]
		
		sorted_data = sort_data(data)
		print(sorted_data)
		write_data_to_dat_file(os.path.join(target_root_path,target_dir,sql_dat_file),sorted_data)
		
	top_segment,current_segment,bottom_segment = divide_file_into_segments(os.path.join(target_root_path,target_dir,target_dir+".prm"),
														["[parameter:JBody_","[parameter:Sys_DateTime]"])

	# print(top_segment.strip())
	# print("------------------")
	# print(current_segment.strip())
	# print("------------------")
	# print(bottom_segment.strip())

	print("##################################################")
	data_segment  = [] 
	
	file_to_read = os.path.join(target_root_path,target_dir,'AIP_Automation.dat')
	val = get_value_from_dat_file(file_to_read,"AuthEnabled")
		
	if(val.lower()=="yes"):
		print("auth enabled")
		login_segment = get_segment(column_name="LOGIN",
			param_name="JBody_AuthMemLogin",select_next_row="Sequential",table=sql_dat_file)	
		password_segment = get_segment(column_name="PASSWORD",
			param_name="JBody_AuthMemPSWD",select_next_row="Same line as JBody_AuthMemLogin",table=sql_dat_file)
		data_segment.append(segment_to_string(login_segment))
		data_segment.append(segment_to_string(password_segment))	
	elif(val.lower()=="no"):
		print("auth not enabled")
		login_segment = get_segment(column_name="LOGIN",
			param_name="JBody_AuthMemLogin",select_next_row="Sequential",table=sql_dat_file)	
		data_segment.append(segment_to_string(login_segment))
	else:
		print("the value of auth enabled was neither no, neither yes ... it was {}".format(val))

	headers = read_data_from_dat_file(os.path.join(target_root_path,target_dir,sql_dat_file),only_headers=True)

	for i in range(len(headers)):
		col_name = headers[i].lstrip("JBody_")
		file_seg = get_segment(column_name=col_name.upper(), param_name=headers[i], select_next_row="Sequential",table=sql_dat_file)
		data_segment.append(segment_to_string(file_seg))
	
	# print("".join(top_segment))
	# print("-------------------")
	# print("".join(data_segment))
	# print("-------------------")
	# print("".join(bottom_segment))
	# print("-------------------")

	with open(os.path.join(target_root_path,target_dir,target_dir+".prm"),"w") as file:
		file.write("".join(top_segment).strip()+"\n")
		file.write("".join(data_segment).strip()+"\n")
		file.write("".join(bottom_segment).strip()+"\n")

	# print("updated {}".format(os.path.join(target_root_path,target_dir,target_dir+".prm")))
	

def get_segment(column_name, param_name, select_next_row, 
			delimiter=",", generate_new_val="EachIteration", original_value = "",
			out_of_range_policy = "ContinueWithLast", start_row = "1",  
			table = "MemIDCardPrint_W.dat", table_location  = "Local", 
			seg_type  = "Table", auto_allocate_block_size = "1", value_for_each_vuser = ""):
	return {
		"parameter":param_name,
		"ColumnName":column_name,
		"Delimiter":delimiter,
		"GenerateNewVal":generate_new_val,
		"OriginalValue":original_value,
		"OutOfRangePolicy":original_value,
		"ParamName":param_name,
		"SelectNextRow":select_next_row,
		"StartRow":start_row,
		"Table":table,
		"TableLocation":table_location,
		"Type": seg_type,
		"auto_allocate_block_size":auto_allocate_block_size,
		"value_for_each_vuser": value_for_each_vuser,
	}

	
def segment_to_string(segment):
	return '''[parameter:{}]
\"ColumnName\"=\"{}\"
\"Delimiter\"=\"{}\"
\"GenerateNewVal\"=\"{}\"
\"OriginalValue\"=\"{}\"
\"OutOfRangePolicy\"=\"{}\"
\"ParamName\"=\"{}\"
\"SelectNextRow\"=\"{}\"
\"StartRow\"=\"{}\"
\"Table\"=\"{}\"
\"TableLocation\"=\"{}\"
\"Type\"=\"{}\"
\"auto_allocate_block_size\"=\"{}\"
\"value_for_each_vuser\"=\"{}\" 
'''.format(segment['parameter'],segment['ColumnName'],segment['Delimiter'],
	segment['GenerateNewVal'],segment['OriginalValue'],segment['OutOfRangePolicy'],
	segment['ParamName'],segment['SelectNextRow'],segment['StartRow'],segment['Table'],
	segment['TableLocation'],segment['Type'],segment['auto_allocate_block_size'],segment['value_for_each_vuser'])


def step_10():
	global target_root_path
	global target_dir
	global target_script_name
	global sql_dat_file

	for file in os.listdir(os.path.join(target_root_path,target_dir)):
		if(file.endswith(".dat")):
			print(file)
			data = read_data_from_dat_file(os.path.join(target_root_path,target_dir,file))
			write_data_to_dat_file(os.path.join(target_root_path,target_dir,file),data)			

					

# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
def join_alias_keys(data_keys,original_key, alternative_key):
	logger = logging.getLogger()
	
	if(data_keys[alternative_key]!=None and data_keys[original_key]==None):
		data_keys[original_key] = data_keys[alternative_key]		
		logger.debug("value for \"{}\" and \"{}\" keys brought to the value of \"{}\"".format(original_key,alternative_key,original_key))	

	else:
		logger.debug("value for \"{}\" and \"{}\" keys cannot be brought together".format(original_key,alternative_key))

def extract_header_info(data_keys):
	logger = logging.getLogger()

	if(data_keys["Other Header Info"]!=None):
		l = data_keys["Other Header Info"].split(",")
		
		data_keys["ClientID"] = "".join(l[:1]).strip() 
		data_keys["ClientSecret"] = ",".join(l[1:]).strip()
		
		if(data_keys["ClientSecret"].split(":")[0].lower() == "ClientSecret".lower()):
			data_keys["ClientSecret"] = ":".join(data_keys["ClientSecret"].split(":")[1:])
		
		logger.debug("Extarcted \"ClientSecret\" and \"ClientSecret\" from \"Other Header Info\"")
		logger.debug("\"Other Header Info\": {}".format(data_keys["Other Header Info"]))
		logger.debug("\"Extracted Client ID\": {}".format(data_keys["ClientID"]))
		logger.debug("\"Extracted Client Secret\": {}".format(data_keys["ClientSecret"]))
	
	else:
		logger.debug("\"Other Header Info\" is set to None, so client id and secret cannot be extracted")

def extract_services_end_point_url(data_keys):
	# TODO .... i feel there is some issue here 

	logger = logging.getLogger()
	
	if(data_keys["ServicesEndPointURL"]!=None and ":" in data_keys["ServicesEndPointURL"]):
		l = data_keys["ServicesEndPointURL"].split(":")
		logger.debug("Info extrcated from \"ServicesEndPointURL\": {} are as below:".format(data_keys["ServicesEndPointURL"]))
		
		data_keys["ServiceType"] = l[0].strip()
		logger.debug("\"ServiceType\": {}".format(data_keys["ServiceType"]))
		
		data_keys["ServiceName"] = ":".join(l[1:-1])
		port = False
		
		if(l[-1].split("/")[0].strip().isnumeric()):
			port = True
			data_keys["ServiceName"] += ":"+l[-1].split("/")[0].strip()
		logger.debug("\"ServiceName\": {}".format(data_keys["ServiceName"]))
		
		try:
			if(port):
				new_l = l[-1].split("/")[1:]
			else:
				new_l = l[-1].split("/")
			
			bsc_index = new_l.index("bsc")
			
			data_keys["ServicePath"] = "/"+"/".join(new_l[:bsc_index]).strip()
			logger.debug("\"ServicePath\": {}".format(data_keys["ServicePath"]))
			
			data_keys["ServiceURL"] = "/"+"/".join(new_l[bsc_index:]).strip()
			logger.debug("\"ServiceURL\": {}".format(data_keys["ServiceURL"]))
		
		except:
			logger.debug("Cannot extract ServicePath and ServiceURL from \"ServicesEndPointURL\" because \"bsc\" was not found in {}".format(data_keys(data_keys["ServicesEndPointURL"])))
	else:
		logger.debug("Cannot extract info from ServicesEndPointURL")

def jsonify(data_keys,key):
	logger = logging.getLogger()

	if(data_keys[key]!=None):
		data_keys[key] = json.loads(data_keys[key])
		
		logger.debug("\"{}\" has been converted to json and can be found below".format(key))
		logger.debug(json.dumps(data_keys[key],indent = 4))
	else:
		logger.debug("Cannot convert to json for \"{}\", as the value is None".format(key))
	
def data_formatting(data_keys):

	join_alias_keys(data_keys,"Test Method Name","Test Operation Name")
	join_alias_keys(data_keys,"Container","JVM")
	join_alias_keys(data_keys,"ServicesEndPointURL","ServicesEndPoint URL")
	extract_header_info(data_keys)
	extract_services_end_point_url(data_keys)
	jsonify(data_keys,"Request JSON")
	jsonify(data_keys,"Response JSON")


def get_processed_dict_data(file_dir,file_name, data_keys):

	file_path = os.path.join(current_directory,catalog_file_to_read)
	
	logger = logging.getLogger()
	logger.debug("Processing the catalog file: {}".format(file_path))

	with open(file_path,"r") as f:	
		prev_key_used = None

		for line in f:
			for key in data_keys:
				if(key.lower() in line.lower()):

					if(data_keys[key]!=None):		
						yield data_keys
						refresh_dict(data_keys)
					
					value = ":".join(line.split(":")[1:]).strip()
					data_keys[key] =  value
					prev_key_used = key
					break
			else:
				data_keys[prev_key_used] += line

		yield data_keys
		refresh_dict(data_keys)
	
	logger.debug("Completed Processing the catalog file: {}".format(file_path))


# -----------------------------------------------------------------------------
def refresh_dict(data_keys):
	logger=logging.getLogger()
	logger.debug("reseting the values in the dictionary in order to extract new set of values")
	for key in data_keys:
		data_keys[key] = None

def setup_logger(file_name):
	logging.basicConfig(filename=os.path.join(current_directory,file_name), 
			format='%(filename)s - %(lineno)s - %(funcName)s() - %(levelname)s - %(message)s', 
			filemode='w')
	logger=logging.getLogger()
	logger.setLevel(logging.DEBUG) 

def backup(source_dir):
	# since after compressing the file would be placed in the same folder only so the path of that folder is only taken
	
	logger = logging.getLogger()
	
	logger.debug("backing up process of {} has started".format(source_dir))
	
	if(os.path.exists(source_dir) and os.path.isdir(source_dir)):
		shutil.make_archive(source_dir,"zip",source_dir)
		shutil.make_archive(base_dir=source_dir, root_dir=source_dir, format='zip', base_name=source_dir)
		logger.debug("backing up files in {} and would be placed in {}".format(source_dir, os.path.split(source_dir)[0]))
	
	else:
		logger.error("some error occered during backing up brocess")
		
def delete_single_folder(folderPath):
	logger = logging.getLogger()
	if(os.path.isdir(folderPath)):
		try:
			shutil.rmtree(folderPath)
			logger.debug("Deleted folder {}".format(folderPath))
		except Exception as e:
			logger.error("Some error in while deleting {}".format(folderPath), exc_info=True)
	else:
		logger.debug("No able to delete {} because it is not a folder".format(folderPath))

def delete_folders(directory_path, folders = set()):
	
	logger = logging.getLogger()
	logger.debug("Deleting folders {}".format(folders))

	for folder_name in os.listdir(directory_path):
		if(folder_name in folders):
			actualFolder = os.path.join(directory_path, folder_name)
			delete_single_folder(actualFolder)
	
	logger.debug("Process complete")

def delete_single_file(dir_name, file):
	
	logger = logging.getLogger()
	
	actualFile = os.path.join(dir_name, file)
	try:
		os.remove(actualFile)
		logger.debug("Deleted file {}".format(actualFile))
	except Exception as e:
		logger.error("Some error in while deleting {}".format(actualFile), exc_info=True)

def delete_files(dir_name, files_to_delete = set(), 
		starts_with=False, ends_with = False, exact_match = False):
	
	logger = logging.getLogger()
	
	if(starts_with==True):
		logger.debug("Deleting files starting with {}".format(files_to_delete))
		
		for file in os.listdir(dir_name):
			for fileType in files_to_delete:
				if file.startswith(fileType):
					delete_single_file(dir_name,file)
		
		logger.debug("Process complete")

	elif(ends_with==True):
		logger.debug("Deleting files ending with {}".format(files_to_delete))
		
		for file in os.listdir(dir_name):
			for fileType in files_to_delete:
				if file.endswith(fileType):
					delete_single_file(dir_name,file)
					
		logger.debug("Process complete")

	elif(exact_match==True):
		logger.debug("Deleting files matching exactly with {}".format(files_to_delete))

		for file in os.listdir(dir_name):
			for fileType in files_to_delete:
				if(file == fileType):
					delete_single_file(dir_name,file)

		logger.debug("Process complete")
	
	else:
		logger.debug("No argument among starts_with, ends_with, exact_match was provided with the fuction call")

def cleanup_script_files(directory_path):
	delete_folders(directory_path, {"result1", "result2"})    
	delete_files(directory_path, {"combined_", "testing"}, starts_with=True)
	delete_files(directory_path, {".idx",".bak",".txt",".tmp",".log",".c.pickle"},ends_with=True)
	delete_files(directory_path, {"Pre_cci.c", "test.txt"},exact_match=True)
	

# ------------------------------------------------------------------------------------------------
# MAIN CODE

global current_directory
global catalog_file_to_read
global src_root_path
global target_dir
global target_script_name
global target_root_path
global log_file

if(__name__=="__main__"):
	

	current_directory = os.getcwd()
	catalog_file_to_read = "TestCatalog1.txt" 
	src_root_path = os.path.join(current_directory,"Template")
	target_dir = None
	target_script_name = None
	target_root_path = None
	log_file = "app.log"

	data_keys = {
		"Test Suite Name": None,
		"Test Method Name":None,
		"Test Operation Name": None,
		"Container": None,
		"JVM": None,
		"Auth URL": None,
		"Auth Token": None,
		"Other Header Info": None,
		"ServicesEndPointURL":None,
		"ServicesEndPoint URL": None,
		"Request JSON": None,
		"SQL Query for Data": None,
		"Response JSON": None,
		"SQL Query to validate the data":None,
		"Test Execution Status": None
	}

	setup_logger(log_file)

	backup(os.path.join(src_root_path,"AIP_Mem_Profile"))

	cleanup_script_files(os.path.join(src_root_path,"AIP_Mem_Profile"))

	logger = logging.getLogger()

	for key_value_pair in get_processed_dict_data(current_directory, catalog_file_to_read, data_keys):
		logger.debug("The parsed data is as below:")
		logger.debug(json.dumps(key_value_pair,indent = 4))
		
		data_formatting(data_keys)
		
		logger.debug("Data after data formatting:")
		logger.debug(json.dumps(key_value_pair,indent = 4))
		
		print("step_2_s")
		step_2(data_keys)    
		print("step_2_e")
		

		print("target_dir:",target_dir)
		print("target_script_name:",target_script_name)
		print("target_root_path: ",target_root_path)
		sd = "AIP_Mem_Profile"

		print("step_3_s")
		step_3(data_keys,sd)
		print("step_3_e")
		print("step_4_s")		
		step_4(data_keys,sd)
		print("step_4_e")
		print("step_5_s")		
		step_5(data_keys,sd)
		print("step_5_e")
		print("step_6a_s")		
		step_6a(data_keys)
		print("step_6a_e")
		print("step_6c_s")		
		step_6c(data_keys)    
		print("step_6c_e")
		print("step_6b_s")		
		step_6b(data_keys)
		print("step_6b_e")
		print("step_7_s")		
		step_7(data_keys)
		print("step_7_e")
		print("step_8_s")		
		step_8(data_keys)
		print("step_8_e")
		print("step_9_s")		
		step_9(data_keys)
		print("step_9_e")
		print("step_10_s")		
		step_10()
		print("step_10_e")
		
		
	

