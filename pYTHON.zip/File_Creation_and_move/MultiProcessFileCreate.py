import os
import datetime
import csv
from concurrent.futures import ProcessPoolExecutor
# Define input and output file paths
input_file_path = "\\\\bsc\\it\\VDI_Home_SAC\\vr02\\Desktop\\BSC\\PML_270FileWrite\\27X\\SUB_export.csv"
output_folder = "C:\\Users\\vr02\\Documents\\SUBFiles\\"
##output_folder = "Z:\\edibound\\testin\\Sterling270RT\\"
##output_folder = "Z:\\EDF09\\edibound\\Inquiry\\testin\\Sterling270RT\\Temp_Output\\"
output_file_name = "Passport_STRL_TPRT_867858EC-4A19-4F29-B84D-"

##print(os.getcwd())
##print(datetime.datetime.now())

#print(input_file_path)
#print(output_folder)

"""
text_1= "ISA*00*          *00*          *ZZ*TRANSUNION     *30*940360524      *210729*1336*^*00501*423703807*0*T*:~GS*HR*TRANSUNION*940360524*20240111*133604*165278843*X*005010X212~ST*276*0001*005010X212~BHT*0010*13*EDI-27X-Prolifics-Migration*20240111*1240~HL*1**20*1~NM1*PR*2*BLUE SHIELD-CA (PPO INDEM ONLY)*****PI*090~HL*2*1*21*1~NM1*41*2*"
text_2="*****46*"
text_3="~HL*3*2*19*1~NM1*1P*2*"
text_4="*****XX*"
text_5="~HL*4*3*22*0~DMG*D8*"
text_6="~NM1*IL*1*"
text_7="*"
text_8="****MI*"
text_9="~TRN*1*27X-PERFTESTEDI~DTP*472*D8*20230304~SE*14*0001~GE*1*165278843~IEA*1*423703807~"
##i=0
"""

text_1= "ISA*00*          *00*          *ZZ*TRANSUNION     *30*940360524      *210729*1336*^*00501*423703807*0*T*:~GS*HR*TRANSUNION*940360524*20240111*133604*165278843*X*005010X212~ST*276*0001*005010X212~BHT*0010*13*EDI-27X-Prolifics-Migration*20240111*1240~HL*1**20*1~NM1*PR*2*BLUE SHIELD-CA (PPO INDEM ONLY)*****PI*090~HL*2*1*21*1~NM1*41*2*"
text_2="*****46*"
text_3="~HL*3*2*19*1~NM1*1P*2*"
text_4="*****XX*"
text_5="~HL*4*3*22*1~NM1*IL*2*"
text_6="*****MI*"
text_7="~HL*5*4*23~DMG*D8*"
text_8="~NM1*QC*1*"
text_9="*"
text_10="~TRN*1*27X-PERFDEPTESTEDI~DTP*472*D8*20231201~SE*16*0001~GE*1*165278843~IEA*1*423703807~"

def create_EDI_Test_file(data_files,output_folder ):
        for line in data_files:
            #print(line.strip())
            prpr_name,prpr_npi,DOB,meme_last_name,meme_first_name,sbsb_id = line.strip().split(",")
            #print("Inside"+output_folder + output_file_name+ sbsb_id +".270")
            with open(output_folder + output_file_name+ sbsb_id +".270", "+w") as output_file:
                output_file.write(text_1+prpr_name+text_2+prpr_npi+text_3+prpr_name+text_4+prpr_npi+text_5+DOB+text_6+meme_last_name+text_7+meme_first_name+text_8+sbsb_id+text_9)
                output_file.close()

# copy files from src to dest
def main(input_file_path="\\\\bsc\\it\\VDI_Home_SAC\\vr02\\Desktop\\BSC\\PML_270FileWrite\\27X\\SUB_export.csv", output_folder="C:\\Users\\vr02\\Documents\\SUBFiles\\"):       
    with open(input_file_path, "r") as input_file:
        inputdata= input_file.readlines()
        input_file.close()
        print(len(inputdata))
        #print(inputdata[1:3])
        n_workers = 10
        chunksize = round(len(inputdata) / n_workers)
        print(chunksize)
        # create the process pool
        with ProcessPoolExecutor(n_workers) as exe:
            # split the copy operations into chunks
            for i in range(0, len(inputdata), chunksize):
                # select a chunk of filenames
                data_files = inputdata[i:(i + chunksize)]
                # submit the batch copy task
                _ = exe.submit(create_EDI_Test_file, data_files, output_folder)
                #print(data_files)
        print('Done')
    # Read content from input file and write it into output file

# entry point
if __name__ == '__main__':
    main()

##print(datetime.datetime.now())
##txt = "KARUK COMMUNITY HEALTH CLINIC,1952483406,19631229,YEIP,SHARI,903107958"
##line_value = txt.split(",")
##prpr_name,prpr_npi,DOB,meme_last_name,meme_first_name,sbsb_id = line_value
##print(text_1+prpr_name+text_2+prpgr_npi+text_3+prpr_name+text_4+prpr_npi+text_5+DOB+text_6+meme_last_name+text_7+meme_first_name+text_8+sbsb_id+text_9)

