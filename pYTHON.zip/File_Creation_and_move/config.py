path = dict(
    src="\\\\bsc\\it\\VDI_Home_SAC\\vr02\\Desktop\\BSC\\PML_270FileWrite\\27X\\SUBFiles",
    dest="Z:\\Sterling276RT\\"
)