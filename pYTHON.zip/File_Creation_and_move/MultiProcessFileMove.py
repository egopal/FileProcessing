# copy files from one directory to another concurrently with processes in batch
from os import listdir
from os.path import join
from shutil import copy
from concurrent.futures import ProcessPoolExecutor
import config

# copy files from source to destination
def copy_files(src_paths, dest_dir):
    # process all file paths
    for src_path in src_paths:
        # copy source file to dest file
        dest_path = copy(src_path, dest_dir)
       # print(f'.copied {src_path} to {dest_path}', flush=True)
 
# copy files from src to dest
def fileMove(src, dest):
    files = [join(src,name) for name in listdir(src)]
    # determine chunksize
    n_workers = 10
    chunksize = round(len(files) / n_workers)
    # create the process pool
    with ProcessPoolExecutor(n_workers) as exe:
        # split the copy operations into chunks
        for i in range(0, len(files), chunksize):
            # select a chunk of filenames
            filenames = files[i:(i + chunksize)]
            # submit the batch copy task
            _ = exe.submit(copy_files, filenames, dest)
    print('Done')

# entry point
if __name__ == '__main__':
    src=config.path['src']
    dest=config.path['dest']
    fileMove(src,dest)    