'''
Static Authentication
Cookie based Authentication
'''