DATA CONSOLIDATION
====================

Open a file as consolidatedData.csv or consolidatedData.xls
Add two column as mpgw, api

Get the list of file from the directory
Sort the list of files by date/month and the count of the same.

Read the BaseFile-Volume-2020-06-27.csv first, even if it is not a default one.
Get the date from the filename
Now go to ConsolidatedData, write the third column name with the date as "20-06-27"
Read every line and copy over to the ConsolidatedData file.
The base file is copied over.
Now, We will now look for the combination of first and second column in all the remaining .csv file for each month as follows


The remaining files for the months are Volume-2020-06-28.csv and Volume-2020-06-29.csv
Open the earliest date file
It is Volume-2020-06-28.csv
Open the file consolidatedData, write the next column name with the date as "20-06-28"
Be Ready to read the Volume-2020-06-28.csv file
Get the first two data (Row 2) from the consolidatedData file for the column name mpwg, api 
Look for the same data in targetFile Volume-2020-06-28.csv
If the combination found in first two columns, then get the value of the count
Add this value in the consolidatedData file under the date  "20-06-28"
The value entered is in the fourth column
Pop this data from the targetFile Volume-2020-06-28.csv
Continue in the same way
if the data is not found, Ignore
If the data is Found, get the count and add for the date
After all the pop, if there are still data found in targetFile Volume-2020-06-28.csv
get all the data
 write the mpwg data under mpwg
 write the api data under api
 the count is under the relevant date
So, you have data for two dates
Repeat the same for Volume-2020-06-29.csv

Now, You will see the count of files for the month is all used up
add a column at the end to consolidatedData file
columnName is Max(Month-Year)
Get the max of the data for the month from the given data.
Write that in the new column

Now Move to another month
The remaining files for the months are Volume-2020-07-01.csv, Volume-2020-07-10.csv, Volume-2020-07-11.csv
continue to read the first file Volume-2020-07-01.csv
Repeat the operation (LINE 18 TO 46 for JULY)
AFTER JULY MAX, Move to AUG repeating line 46 to 49 for Aug.

