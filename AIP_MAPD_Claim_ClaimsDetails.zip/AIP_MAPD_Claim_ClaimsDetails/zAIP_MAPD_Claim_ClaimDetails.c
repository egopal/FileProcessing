/*
//--------------------------------------------------------------------------------------------------------------------/
	BRIEFLY DESCRIBE SCRIPT FUNCTIONALITY
    PLEASE ADD ANY COMMENTS/OBSERVATIONS RELATED TO THE SCRIPT YOU ARE WORKING ON, WE CAN TAKE ACTION BASED ON COMMENTS
//---------------------------------------------------------------------------------------------------------------------/
*/

zAIP_MAPD_Claim_ClaimDetails(){
	
	
	
	//*---------------------------------------------------------------------------------------------------------------------/
	//[1] Environment and Auth Variables
    //*---------------------------------------------------------------------------------------------------------------------/

	  InvokeMemAuth();
  
  

  	
    //*---------------------------------------------------------------------------------------------------------------------/
    //[2] ENRICH DATA AND SET PARAM VALUES - We will be using lr_save_string to save the param value to support 12.60 JSON 
    //*---------------------------------------------------------------------------------------------------------------------/

    	// JSON HEADER - MODIFY ONLY IF THE SERVICENAME PARAM IS DIFFERENT
    	
	   	lr_save_string(lr_get_host_name( ),"hostName_val");
		lr_param_sprintf ("transId_val", "%s-%s%s", lr_eval_string("{AIP_ServiceName}"), lr_eval_string("{Sys_VUserID}"), lr_eval_string("{Sys_Iteration}"), 40);				
 		lr_save_string(lr_eval_string("{Sys_DateTime}"),"requestDateTime_val");
		
    
		// JSON BODY - DEFINE REQUIRED DATA PARAMETERS AND ASSIGN AS *_val
		
		// delcare variables for the body request here.  In this example, we are grabbing variable Auth_MemberIdentifier_val from the authenticate service call
		//  in AIP_Auth_MemAuth.h
		
     	//lr_save_string(lr_eval_string("{JBody_DataParam1}"),"DataParam1_val");
     	//lr_save_string(lr_eval_string("{JBody_DataParam1}"),"DataParam1_val");
     	// etc...
     	
     	//Example if no auth call, we will call the parameter from a file rather than from the authentication call in AIP_AUth_MemAuth.h:
     	//lr_save_string(lr_eval_string("{JBody_MemberIdentifier}","Auth_MemberIdentifier_val");
     	
     	lr_save_string(lr_eval_string("{JBody_MbrId}"),"MbrId_val");
     	lr_save_string(lr_eval_string("{JBody_ClaimNumber}"),"ClaimNumber_val");
     	
    	web_add_header("mbrnum", "{MbrId_val}");

	//*---------------------------------------------------------------------------------------------------------------------/
    //[3] Load JSON or Get JSON from FilePath or Define JSON
  	//*---------------------------------------------------------------------------------------------------------------------/
 	
  		//HEADER - RETAIN PARAM VALUES (requestDateTime_val, hostName_val, transId_val), REQUIRED FOR TRANSACTION ANALYSIS
  		//BODY   - REPLACE DATA PARAM VALUES WITH *_val HERE
  		
  		request_json_base=
		" {"
     "\"requestHeader\": {\n"
                        "\"consumer\": {\n"
                                    "\"name\": \"MEMBER\",\n"
                                    "\"id\": \"MEMBER\",\n"
                                    "\"businessUnit\": \"CHANNELS\",\n"
                                    "\"type\": \"string\",\n"
                                    "\"clientVersion\": \"V1\",\n"
                                    "\"requestDateTime\": \"string\",\n"
                                    "\"hostName\": \"LOCALHOST\",\n"
                                    "\"businessTransactionType\": \"string\",\n"
                                    "\"contextId\": \"\",\n"
                                    "\"secondContextId\": \"\",\n"
                                    "\"thirdContextId\": \"\"\n"
                        "},\n"
                        "\"credentials\": {\n"
                                    "\"userName\": \"\",\n"
                                    "\"password\": \"\",\n"
                                    "\"token\": \"eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJTZXJ2aWNlRGVza3RvcF9CbHVlc2hpZWxkQ0EiLCJpYXQiOjE0OTQyODY0NTMsInN1YiI6IkJsdWUgU2hpbGVkIG9mIENhbGlmb3JuaWEiLCJpc3MiOiJCbHVlc2hpZWxkQ0EiLCJleHAiOjE0OTQ1MDU0NTN9.7Pds-xLnZXkt7eWMhMSUyt0KQZmgNsrL8RMrUUENZCk\",\n"
                                    "\"type\": \"jwt\"\n"
                        "},\n"
                        "\"transactionId\": \"123456\"\n"
            "},\n"
            "\"requestBody\": {\n"
                        "\"memberIdentifier\": \"{MbrId_val}\",\n"
                        "\"claimNumbers\": \"{ClaimNumber_val}\"\n"
            "}\n"


"}";


		// PLEASE DO NOT MODIFY - RESOLVING THE REQUEST CONTRACT
	    lr_save_string(lr_eval_string(request_json_base), "REQUEST_JSON_PARAM");

	    	    
 	//*---------------------------------------------------------------------------------------------------------------------/
 	//[4] RESPONSE ASSERTIONS FOR TEST ANALYSIS
	//*---------------------------------------------------------------------------------------------------------------------/

		// RESPONSE DATA - PLEASE DO NOT MODIFY
		
	    web_reg_save_param_ex("ParamName=ResponseHttp", "LB=", "RB=", SEARCH_FILTERS, "Scope=Headers", LAST);
		
	    web_reg_save_param_ex("ParamName=ResponseJSON", "LB=", "RB=", SEARCH_FILTERS, "Scope=Body", LAST);
	    

		// RESPONSE JSON - HEADER VALIDATION - RETAIN SuccessCount and WarningCount
		
	    web_reg_find("Text=SUCCESS", "SaveCount=SuccessCount", "Search=ALL", "LAST" );
	
		// RESPONSE JSON - MODIFY BODY VALIDATION TEXT/VALUE - RETAIN PayLoadCount.
		// ADD ADDITIONAL VALIDATIONS - NAME IT RELEVANT TO THE OBJECT, say PayloadClaims, etc.
		
        web_reg_find("Text=patientResponsibilityAmount", "SaveCount=PayloadCount","Search=ALL", LAST );
       // web_reg_find("Text=No Data Found", "SaveCount=PayloadCount", "Fail=Found", LAST );

		
  	//*---------------------------------------------------------------------------------------------------------------------/
    //[5] SERVICE REQUESTS
    //*---------------------------------------------------------------------------------------------------------------------/
    
   
	    lr_save_string(lr_eval_string("{Sys_DateTime}"),"requestTime");
	
		
		// YOU MAY NEED TO INPUT CORRECT SERVICENAME PARAM WHEN THERE ARE MORE THAN ONE TRANSACTIONS
    	
		lr_start_transaction(lr_eval_string("{AIP_ServiceName}"));
			
		web_custom_request(lr_eval_string("{AIP_ServiceName}"),
	  		"URL={AIP_EnvServer}{AIP_EnvServerPath}{AIP_ServiceURL}",
	       	"Method=POST",
	     	"Mode=HTTP",
	     	"EncType=application/json",
	 	   	"Body={REQUEST_JSON_PARAM}",
     	LAST);
		
		transDuration = lr_get_transaction_duration(lr_eval_string("{AIP_ServiceName}"));

		
	//*---------------------------------------------------------------------------------------------------------------------/
    //[6] TRANSACTION PASS/FAIL DECISION CRITERIA
    //*---------------------------------------------------------------------------------------------------------------------/
  
		// ALL THE THREE CRIERIA IS MANDATORY, ADD ADDITIONAL VALIDATION WHEN NEEDED
		
		if ( (atoi(lr_eval_string("{SuccessCount}")) > 0  ) && ( atoi(lr_eval_string("{PayloadCount}")) > 0 ) ) {
	      	lr_end_transaction(lr_eval_string("{AIP_ServiceName}"), LR_PASS);
	    	transStatus ="PASS";
	    } else {
	    	lr_end_transaction(lr_eval_string("{AIP_ServiceName}"), LR_FAIL);
	    	transStatus ="FAIL";
	    }
		
		
	//*---------------------------------------------------------------------------------------------------------------------/
 	//[7] LOGGING - FOR EVERY TRANSACTIONS - DO NOT ENABLE UNLESS YOU WANT TO TRY THIS OUT - DISABLE WHILE RUNNING ACTUAL TESTS
    //*---------------------------------------------------------------------------------------------------------------------/
    	
    //   YOU MAY NEED TO INPUT CORRECT SERVICENAME PARAM WHEN YOU ADD MORE THAN ONE SERVICES IN THE SCRIPT
    	
     //ResponseAnalysis( lr_eval_string("{transId_val}"), lr_eval_string("{AIP_ServiceURL}"), lr_eval_string("{SuccessCount}"), lr_eval_string("{PayloadCount}"), lr_eval_string("{requestTime}"), lr_eval_string(request_json_base), transStatus, transDuration);

	//*======================================================================================================================
	
	
	return 0;
	 
}