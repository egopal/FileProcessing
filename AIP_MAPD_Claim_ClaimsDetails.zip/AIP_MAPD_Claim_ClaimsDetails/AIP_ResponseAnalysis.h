ResponseAnalysis(char transId[40], char serviceURL[80], char successCount[3], char payloadCount[3], char * requestTime, char *REQUEST_JSON_PARAM, char *transStatus,  double rtDuration )
{   
	int responseMemSize;	
	int HttpRetCode, jsonRequestSize, httpRespSize, jsonResponseSize;

//	char * transId = transId_val;
	
  	char * respStatusJ;
	char * statusCodeJ;
	char * respDTimeJ;
	char * transIdJ;
	char * errorCodeJ;
	char * descJ;
    char * messageJ;
    char lrRespTime[10]="";
    char TestDataBuffer[1000];   //Dynamic - Gopal
    
    double atof (const char *string); 
  	double time_difference;
    
  	lr_save_timestamp("startTime", LAST);
    //lr_output_message("Start Time = %s", lr_eval_string("{startTime}")); 
  	
    snprintf(lrRespTime, 10, "%2.4f", rtDuration);
	
	HttpRetCode = web_get_int_property(HTTP_INFO_RETURN_CODE);
	//lr_output_message("HTML Response CODE********************* %d",HttpRetCode);
    
	jsonRequestSize  = strlen(lr_eval_string("{REQUEST_JSON_PARAM}"));
    	
	httpRespSize     = strlen(lr_eval_string("{ResponseHttp}"));
	
	jsonResponseSize = strlen(lr_eval_string("{ResponseJSON}"));
	
	lr_output_message("START_TRANSACTION_LOG******%s", lr_eval_string("{transId_val}"));
	
	//httpResponseSize = web_get_int_property(HTTP_INFO_DOWNLOAD_SIZE);
	//lr_output_message("HTML Response Size********************* %d",httpResponseSize);
	
	// DATA FOR ANALYTICS
	
	FindAllSubStrings(lr_eval_string("{ResponseJSON}"), "transactionNotification\":{\"status\":\"", "\",", TestDataBuffer, "RespStatus");
	lr_save_string(TestDataBuffer,"respStatusFromJson");
	
	FindAllSubStrings(lr_eval_string("{ResponseJSON}"), "\"statusCode\":\"", "\",", TestDataBuffer, "StatusCode");
	lr_save_string(TestDataBuffer,"statusCodeFromJson");
		
	FindAllSubStrings(lr_eval_string("{ResponseJSON}"), "responseDateTime\":\"", "\",", TestDataBuffer, "RespDT");
	lr_save_string(TestDataBuffer,"respDTimeFromJson");
	
	//FindAllSubStrings(lr_eval_string("{ResponseJSON}"), "transactionId\":\"", "\",\"remarks", TestDataBuffer, "TransID");
	//lr_save_string(TestDataBuffer,"transIdFromJson");
	
  	FindAllSubStrings(lr_eval_string("{ResponseJSON}"), "\"code\":\"", "\",", TestDataBuffer, "ErrorCode");
 	//lr_output_message("errorCodeJ: %s\n", errorCodeJ);
	lr_save_string(TestDataBuffer,"errorCodeFromJson");
	
	FindAllSubStrings(lr_eval_string("{ResponseJSON}"), "\"description\":\"", "\",", TestDataBuffer, "Description"); 
	lr_save_string(TestDataBuffer,"descriptionFromJson");	
	
	FindAllSubStrings(lr_eval_string("{ResponseJSON}"), "\",\"message\":\"", "\",", TestDataBuffer, "Message");
	lr_save_string(TestDataBuffer,"messageFromJson");
	
	lr_output_message("%s_REQUEST_START:%s_REQUEST_END", lr_eval_string("{transId_val}"), lr_eval_string(REQUEST_JSON_PARAM) );
  	
	lr_output_message("%s_RESPONSE_HTTP_START:%s_RESPONSE_HTTP_END", lr_eval_string("{transId_val}"), lr_eval_string("{ResponseHttp}"));

	lr_output_message("%s_RESPONSE_JSON_START:%s_RESPONSE_JSON_END", lr_eval_string("{transId_val}"), lr_eval_string("{ResponseJSON}"));
		
	lr_save_timestamp("EndTime", LAST);
    //lr_output_message("EndTime = %s", lr_eval_string("{EndTime}"));
	
//	lr_output_message ("HEAD~~TransName-VUserItnID~TrnStatus~RespStatusJ~HttpCode~PayloadCount~LRRespTime~StatusCodeJ~ErrorCode~Descriptions~Message~ActualReqDT~RespDTJ~JsonReqBytes~HttpRespBytes~JsonRespBytes~SysMem~RATime~DataRowNum~Server~URL~LGName~~END");
	
	time_difference = atof(lr_eval_string("{EndTime}")) - atof(lr_eval_string("{startTime}"));
	
	lr_output_message ("LOG~~%s~%s~%s~%d~%s~%s~%s~%s~%s~%s~%s~%s~%s~%s~%s~%s~%d~%d~%d~%d~%s~%d~%s~%s~%s~%s~~END",
	        transId,
		    transStatus,
		    lr_eval_string("{respStatusFromJson}"),
		    HttpRetCode,
		    payloadCount,
		    lrRespTime,
			lr_eval_string("{statusCodeFromJson}"),
		    lr_eval_string("{errorCodeFromJson}"),
			lr_eval_string("{descriptionFromJson}"),
			lr_eval_string("{messageFromJson}"),
			requestTime,
			lr_eval_string("{respDTimeFromJson}"),
			lr_eval_string("{AIP_ServiceContainerName}"),
			lr_eval_string(""),
			lr_eval_string(""),	
			lr_eval_string(""),
			jsonRequestSize,
			httpRespSize,
			jsonResponseSize,
			(httpRespSize+jsonResponseSize),
			lr_eval_string("{AIP_Automation_Mem}"),
			(int)time_difference,
			lr_eval_string("{JBody_RowNum}"),
	        lr_eval_string("{AIP_EnvServer}"),
		    serviceURL,                             // Needed for Auth and MultiAction Scenario
			lr_get_host_name()
	);

//	lr_output_message("LOG_END_******%s", lr_eval_string("{transId_val}"));
	lr_output_message("TRANSACTION_LOG_END***_%s_LOG_END", lr_eval_string("{transId_val}"));

    // lr_eval_string("{transIdFromJson}"),	
		
    return 0;  
}