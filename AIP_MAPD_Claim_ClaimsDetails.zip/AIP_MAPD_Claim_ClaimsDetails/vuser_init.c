vuser_init()
{

     web_set_sockets_option("SSL_VERSION","TLS1.2");

     web_set_max_html_param_len(lr_eval_string("{AIP_Automation_Mem}"));
		
     //setSSLCert();
     
    
     return 0;
}